#include <features.h>

char __Ident_gnulib[] = "$Version: MiNTLib "
#ifdef __M68020__
"-m68020-60 "
#endif
#ifdef __M68881__
"-m68881 "
#endif
#ifdef __MSHORT__
"-mshort "
#endif
VERSION" $";
