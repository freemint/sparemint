#include <stdio/test-iformat.c>
