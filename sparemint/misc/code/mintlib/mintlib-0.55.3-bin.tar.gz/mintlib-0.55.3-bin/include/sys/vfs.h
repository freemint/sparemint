#ifdef __TURBOC__
# include <sys\statfs.h>
#else
# include <sys/statfs.h>
#endif
