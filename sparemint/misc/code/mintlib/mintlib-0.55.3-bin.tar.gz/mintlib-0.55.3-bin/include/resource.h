#ifdef _TURBO_C
# include <sys\resource.h>
#else
# include <sys/resource.h>
#endif
