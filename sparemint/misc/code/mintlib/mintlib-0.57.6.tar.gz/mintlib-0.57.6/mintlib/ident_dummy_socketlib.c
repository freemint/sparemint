/* dummy ident string to satifsy extern reference in crt0.o if socketlib is
   not linked
 */
char __Ident_socketlib[1];

