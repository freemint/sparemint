#ifdef __TURBOC__
# include <sys\types.h>
#else
# include <sys/types.h>
#endif

uid_t __uid = 0;
gid_t __gid = 0;

