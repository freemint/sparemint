#include "../stdio/test-wc-printf.c"
