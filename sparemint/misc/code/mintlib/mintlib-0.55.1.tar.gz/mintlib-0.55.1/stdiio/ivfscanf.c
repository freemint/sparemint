#define ONLY_INTEGER_IO
#include "../stdio/vfscanf.c"
