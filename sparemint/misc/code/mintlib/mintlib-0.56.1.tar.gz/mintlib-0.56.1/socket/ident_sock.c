
/* For dependencies only.  */
#include <features.h>


char _Ident_socketlib[] = "$Version: SocketLib: MiNTLib "VERSION" ";
