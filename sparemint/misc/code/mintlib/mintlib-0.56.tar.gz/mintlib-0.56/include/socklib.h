#ifndef _SOCKLIB_H
#define _SOCKLIB_H

#ifdef __GNUC__
__asm__(".globl __Ident_socketlib\n");
#endif

#endif
