#include <features.h>  /* For dependencies only.  */
char _Ident_socketlib[] = "$Version: SocketLib: MiNTLib "VERSION" ";
