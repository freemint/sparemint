
#include <sys/types.h>

ino_t __inode = 32; /* used in readdir, __do_stat, fstat */

