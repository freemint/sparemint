/* leave this as an uninitialized variable, so it goes in the bss */
long _initial_stack;
