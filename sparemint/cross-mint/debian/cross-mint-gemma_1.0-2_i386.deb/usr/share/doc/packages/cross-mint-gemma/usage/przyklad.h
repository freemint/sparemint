/* Resource file indices for PRZYKLAD. */

#define WINDOW           0   /* Form/Dialog-box */
#define WINDOWBACKGROUND 0   /* BOX in tree WINDOW */
#define FORK             1   /* BUTTON in tree WINDOW */
#define EXIT             2   /* BUTTON in tree WINDOW */

#define PNAME            0   /* Free String */

#define WINTITLE         1   /* Free String */
