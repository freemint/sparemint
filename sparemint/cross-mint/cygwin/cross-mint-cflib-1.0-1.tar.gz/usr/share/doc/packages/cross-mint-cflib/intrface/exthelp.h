/* Resource Datei Indizes f�r EXTHELP */

#define HELP_EXTEND      0   /* Formular/Dialog */

#define EXITALERT        0   /* Alert String */
