#include <mint/a.out.h>
