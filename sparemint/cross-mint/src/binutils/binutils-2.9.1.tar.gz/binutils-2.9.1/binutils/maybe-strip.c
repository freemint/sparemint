/* Linked with objcopy.o to flag that this program decides at runtime
   (using argv[0] if it is is 'strip' or 'objcopy'. */

int is_strip = -1;
