
# ifndef _pdlg_h
# define _pdlg_h


extern void test_pdlg (int win);


# endif /* _pdlg_h */
