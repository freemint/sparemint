/* Resource Datei Indizes f�r INLINE */

#define ALERTBOX         0   /* Formular/Dialog */
#define AL_TITLE         1   /* STRING in Baum ALERTBOX */
#define AL_INFO          2   /* IMAGE in Baum ALERTBOX */
#define AL_ACHT          3   /* IMAGE in Baum ALERTBOX */
#define AL_QST           4   /* IMAGE in Baum ALERTBOX */
#define AL_STOP          5   /* IMAGE in Baum ALERTBOX */
#define AL_STR1          6   /* STRING in Baum ALERTBOX */
#define AL_STR2          7   /* STRING in Baum ALERTBOX */
#define AL_STR3          8   /* STRING in Baum ALERTBOX */
#define AL_STR4          9   /* STRING in Baum ALERTBOX */
#define AL_STR5          10  /* STRING in Baum ALERTBOX */
#define AL_BUT1          11  /* BUTTON in Baum ALERTBOX */
#define AL_BUT2          12  /* BUTTON in Baum ALERTBOX */
#define AL_BUT3          13  /* BUTTON in Baum ALERTBOX */

#define ASCIITAB         1   /* Formular/Dialog */
#define AT_TITLE         1   /* STRING in Baum ASCIITAB */
#define AT_BOX           2   /* IBOX in Baum ASCIITAB */
#define AT_DEZ           4   /* TEXT in Baum ASCIITAB */
#define AT_HEX           6   /* TEXT in Baum ASCIITAB */
#define AT_ABBRUCH       7   /* BUTTON in Baum ASCIITAB */

#define BUTTONS          2   /* Formular/Dialog */
#define BT_RADIO         1   /* USERDEF in Baum BUTTONS */
#define BT_CHECK         2   /* USERDEF in Baum BUTTONS */
#define BT_RLOW          3   /* USERDEF in Baum BUTTONS */
#define BT_CLOW          4   /* USERDEF in Baum BUTTONS */
