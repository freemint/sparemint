/* User function prototypes */

long rsrc_xgaddr(BASEPAGE *bp, long fn, short nargs, \
		short type, short obj, PROC_ARRAY *p);

/* EOF */

