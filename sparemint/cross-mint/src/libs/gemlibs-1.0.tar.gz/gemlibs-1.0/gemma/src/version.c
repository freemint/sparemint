/* Version information */

const char Version[] =
{
	"$Gemma shared library version 1.07, "
	"Copyright (c) 1999-2000 Draco/YC "
	"Dedicated with love to Anna A."
};

/* EOF */
