/* Alert module */

long _alert(PROC_ARRAY *p, short button, char *msg);

/* EOF */
