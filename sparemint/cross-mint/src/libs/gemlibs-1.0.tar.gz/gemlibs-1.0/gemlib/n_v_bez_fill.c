/*
 * see n_v_bez.c
 */
