
#include "gemx.h"


long
vqr_fg_color (short handle, COLOR_ENTRY * fg_color)
{
	vdi_control[0] = 202;
	vdi_control[1] = 0;
	vdi_control[3] = 0;
	vdi_control[5] = 4;
	vdi_control[6] = handle;
	vdi (&vdi_params);

	*fg_color = *(COLOR_ENTRY *) & vdi_intout[2];
	return (*(long *) &vdi_intout[0]);
}

/*
 * * NOTE: requires NVDI version 5.x or higher
 */
