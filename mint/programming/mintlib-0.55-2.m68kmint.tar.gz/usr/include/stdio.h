/*
 *
 *	STDIO.H		Standard i/o include file
 *
 */

#ifndef _STDIO_H

/* One of the most annoying inheritances of GEMDOS from MS-DOS was the
   convention that so-called text streams should automatically map
   newline characters to a sequence of carriage return plus newline
   on output and the same sequence back to a single newline on input.
   For compatibility's sake the MiNTLib still supports this stupid
   convention as it's default behavior for streams.
   
   Normally you don't have to worry about all that.  If the user has
   set the environment variable "UNIXMODE" to a value that contains
   the character `b' (not preceded by an `r'!) the MiNTLib will behave
   the standard way, i. e. no translation is performed, all streams
   are "binary" by default.  NOTE: For security reasons this has
   no effect with setuid programs.  These programs will open all
   streams in "binary" mode by default.
   
   You can override the setting in the environment by an explicit 
   call to the function __binmode (see below for a description).
   Calling __binmode is equivalent to setting member "__binary"
   of the internal variable "__default_mode__" but the function
   call is more portable.  All subsequents fopen calls will obey the
   default mode, streams that are already opened (notably the
   standard streams stdin, stdout, and stderr) are not affected.
   
   If you want to control the behavior of one distinct stream you
   should add the qualifier "b" to the mode argument, for example:
   
   	FILE* stream = fopen ("foobar", "rb");
   
   This will ensure that no translation takes place on STREAM.  There
   is no flag with an opposite effect.
   
   In former versions of the MiNTLib you could also change the behavior
   of streams by or'ing the member _flag of the FILE structure with
   the constant _IOBIN (0x4).  Object files that contain such code
   will make the library crash!  One important exception: This will
   still work for the standard streams stdin, stdout, and stderr.
   
   If you can't help to change the behavior of an already opened stream
   you can use the new and completely unportable function __set_binmode
   (see below).  Please consider the behavior of the stream undefined
   until the next call to fflush.  And please also consider the member
   __binary of the __io_mode member of FILE read-only!  Changing the
   flag has no effect!
   
   Of course all that binary/text stuff only applies to streams associated
   to a file and not to memstreams, obstreams or the like.  */
   
#ifndef __need_FILE
# define _STDIO_H 1
# include <features.h>

__BEGIN_DECLS

#define __need_size_t
#define __need_NULL
#include <stddef.h>

#define __need___va_list
#include <stdarg.h>

#endif /* Don't need FILE.  */
#undef __need_FILE

#ifndef __FILE_defined

/* The opaque type of streams.  */
typedef struct __stdio_file FILE;

#define __FILE_defined 1
#endif /* FILE not defined.  */

#ifdef _STDIO_H

/* The type of the soecond argument to `fgetpos' and `fsetpos'.  */
typedef long fpos_t;

#ifndef __THROW
# define __THROW
#endif

/* The mode of I/O, as given in the MODE argument of fopen, etc.  */
typedef struct
{
  unsigned int __read: 1;	/* Open for reading.  */
  unsigned int __write: 1;	/* Open for writing.  */
  unsigned int __append: 1;	/* Open for appending.  */
  unsigned int __binary: 1;	/* Opened binary, read-only! See comment
                                   at the top of this file.  */
  unsigned int __create: 1;	/* Create the file.  */
  unsigned int __exclusive: 1;	/* Error if it already exists.  */
  unsigned int __truncate: 1;	/* Truncate the file on opening.  */
  
  unsigned int __device: 1;	/* Non-zero if this is a device stream
  				   (MiNTLib extension).  */
} __io_mode;

/* If you want a certain default mode for your FILEs you can define
 * this variable in your sources (only the member __binary gets
 * evaluated).
 */
extern __io_mode __default_mode__;

/* Functions to do I/O and file management for a stream.  */

/* Read NBYTES from COOKIE into a buffer pointed to by BUF.
   Return number of bytes read.  */
typedef __SSIZE_TYPEDEF__ __io_read_fn __PROTO((void* __cokie, char* __buf,
				                size_t __nbytes));

/* Write NBYTES pointed to by BUF to COOKIE.  Write all N bytes
   unless there is an error.  Return the number of bytes written, or -1
   if there is an error without writing anything.  If the file has been
   opened for append (__mode.__append set), then set the file pointer
   to the end of the file and then do the write; if not, just write at
   the current file pointer.  */
typedef __SSIZE_TYPEDEF__ __io_write_fn __PROTO ((void* __cookie, 
						  const char* __buf,
					          size_t __nbytes));

/* Move COOKIE's file position to *POS bytes from the
   beginning of the file (if W is SEEK_SET),
   the current position (if W is SEEK_CUR),
   or the end of the file (if W is SEEK_END).
   Set *POS to the new file position.
   Returns zero if successful, nonzero if not.  */
typedef int __io_seek_fn __PROTO ((void* __cookie, fpos_t* __pos, int __w));

/* Close COOKIE.  */
typedef int __io_close_fn __PROTO ((void* __cookie));

/* Return the file descriptor associated with COOKIE,
   or -1 on error.  There need not be any associated file descriptor.  */
typedef int __io_fileno_fn __PROTO ((void* __cookie));

#ifdef __USE_GNU
/* User-visible names for the above.  */
typedef __io_read_fn cookie_read_function_t;
typedef __io_write_fn cookie_write_function_t;
typedef __io_seek_fn cookie_seek_function_t;
typedef __io_close_fn cookie_close_function_t;
typedef __io_fileno_fn cookie_fileno_function_t;
#endif

/* Low level interface, independent of FILE*representation.  */
#if defined __USE_GNU && !defined _LIBC
/* Define the user-visible type, with user-friendly names.  */
typedef struct
{
  __io_read_fn* read;		/* Read bytes.  */
  __io_write_fn* write;		/* Write bytes.  */
  __io_seek_fn* seek;		/* Seek/tell file position.  */
  __io_close_fn* close;		/* Close file.  */
  __io_fileno_fn* fileno;	/* Return file descriptor.  */
} cookie_io_functions_t;
/* This name is still used in the prototypes in this file.  */
typedef cookie_io_functions_t __io_functions;
#else
/* Stick to ANSI-safe names.  */
typedef struct {
  __io_read_fn* __read;		/* Read bytes.  */
  __io_write_fn* __write;	/* Write bytes.  */
  __io_seek_fn* __seek;		/* Seek/tell file position.  */
  __io_close_fn* __close;	/* Close file.  */
  __io_fileno_fn* __fileno;	/* Return file descriptor.  */
} __io_functions;
#endif

/* Higher level interface, dependent on FILE*representation.  */
typedef struct
{
  /* Make room in the input buffer.  */
  int (*__input) __PROTO ((FILE* __stream));
  /* Make room in the output buffer.  */
  void (*__output) __PROTO ((FILE* __stream, int __c));
} __room_functions;

/* These are the functions used for streams associated with a file.
   Streams open in text mode will use "__default_text_io_functions".  */
__EXTERN const __io_functions __default_io_functions;
__EXTERN const __io_functions __default_text_io_functions;
__EXTERN const __room_functions __default_room_functions;

/* Default close function.  */
__EXTERN __io_close_fn __stdio_close;
/* Open FILE*with mode M, store cookie in *COOKIEPTR.  */
__EXTERN int __stdio_open __PROTO ((const char* __file, __io_mode __m,
				    void** __cookieptr));
/* Put an error message for when stdio needs to die.  */
__EXTERN void __stdio_errmsg __PROTO ((const char* __msg, size_t __len));


/* For thread safe I/O functions we need a lock in each stream.  We
   keep the type opaque here.  */
struct __stdio_lock;

/* The FILE*structure.  */
struct __stdio_file
{
  /* Magic number for validation.  Must be negative in open streams
     for the glue to Unix stdio getc/putc to work.
     NOTE: stdio/glue.c has special knowledge of these first four members.  */
#ifdef __MSHORT__
  long __magic;
#else
  int __magic;
#endif
#define _IOMAGIC ((int) 0xfedabeeb)     /* Magic number to file `__magic'.  */
#define _GLUEMAGIC ((int) 0xfeedbabe)   /* Magic for glued Unix streams.  */

  char* __bufp;				/* Pointer into the buffer.  */
  char* __get_limit;			/* Reading limit.  */
  char* __put_limit;			/* Writing limit.  */
  
  char* __buffer;			/* Base of buffer.  */
  size_t __bufsize;			/* Size of the buffer.  */
  void* __cookie;			/* Magic cookie.  */
  __io_mode __mode;			/* File access mode.  */
  __io_functions __io_funcs;		/* I/O functions.  */
  __room_functions __room_funcs;	/* I/O buffer room functions.  */
  fpos_t __offset;			/* Current file position.  */
  fpos_t __target;			/* Target file position.  */
  FILE* __next;				/* Next FILE*in linked list.  */
  char* __pushback_bufp;		/* Old bufp if char pushed back.  */
  unsigned char __pushback;		/* Pushed-back character.  */
  unsigned int __pushed_back:1;		/* A char has been pushed back.  */
  unsigned int __eof:1;			/* End of file encountered.  */
  unsigned int __error:1;		/* Error encountered.  */
  unsigned int __userbuf:1;		/* Buffer from user (should not be 
  					   freed).  */
  unsigned int __linebuf:1;		/* Flush on newline.  */
  unsigned int __linebuf_active:1;	/* put_limit is not really in use.  */
  unsigned int __seen:1;		/* This stream has been seen.  */
  unsigned int __ispipe:1;		/* Nonzero if opened by popen.  */
  struct __stdio_lock* __lock;		/* Pointer to associated lock.  */
};

/* All macros used internally by other macros here and by stdio functions begin
   with `__'.  All of these may evaluate their arguments more than once.  */


/* Nonzero if STREAM is a valid stream.
   STREAM must be a modifiable lvalue (wow, I got to use that term).
   See stdio/glue.c for what the confusing bit is about.  */
#define __validfp(stream)						      \
  (stream != NULL &&							      \
   ({ if (stream->__magic == _GLUEMAGIC)				      \
	stream = *((struct { int __magic; FILE**__p; } *) stream)->__p;      \
      stream->__magic == _IOMAGIC; }))

/* Clear the error and EOF indicators of STREAM.  */
#define	__clearerr(stream)	((stream)->__error = (stream)->__eof = 0)

/* Nuke STREAM, making it unusable but available for reuse.  */
__EXTERN void __invalidate __PROTO ((FILE* __stream));

/* Make sure STREAM->__offset and STREAM->__target are initialized.
   Returns 0 if successful, or EOF on
   error (but doesn't set STREAM->__error).  */
__EXTERN int __stdio_check_offset __PROTO ((FILE* __stream));


/* The possibilities for the third argument to `setvbuf'.  */
#define _IOFBF	0x1		/* Full buffering.  */
#define _IOLBF	0x2		/* Line buffering.  */
#define _IONBF	0x4		/* No buffering.  */


/* Default buffer size.  */
#define	BUFSIZ	1024


/* End of file character.
   Some things throughout the library rely on this being -1.  */
#define	EOF	(-1)


/* The possibilities for the third argument to `fseek'.
   These values should not be changed.  */
#define	SEEK_SET	0	/* Seek from beginning of file.  */
#define	SEEK_CUR	1	/* Seek from current position.  */
#define	SEEK_END	2	/* Seek from end of file.  */


#ifdef	__USE_SVID
#ifdef	__USE_SVID
/* Default path prefix for `tempnam' and `tmpnam'.  */
#define	P_tmpdir	"/usr/tmp"
/* This will be sent to the OS but P_tmpdir will get used if __mint
   is set.  */
#define __ugly_tos_P_tmpdir "\\usr\\tmp"
#endif

#endif


/* Get the values:
   L_tmpnam	How long an array of chars must be to be passed to `tmpnam'.
   TMP_MAX	The minimum number of unique filenames generated by tmpnam
   		(and tempnam when it uses tmpnam's name space),
		or tempnam (the two are separate).
   L_ctermid	How long an array to pass to `ctermid'.
   L_cuserid	How long an array to pass to `cuserid'.
   FOPEN_MAX	Minimum number of files that can be open at once.
   FILENAME_MAX	Maximum length of a filename.  */
#include <bits/stdio_lim.h>


/* All the known streams are in a linked list
   linked by the `next' field of the FILE*structure.  */
__EXTERN FILE* __stdio_head;	/* Head of the list.  */

/* Standard streams.  */
__EXTERN FILE *stdin, *stdout, *stderr;
#ifdef __STRICT_ANSI__
/* ANSI says these are macros; satisfy pedants.  */
#define	stdin	stdin
#define	stdout	stdout
#define	stderr	stderr
#endif


/* Remove file FILENAME.  */
__EXTERN int remove __PROTO ((const char* __filename));
/* Rename file OLD to NEW.  */
__EXTERN int rename __PROTO ((const char* __old, const char* __new));


/* Create a temporary file and open it read/write.  */
__EXTERN FILE*tmpfile __PROTO ((void));
#ifdef __USE_LARGEFILE64
/* This is ugly!  */
#define tmpfile64 tmpfile
#endif
/* Generate a temporary filename.  */
__EXTERN char *tmpnam __PROTO ((char* __s));


#ifdef __USE_REENTRANT
/* This is the reentrant variant of `tmpnam'.  The only difference is
   that it does not allow S to be NULL.  */
__EXTERN char *tmpnam_r __PROTO ((char* __s));
#endif


#if defined __USE_SVID || defined __USE_XOPEN
/* Generate a unique temporary filename using up to five characters of PFX
   if it is not NULL.  The directory to put this file in is searched for
   as follows: First the environment variable "TMPDIR" is checked.
   If it contains the name of a writable directory, that directory is used.
   If not and if DIR is not NULL, that value is checked.  If that fails,
   P_tmpdir is tried and finally "/tmp".  The storage for the filename
   is allocated by `malloc'.  */
__EXTERN char *tempnam __PROTO ((const char* __dir, const char* __pfx));
#endif


/* This performs actual output when necessary, flushing
   STREAM's buffer and optionally writing another character.  */
__EXTERN int __flshfp __PROTO ((FILE* __stream, int __c));


/* Close STREAM.  */
__EXTERN int fclose __PROTO ((FILE* __stream));
/* Flush STREAM, or all streams if STREAM is NULL.  */
__EXTERN int fflush __PROTO ((FILE* __stream));

#ifdef __USE_MISC
/* Faster versions when locking is not required.  */
__EXTERN int fflush_unlocked __PROTO ((FILE* __stream));
#endif

#ifdef __USE_GNU
/* Close all streams.  */
__EXTERN int __fcloseall __PROTO ((void));
__EXTERN int fcloseall __PROTO ((void));
#endif


/* Open a file and create a new stream for it.  */
__EXTERN FILE*fopen __PROTO ((const char* __filename, const char* __modes));
/* Open a file, replacing an existing stream with it. */
__EXTERN FILE*freopen __PROTO ((const char* __filename, const char* __modes,
			        FILE* __stream));

/* Return a new, zeroed, stream.
   You must set its cookie and io_mode.
   The first operation will give it a buffer unless you do.
   It will also give it the default functions unless you set the `seen' flag.
   The offset is set to -1, meaning it will be determined by doing a
   stationary seek.  You can set it to avoid the initial tell call.
   The target is set to -1, meaning it will be set to the offset
   before the target is needed.
   Returns NULL if a stream can't be created.  */
__EXTERN FILE* __newstream __PROTO ((void));

#ifdef	__USE_POSIX
/* Create a new stream that refers to an existing system file descriptor.  */
__EXTERN FILE* __fdopen __PROTO ((int __fd, const char* __modes));
__EXTERN FILE* fdopen __PROTO ((int __fd, const char* __modes));
#endif

#ifdef	__USE_GNU
/* Create a new stream that refers to the given magic cookie,
   and uses the given functions for input and output.  */
__EXTERN FILE *fopencookie __PROTO ((void* __magic_cookie, const char* __modes,
			             __io_functions __io_funcs));

/* Create a new stream that refers to a memory buffer.  */
__EXTERN FILE *fmemopen __PROTO ((void* __s, size_t __len, 
				  const char* __modes));

/* Open a stream that writes into a malloc'd buffer that is expanded as
   necessary.  *BUFLOC and *SIZELOC are updated with the buffer's location
   and the number of characters written on fflush or fclose.  */
__EXTERN FILE* open_memstream __PROTO ((char** __bufloc, size_t* __sizeloc));
#endif


/* If BUF is NULL, make STREAM unbuffered.
   Else make it use buffer BUF, of size BUFSIZ.  */
__EXTERN void setbuf __PROTO ((FILE* __stream, char* __buf));
/* Make STREAM use buffering mode MODE.
   If BUF is not NULL, use N bytes of it for buffering;
   else allocate an internal buffer N bytes long.  */
__EXTERN int setvbuf __PROTO ((FILE* __stream, char* __buf,
			       int __modes, size_t __n));

#ifdef	__USE_BSD
/* If BUF is NULL, make STREAM unbuffered.
   Else make it use SIZE bytes of BUF for buffering.  */
__EXTERN void setbuffer __PROTO ((FILE* __stream, char* __buf, size_t __size));

/* Make STREAM line-buffered.  */
__EXTERN void setlinebuf __PROTO ((FILE* __stream));
#endif


/* Write formatted output to STREAM.  */
__EXTERN int fprintf __PROTO ((FILE* __stream,
			       const char* __format, ...));
/* Write formatted output to stdout.  */
__EXTERN int printf __PROTO ((const char* __format, ...));
/* Write formatted output to S.  */
__EXTERN int sprintf __PROTO ((char* __s, const char* __format, ...));

/* Write formatted output to S from argument list ARG.  */
__EXTERN int vfprintf __PROTO ((FILE* __s, const char* __format,
				__gnuc_va_list __arg));
/* Write formatted output to stdout from argument list ARG.  */
__EXTERN int vprintf __PROTO ((const char* __format, __gnuc_va_list __arg));
/* Write formatted output to S from argument list ARG.  */
__EXTERN int vsprintf __PROTO ((char* __s, const char* __format,
				__gnuc_va_list __arg));

/* Write formatted output to STREAM from argument list ARG using
   fputc like function PUTFUNCTION.  This is provided for binary
   compatibility with older versions.  */
__EXTERN int _doprnt __PROTO((int (*__putfunction) (int, FILE*), 
			      FILE* __stream, const char* __format, 
			      __gnuc_va_list __arg));

#ifdef	__OPTIMIZE__
extern __inline int
vprintf (const char* __fmt, __gnuc_va_list __arg) __THROW
{
  return vfprintf (stdout, __fmt, __arg);
}
#endif /* Optimizing.  */

#if defined __USE_BSD || defined __USE_ISOC9X
/* Maximum chars of output to write in MAXLEN.  */
__EXTERN int __snprintf __PROTO ((char* __s, size_t __maxlen,
			    	  const char* __format, ...))
     __attribute__ ((__format__ (__printf__, 3, 4)));
__EXTERN int snprintf __PROTO ((char* __s, size_t __maxlen,
			  const char* __format, ...))
     __attribute__ ((__format__ (__printf__, 3, 4)));

__EXTERN int __vsnprintf __PROTO ((char* __s, size_t __maxlen,
			     const char* __format, __gnuc_va_list __arg))
     __attribute__ ((__format__ (__printf__, 3, 0)));
__EXTERN int vsnprintf __PROTO ((char* __s, size_t __maxlen,
			   const char* __format, __gnuc_va_list __arg))
     __attribute__ ((__format__ (__printf__, 3, 0)));
#endif

#ifdef __USE_GNU
/* Write formatted output to a string dynamically allocated with `malloc'.
   Store the address of the string in *PTR.  */
__EXTERN int vasprintf __PROTO ((char** __ptr,
				 const char* __f, __gnuc_va_list __arg))
     __attribute__ ((__format__ (__printf__, 2, 0)));
__EXTERN int __asprintf __PROTO ((char** __ptr, const char* __fmt, ...))
     __attribute__ ((__format__ (__printf__, 2, 3)));
__EXTERN int asprintf __PROTO ((char** __ptr, const char* __fmt, ...))
     __attribute__ ((__format__ (__printf__, 2, 3)));

/* Write formatted output to a file descriptor.  */
__EXTERN int vdprintf __PROTO ((int __fd, const char* __fmt, 
				__gnuc_va_list __arg))
     __attribute__ ((__format__ (__printf__, 2, 0)));
__EXTERN int dprintf __PROTO ((int __fd, const char* __fmt, ...))
     __attribute__ ((__format__ (__printf__, 2, 3)));
#endif


/* Read formatted input from STREAM.  */
__EXTERN int fscanf __PROTO ((FILE* __stream, const char* __format, ...));
/* Read formatted input from stdin.  */
__EXTERN int scanf __PROTO ((const char* __format, ...));
/* Read formatted input from S.  */
__EXTERN int sscanf __PROTO ((const char* __s, const char* __format, ...));

#ifdef	__USE_ISOC9X
/* Read formatted input from S into argument list ARG.  */
__EXTERN int __vfscanf __PROTO ((FILE* __s, const char* __format,
			   __gnuc_va_list __arg));
__EXTERN int vfscanf __PROTO ((FILE* __s, const char* __format,
			 __gnuc_va_list __arg));

/* Read formatted input from stdin into argument list ARG.  */
__EXTERN int __vscanf __PROTO ((const char* __format, __gnuc_va_list __arg));
__EXTERN int vscanf __PROTO ((const char* __format, __gnuc_va_list __arg));

/* Read formatted input from S into argument list ARG.  */
__EXTERN int __vsscanf __PROTO ((const char* __s, const char* __format,
				__gnuc_va_list __arg));
__EXTERN int vsscanf __PROTO ((const char* __s, const char* __format,
			       __gnuc_va_list __arg));


#ifdef	__OPTIMIZE__
extern __inline int
vfscanf (FILE* __s, const char* __fmt, __gnuc_va_list __arg) __THROW
{
  return __vfscanf (__s, __fmt, __arg);
}
extern __inline int
vscanf (const char* __fmt, __gnuc_va_list __arg) __THROW
{
  return __vfscanf (stdin, __fmt, __arg);
}
extern __inline int
vsscanf (const char* __s, const char* __fmt, __gnuc_va_list __arg) __THROW
{
  return __vsscanf (__s, __fmt, __arg);
}
#endif /* Optimizing.  */
#endif /* Use ISO C9x.  */


/* This does actual reading when necessary, filling STREAM's
   buffer and returning the first character in it.  */
__EXTERN int __fillbf __PROTO ((FILE* __stream));


/* Read a character from STREAM.  */
__EXTERN int fgetc __PROTO ((FILE* __stream));
__EXTERN int getc __PROTO ((FILE* __stream));

/* Read a character from stdin.  */
__EXTERN int getchar __PROTO ((void));

/* The C standard explicitly says this can
   re-evaluate its argument, so it does. */
#define	__getc(stream)							      \
  ((stream)->__bufp < (stream)->__get_limit ?				      \
   (int) ((unsigned char) *(stream)->__bufp++) : __fillbf(stream))

/* The C standard explicitly says this is a macro,
   so we always do the optimization for it.  */
#define	getc(stream)	__getc(stream)

#ifdef	__OPTIMIZE__
extern __inline int
getchar (void) __THROW
{
  return __getc (stdin);
}
#endif /* Optimizing.  */

#if defined __USE_POSIX || defined __USE_MISC
/* These are defined in POSIX.1:1996.  */
__EXTERN int getc_unlocked __PROTO ((FILE* __stream));
__EXTERN int getchar_unlocked __PROTO ((void));

# ifdef __OPTIMIZE__
extern __inline int
getc_unlocked (FILE* __stream) __THROW
{
  return __getc (__stream);
}

extern __inline int
getchar_unlocked (void) __THROW
{
  return __getc (stdin);
}
# endif /* Optimizing.  */
#endif /* Use POSIX or MISC.  */


/* Write a character to STREAM.  */
__EXTERN int fputc __PROTO ((int __c, FILE* __stream));
__EXTERN int putc __PROTO ((int __c, FILE* __stream));

/* Write a character to stdout.  */
__EXTERN int putchar __PROTO ((int __c));


/* The C standard explicitly says this can
   re-evaluate its arguments, so it does.  */
#define	__putc(c, stream)						      \
  ((stream)->__bufp < (stream)->__put_limit ?				      \
   (int) (unsigned char) (*(stream)->__bufp++ = (unsigned char) (c)) :	      \
   __flshfp ((stream), (unsigned char) (c)))

/* The C standard explicitly says this can be a macro,
   so we always do the optimization for it.  */
#define	putc(c, stream)	__putc ((c), (stream))

#ifdef __OPTIMIZE__
extern __inline int
putchar (int __c) __THROW
{
  return __putc (__c, stdout);
}
#endif

#ifdef __USE_MISC
/* Faster version when locking is not necessary.  */
__EXTERN int fputc_unlocked __PROTO ((int __c, FILE* __stream));

# ifdef __OPTIMIZE__
extern __inline int
fputc_unlocked (int __c, FILE* __stream) __THROW
{
  return __putc (__c, __stream);
}
# endif /* Optimizing.  */
#endif /* Use MISC.  */

#if defined __USE_POSIX || defined __USE_MISC
/* These are defined in POSIX.1:1996.  */
__EXTERN int putc_unlocked __PROTO ((int __c, FILE* __stream));
__EXTERN int putchar_unlocked __PROTO ((int __c));

# ifdef __OPTIMIZE__
extern __inline int
putc_unlocked (int __c, FILE* __stream) __THROW
{
  return __putc (__c, __stream);
}

extern __inline int
putchar_unlocked (int __c) __THROW
{
  return __putc (__c, stdout);
}
# endif /* Optimizing.  */
#endif /* Use POSIX or MISC.  */


#if defined __USE_SVID || defined __USE_MISC
/* Get a word (int) from STREAM.  */
__EXTERN int getw __PROTO ((FILE* __stream));

/* Write a word (int) to STREAM.  */
__EXTERN int putw __PROTO ((int __w, FILE* __stream));
#endif


/* Get a newline-terminated string of finite length from STREAM.  */
__EXTERN char* fgets __PROTO ((char* __s, int __n, FILE* __stream));

#ifdef __USE_GNU
/* This function does the same as `fgets' but does not lock the stream.  */
__EXTERN char* fgets_unlocked __PROTO ((char* __s, int __n, FILE* __stream));
#endif

/* Get a newline-terminated string from stdin, removing the newline.
   DO NOT USE THIS FUNCTION!!  There is no limit on how much it will read.  */
__EXTERN char *gets __PROTO ((char* __s));


#ifdef	__USE_GNU
#include <sys/types.h>

/* Read up to (and including) a DELIMITER from STREAM into *LINEPTR
   (and null-terminate it). *LINEPTR is a pointer returned from malloc (or
   NULL), pointing to *N characters of space.  It is realloc'd as
   necessary.  Returns the number of characters read (not including the
   null terminator), or -1 on error or EOF.  */
ssize_t __getdelim __PROTO ((char** __lineptr, size_t* __n, int __delimiter, 
			     FILE* __stream));
ssize_t getdelim __PROTO ((char** __lineptr, size_t* __n, int __delimiter, 
			   FILE* __stream));

/* Like `getdelim', but reads up to a newline.  */
ssize_t __getline __PROTO ((char** __lineptr, size_t* __n, FILE* __stream));
ssize_t getline __PROTO ((char** __lineptr, size_t* __n, FILE* __stream));

#ifdef	__OPTIMIZE__
extern __inline ssize_t
getline (char** __lineptr, size_t* __n, FILE* __stream) __THROW
{
  return __getdelim (__lineptr, __n, '\n', __stream);
}
#endif /* Optimizing.  */
#endif


/* Write a string to STREAM.  */
__EXTERN int fputs __PROTO ((const char* __s,
		       FILE* __stream));

#ifdef __USE_GNU
/* This function does the same as `fputs' but does not lock the stream.  */
__EXTERN int fputs_unlocked __PROTO ((const char* __s,
				FILE* __stream));
#endif

/* Write a string, followed by a newline, to stdout.  */
__EXTERN int puts __PROTO ((const char* __s));


/* Push a character back onto the input buffer of STREAM.  */
__EXTERN int ungetc __PROTO ((int __c, FILE* __stream));


/* Read chunks of generic data from STREAM.  */
__EXTERN size_t fread __PROTO ((void*  __ptr, size_t __size,
			  size_t __n, FILE* __stream));
/* Write chunks of generic data to STREAM.  */
__EXTERN size_t fwrite __PROTO ((const void* __ptr, size_t __size,
			   size_t __n, FILE* __s));

#ifdef __USE_MISC
/* Faster versions when locking is not necessary.  */
__EXTERN size_t fread_unlocked __PROTO ((void* __ptr, size_t __size,
				   	 size_t __n, FILE* __stream));
__EXTERN size_t fwrite_unlocked __PROTO ((const void* __ptr,
				    	  size_t __size, size_t __n,
				    	  FILE* __stream));
#endif


/* Seek to a certain position on STREAM.  */
__EXTERN int fseek __PROTO ((FILE* __stream, long int __off, int __whence));
/* Return the current position of STREAM.  */
__EXTERN long int ftell __PROTO ((FILE* __stream));
/* Rewind to the beginning of STREAM.  */
__EXTERN void rewind __PROTO ((FILE* __stream));

/* Get STREAM's position.  */
__EXTERN int fgetpos __PROTO ((FILE* __stream, fpos_t * __pos));
/* Set STREAM's position.  */
__EXTERN int fsetpos __PROTO ((FILE* __stream, const fpos_t *__pos));


/* Clear the error and EOF indicators for STREAM.  */
__EXTERN void clearerr __PROTO ((FILE* __stream));
/* Return the EOF indicator for STREAM.  */
__EXTERN int feof __PROTO ((FILE* __stream));
/* Return the error indicator for STREAM.  */
__EXTERN int ferror __PROTO ((FILE* __stream));

#ifdef	__OPTIMIZE__
#define	feof(stream)	((stream)->__eof != 0)
#define	ferror(stream)	((stream)->__error != 0)
#endif /* Optimizing.  */

#ifdef __USE_MISC
/* Faster versions when locking is not required.  */
__EXTERN void clearerr_unlocked __PROTO ((FILE* __stream));
__EXTERN int feof_unlocked __PROTO ((FILE* __stream));
__EXTERN int ferror_unlocked __PROTO ((FILE* __stream));

# ifdef	__OPTIMIZE__
#  define feof_unlocked(stream)		((stream)->__eof != 0)
#  define ferror_unlocked(stream)	((stream)->__error != 0)
# endif /* Optimizing.  */
#endif

/* Print a message describing the meaning of the value of errno.  */
__EXTERN void perror __PROTO ((const char* __s));


/* These variables normally should not be used directly.  The `strerror'
   function provides all the needed functionality.  */
#ifdef	__USE_BSD
extern int sys_nerr;
extern __const char *__const sys_errlist[];
#endif
#ifdef	__USE_GNU
extern int _sys_nerr;
extern __const char *__const _sys_errlist[];
#endif

#ifdef	__USE_POSIX
/* Return the system file descriptor for STREAM.  */
__EXTERN int fileno __PROTO ((FILE* __stream));
#endif /* Use POSIX.  */

#ifdef __USE_MISC
/* Faster version when locking is not required.  */
__EXTERN int fileno_unlocked __PROTO ((FILE* __stream));
#endif


#if (defined __USE_POSIX2 || defined __USE_SVID || defined __USE_BSD || \
     defined __USE_MISC)
/* Create a new stream connected to a pipe running the given command.  */
__EXTERN FILE *popen __PROTO ((const char* __command, const char* __modes));

/* Close a stream opened by popen and return the status of its child.  */
__EXTERN int pclose __PROTO ((FILE* __stream));
#endif


#ifdef	__USE_POSIX
/* Return the name of the controlling terminal.  */
__EXTERN char* ctermid __PROTO ((char* __s));
#endif


#ifdef __USE_XOPEN
/* Return the name of the current user.  */
__EXTERN char* cuserid __PROTO ((char* __s));
#endif


#ifdef	__USE_GNU
struct obstack;			/* See <obstack.h>.  */

/* Open a stream that writes to OBSTACK.  */
__EXTERN FILE* open_obstack_stream __PROTO ((struct obstack *__obstack));

/* Write formatted output to an obstack.  */
__EXTERN int obstack_printf __PROTO ((struct obstack *__obstack,
				      const char* __format, ...));
__EXTERN int obstack_vprintf __PROTO ((struct obstack *__obstack,
				       const char* __format,
				       __gnuc_va_list __args));
#endif


#if defined __USE_POSIX || defined __USE_MISC
/* These are defined in POSIX.1:1996.  */

/* Acquire ownership of STREAM.  */
__EXTERN void flockfile __PROTO ((FILE* __stream));

/* Try to acquire ownership of STREAM but do not block if it is not
   possible.  */
__EXTERN int ftrylockfile __PROTO ((FILE* __stream));

/* Relinquish the ownership granted for STREAM.  */
__EXTERN void funlockfile __PROTO ((FILE* __stream));
#endif /* POSIX || misc */

#if defined __USE_XOPEN && !defined __USE_GNU
/* The X/Open standard requires some functions and variables to be
   declared here which do not belong into this header.  But we have to
   follow.  In GNU mode we don't do this nonsense.  */
# define __need_getopt
# include <getopt.h>
#endif


#if defined(__USE_SVID) || defined(__USE_XOPEN)
/* Generate a unique temporary filename using up to five characters of PFX
   if it is not NULL.  The directory to put this file in is searched for
   as follows: First the environment variable "TMPDIR" is checked.
   If it contains the name of a writable directory, that directory is used.
   If not and if DIR is not NULL, that value is checked.  If that fails,
   P_tmpdir is tried, then "/tmp", then the envariable "TEMPDIR", then
   the envariable "TMP", then "TEMP" and finally ".".  The storage for the 
   filename is allocated by `malloc'.  */
__EXTERN char* tempnam __PROTO ((const char* __dir, const char* __pfx));
#endif

/* Calling __binmode with a non-zero argument will cause the library
   to open all streams in binary mode.  Calling it with a zero argument
   has the opposite effect, i. e. all files are opened in text mode.  */
__EXTERN void __binmode __PROTO ((int));
/* This is the same as __binmode, left here for compatibility reasons.  */
__EXTERN void _binmode __PROTO((int));

/* Set or unset the binary flag on an open stream.  This has only an effect
   if the stream is associated with a file.  If you use this function on
   a stream open for reading you should first fflush it because the
   stream's buffer contents will be left unchanged by this function.  */
__EXTERN void __set_binmode __PROTO ((FILE* __stream, int __binary));

# ifdef __USE_MINTLIB
__EXTERN FILE*	fopenp	__PROTO((const char* , const char*));
__EXTERN int 	fungetc	__PROTO((int, FILE*));
__EXTERN long 	getl	__PROTO((FILE*));
__EXTERN long 	putl	__PROTO((long, FILE*));
__EXTERN void	_getbuf	__PROTO((FILE*));
# endif /* __USE_MINTLIB */

/* Print out MESSAGE on stderr and abort.  */
__EXTERN void __libc_fatal __PROTO ((const char* __message));

__END_DECLS

#endif /* <stdio.h> included.  */

#endif /* stdio.h  */

