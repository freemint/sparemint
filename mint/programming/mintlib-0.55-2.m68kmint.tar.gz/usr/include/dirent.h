#ifdef __TURBOC__
# include <sys\dirent.h>
#else
# include <sys/dirent.h>
#endif
