**** Arrow keys
Key_up		= $48
Key_down	= $50
Key_left	= $4b
Key_right	= $4d
Key_leftctrl	= $73
Key_rightctrl	= $74

Key_clrhom	= $47
Key_clrhomctrl	= $77

**** Function keys
Key_f1		= $3b
Key_f2		= $3c
Key_f3		= $3d
Key_f4		= $3e
Key_f5		= $3f
Key_f6		= $40
Key_f7		= $41
Key_f8		= $42
Key_f9		= $43
Key_f10		= $44

Key_f11		= $54
Key_f12		= $55
Key_f13		= $56
Key_f14		= $57
Key_f15		= $58
Key_f16		= $59
Key_f17		= $5a
Key_f18		= $5b
Key_f19		= $5c
Key_f20		= $5d

Asc_esc		= $1b
Key_esc		= $01

Asc_tab		= $09
Key_tab		= $0f

Asc_lf		= 10
Asc_cr		= 13

Asc_bksp	= 8
Key_bksp	= $e
Asc_del		= $7f
Key_del		= $53

Asc_ctrl_a	= $1
Asc_ctrl_b	= $2
Asc_ctrl_c	= $3
Asc_ctrl_d	= $4
Asc_ctrl_e	= $5
Asc_ctrl_f	= $6
Asc_ctrl_g	= $7
Asc_ctrl_h	= $8
Asc_ctrl_i	= $9
Asc_ctrl_j	= $a
Asc_ctrl_k	= $b
Asc_ctrl_l	= $c
Asc_ctrl_m	= $d
Asc_ctrl_n	= $e
Asc_ctrl_o	= $f
Asc_ctrl_p	= $10
Asc_ctrl_q	= $11
Asc_ctrl_r	= $12
Asc_ctrl_s	= $13
Asc_ctrl_t	= $14
Asc_ctrl_u	= $15
Asc_ctrl_v	= $16
Asc_ctrl_w	= $17
Asc_ctrl_x	= $18
Asc_ctrl_y	= $19
Asc_ctrl_z	= $1a

Asc_ctrl_1	= $11
Asc_ctrl_2	= $0
Asc_ctrl_3	= $13
Asc_ctrl_4	= $14
Asc_ctrl_5	= $15
Asc_ctrl_6	= $1e
Asc_ctrl_7	= $17
Asc_ctrl_8	= $18
Asc_ctrl_9	= $19
Asc_ctrl_0	= $10
