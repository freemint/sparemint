#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <osbind.h>
#include <mintbind.h>
#include "gs_descr.h"

void usage(const char *prgname)
{
  fprintf(stderr,
	  "usage: %s [debug-level] \"line of text\"\n\n"
	  "Simulated debug level for log entry:\n"
	  "  1   Fatal system error\n"
	  "  2   STiK error\n"
	  "  3   STiK function entry/exit\n"
	  "  4   Tracing information\n",
	  prgname);
  exit(1);
}

int main(int argc, char *argv[])
{
  long lev;
  long fd;
  union GS_cmd cmd;
  char line[512];

  if (argc != 3)
    usage(argv[0]);

  lev = strtol(argv[1], NULL, 10);
  if (lev == 0 && strcmp(argv[1], "0") != 0)
    usage(argv[0]);
  if (lev < DBG_FATAL || lev > DBG_TRACE)
    usage(argv[0]);
  sprintf(line, "%s\r\n", argv[2]);

  fd = Fopen(GSDEV_NAME, 0);
  if (fd < 0) {
    fprintf(stderr, "Unable to open GlueSTiK socket device:  error %ld\n", fd);
    return 1;
  }

  cmd.log_entry_cmd.cmd = LOGENTRY_CMD;
  cmd.log_entry_cmd.pid = Pgetpid();
  cmd.log_entry_cmd.lev = lev;
  cmd.log_entry_cmd.line = line;
  Fcntl((int)fd, (long)&cmd, GLUESTIK_CMD);

  Fclose(fd);
  return 0;
}
