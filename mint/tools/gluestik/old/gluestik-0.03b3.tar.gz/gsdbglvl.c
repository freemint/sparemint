#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <osbind.h>
#include <mintbind.h>
#include "gs_descr.h"

void usage(const char *prgname)
{
  fprintf(stderr,
	  "usage: %s [debug-level]\n\n"
	  "Allowed debug levels:\n"
	  "  0   No information reported\n"
	  "  1   Report fatal system errors\n"
	  "  2   Report as (1) plus STiK errors\n"
	  "  3   Report as (2) plus STiK function entry and exit\n"
	  "  4   Report as (3) plus tracing information\n",
	  prgname);
  exit(1);
}

int main(int argc, char *argv[])
{
  long lev;
  long fd;

  if (argc > 2)
    usage(argv[0]);

  if (argc == 2) {
    lev = strtol(argv[1], NULL, 10);
    if (lev == 0 && strcmp(argv[1], "0") != 0)
      usage(argv[0]);
    if (lev < 0 || lev > DBG_TRACE)
      usage(argv[0]);
  }

  fd = Fopen(GSDEV_NAME, 0);
  if (fd < 0) {
    fprintf(stderr, "Unable to open GlueSTiK socket device:  error %ld\n", fd);
    return 1;
  }

  if (argc == 2) {
    Fcntl((int)fd, lev, SETDBGLVL_CMD);
    lev = Fcntl((int)fd, 0L, GETDBGLVL_CMD);
    printf("GlueSTiK debug level set to %ld\n", lev);
  } else {
    lev = Fcntl((int)fd, 0L, GETDBGLVL_CMD);
    printf("GlueSTiK debug level is %ld\n", lev);
  }

  Fclose(fd);
  return 0;
}
