/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

/* header file for dealing with the cookie jar */

#ifndef _COOKIE_H
#define _COOKIE_H

struct cookie {
	long tag;
	long value;
};

typedef struct cookie COOKIE;

#define CJAR	   ((COOKIE **) 0x5a0)


/* List of currently available tag values */

#define  COOKIE_MiNT 		0x4d694e54L	/* 'MiNT' */
#define  COOKIE_STiK 		0x5354694bL	/* 'STiK' */

#endif /* _COOKIE_H */
