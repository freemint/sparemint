#include <basepage.h>
#include <stdarg.h>
typedef BASEPAGE BASPAG;	/* What's in a name?... */
#include "file.h"
#include "portab.h"
#include "transprt.h"

#define GS_VERSION	"0.03b3"


struct GS {
  CIB cib;			/* information needed by STiK */
  short sock_fd;		/* The real socket */
  unsigned short flags;		/* What condition are we in? */
#define GS_LISTENING	0x01	/* unconnected listen port */
#if 0
#define GS_PEND_OPEN	0x02	/* waiting for connect() to complete */
#endif
#define GS_NOSOCKET	0x04	/* no socket on this connection */
};

union GS_cmd {
  struct { int cmd; } cmd;
  struct { int cmd; int32 size; } KRmalloc_cmd;
  struct { int cmd; void *mem; } KRfree_cmd;
  struct { int cmd; int16 flag; } KRgetfree_cmd;
  struct { int cmd; void *mem; int32 newsize; } KRrealloc_cmd;
  struct { int cmd; char *var; } getvstr_cmd;
  struct { int cmd; uint32 rhost; int16 rport; uint32 lhost; int16 lport; }
    TCP_open_cmd;
  struct { int cmd; int16 timeout; } TCP_wait_state_cmd;
  struct { int cmd; uint32 rhost; int16 rport; } UDP_open_cmd;
  struct { int cmd; char *vs; char *value; } setvstr_cmd;
  struct { int cmd; char *buffer; int16 len; char delim; } CNgets_cmd;
  struct { int cmd; int pid; int lev; const char *line; } log_entry_cmd;
  struct { int cmd; int lev; } set_dbglvl_cmd;
  struct { int cmd; int16 err; } get_err_text_cmd;
};

struct GS_resolve_cmd {
  char *dn;
  char **rdn;
  uint32 *alist;
  int16 lsize;
};
 
/* struct for Pmsg() */
typedef struct {
  long userlong1;
  long userlong2;
  short pid;
} PMSG;

extern char gsdev_name[];
#define GSDEV_NAME	"u:\\dev\\gluestik"

/* GlueSTiK command codes */
#define GLUESTIK_CMD	(('G' << 8) | 1)	/* GlueSTiK command ioctl */
#define KRMALLOC_CMD	(('G' << 8) | 2)
#define KRFREE_CMD	(('G' << 8) | 3)
#define KRGETFREE_CMD	(('G' << 8) | 4)
#define KRREALLOC_CMD	(('G' << 8) | 5)
#define GETVSTR_CMD	(('G' << 8) | 6)
#define TCP_OPEN_CMD	(('G' << 8) | 7)
#define TCP_WAIT_CMD	(('G' << 8) | 8)
#define UDP_OPEN_CMD	(('G' << 8) | 9)
#define CNBYTECOUNT_CMD	(('G' << 8) | 10)
#define CNGETNDB_CMD	(('G' << 8) | 11)
#define CNGETINFO_CMD	(('G' << 8) | 12)
#define SETVSTR_CMD	(('G' << 8) | 13)
#define CNGETS_CMD	(('G' << 8) | 14)
#define GETERRTXT_CMD	(('G' << 8) | 15)

/* GlueSTiK internal access codes */
#define LOGENTRY_CMD	(('G' << 8) | 128)
#define GETDBGLVL_CMD	(('G' << 8) | 129)
#define SETDBGLVL_CMD	(('G' << 8) | 130)

/* Assorted cookie-ish values */
#define FLG_SEM		0x4753464CUL	/* 'GSFL' */
#define RESOLV_MBX	0x4753524DUL	/* 'GSRM' */

/* From gsdebug.c */
extern int init_debug(void);
extern void cleanup_debug(void);
extern void log_entry_raw(int, int, const char *);
extern void log_entry(int, const char *, ...);
extern int debug_level;
#define LOG             (!debug_level)?((void)0):log_entry
#define DBG_NOMSG       0
#define DBG_FATAL       1
#define DBG_ERROR       2
#define DBG_SYSCALL     3
#define DBG_TRACE       4

/* From gsdev.c */
extern long gssock_read(FILEPTR *, char *, long);

/* From gsutil.c */
extern struct GS *gs_create(void);
extern void gs_release(struct GS *);
extern int gs_xlate_error(int, const char *);
extern int gs_accept(struct GS *);
extern int gs_establish(struct GS *);
extern long gs_connect(FILEPTR *, union GS_cmd *);
extern long gs_listen(FILEPTR *, union GS_cmd *);
extern long gs_udp_open(FILEPTR *, union GS_cmd *);
extern long gs_wait(FILEPTR *, int);
extern long gs_canread(FILEPTR *);
extern long gs_read_delim(FILEPTR *, union GS_cmd *);
extern long gs_readndb(FILEPTR *);
extern long gs_resolve(char *, char **, uint32 *, int16);

/* From gsmem.c */
extern void *gs_mem_alloc(int32);
extern void gs_mem_free(void *);
extern int32 gs_mem_getfree(int16);
extern void *gs_mem_realloc(void *, int32);
extern int init_mem(void);
extern void cleanup_mem(void);

/* From gsconfig.c */
extern char *gs_getvstr(char *);
extern long gs_setvstr(char *, char *);
extern int load_config_file(void);
extern void cleanup_config(void);

/* From gsstikif.c */
extern char *do_get_err_text(int16);
extern int init_stik_if(void);
extern void cleanup_stik_if(void);

/* From gslogfmt.c */
extern void log_entry_fmt(char *, const char *, va_list);
