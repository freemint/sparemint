/*
 *	File for keeping version information.
 *
 *	11/12/93, kay roemer.
 */

# ifndef _version_h
# define _version_h


# define VER_MAJOR	1
# define VER_MINOR	4
# define VER_PL		0
# define VER_STATUS	"interim"

# if 0
# define ALPHA
# endif

# if 0
# define BETA
# endif


# endif /* _version_h */
