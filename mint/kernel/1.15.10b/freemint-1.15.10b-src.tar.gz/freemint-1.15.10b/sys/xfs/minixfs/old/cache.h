
# ifndef _cache_h
# define _cache_h

# include "minix.h"

void	l_sync		(void);

# endif /* _cache_h */
