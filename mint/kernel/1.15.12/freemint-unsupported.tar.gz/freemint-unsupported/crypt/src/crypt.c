/* Crypt! 1.2, C version
 *
 * (c) 2000 Draco/YC, draco@atari.org
 *
 */

/*  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

# include <errno.h>
# include <string.h>
# include <mintbind.h>
# include <mint/ssystem.h>

# include <gemma/gemma.h>

# include "crypt.h"

# define ASTERISK 0x662a
# define bell()	Cconout(7)

static short passwdlen;		/* Length of the password field (constans) */
static short cursorpos;		/* Current cursor position in editbuf[] */
static char editbuf[32];	/* Password edition buffer */

/* Handler for messages external to the library */

static long
newmsg(WINDIAL *wd, short vec, short *msg)
{
	if (msg[0] == AP_TERM)
		windial_longjmp(wd, vec);	/* never returns */
	return 0;
}

/* Handler for keystrokes external to the library
 *
 * return  0: continue processing
 * return <0: abort processing
 * return >0: substitute keycode and continue processing
 *
 */

static long
newkey(WINDIAL *wd, short vec, short keystate, short keycode)
{
	if (keycode <= 0)
		return -1;
	keycode &= 0x007f;
	if (keycode == 0x0011)			/* 0x0011 = Ctrl/Q */
		windial_longjmp(wd, vec);	/* never returns */
	switch(keycode)
	{
		case	0x0008:
				if (cursorpos)
					editbuf[--cursorpos] = '\0';
				/* fall sru */
		case	0x000d:
		case	0x000a:
				return 0;
		case	0x001b:
				cursorpos = 0;
				editbuf[0] = 0;
				return 0;
		case	0x007f:
				return -1;
	}

	if (keycode >= 0x0020) {
		if (cursorpos < passwdlen) {
			editbuf[cursorpos++] = (char)keycode;
			editbuf[cursorpos] = '\0';
			return ASTERISK;
		}
	}

	return -1;	/* ignore the rest */
}

/* Few utils */

/* `flag' tells thou whether to redraw the object being updated */

static void
disable(WINDIAL *wd, short obj, short flag)
{
	OBJECT *ob = (OBJECT *)wd->wb_treeptr;

	ob[obj].ob_flags &= ~(OF_SELECTABLE|OF_EXIT|OF_RBUTTON|OF_TOUCHEXIT);
	if (flag)
		objc_xchange(wd, obj, OS_DISABLED, 1);
	else
		ob[obj].ob_state |= OS_DISABLED;
}

static void
enable(WINDIAL *wd, short obj, short flag)
{
	OBJECT *ob = wd->wb_treeptr;

	ob[obj].ob_flags |= (OF_SELECTABLE|OF_EXIT);
	if (flag)
		objc_xchange(wd, obj, OS_NORMAL, 1);
	else
		ob[obj].ob_state &= ~OS_DISABLED;
}

static void
deselect(WINDIAL *wd, short obj, short force)
{
	OBJECT *ob = (OBJECT *)wd->wb_treeptr;

	if (force || !(ob[obj].ob_flags & OF_RBUTTON))
		objc_xchange(wd, obj, OS_NORMAL, 1);
}

static void
do_window(WINDIAL *wd)
{
	OBJECT *ob = (OBJECT *)wd->wb_treeptr;
	long r, dmap, drive = 0;
	short m;

	disable(wd, SETPASS, 0);
	disable(wd, RESETPASS, 0);

	passwdlen = strlen(ob[PASSFIELD].ob_spec.tedinfo->te_ptmplt);	/* paranoia */

	dmap = Dsetdrv(Dgetdrv()) >> 2;
	r = DISK_C;
	while(r < DISK_C+30)
	{
		if (!(dmap & 1))
			disable(wd, r, 0);
		dmap >>= 1;
		r++;
	}

	/* Make the window visible */
	windial_open(wd);

	/* These calls below must be done in the same stack context
	 * as windial_formdo(). AP_TERM messages and Ctrl/Q actions
	 * that have happened until now, were harmlessly ignored.
	 */
	if (windial_setjmp(wd, 0, newmsg) == 1)
		return;
	if (windial_setjmp(wd, 1, newkey) == 1)
		return;

	for(;;)
	{
		m = windial_formdo(wd);
		if (m == -1)
			break;		/* -1 is the closer gadget */

		m &= 0x7fff;
		deselect(wd, m, 0);	/* does not deselect radiobuttons */

		switch(m)
		{
			case	EXIT:
					return;
			case	SETPASS:
					if (editbuf[0] == '\0')
						break;
					r = Dsetkey(0L, drive, editbuf, 0);
					if (r < 0)
						goto some_error;
					enable(wd, RESETPASS, 1);
					av_dir_update(drive);
					break;
			case	RESETPASS:
					r = Dsetkey(0L, drive, "", 0);
					if (r < 0)
						windial_error(r, -1);
					else {
						disable(wd, RESETPASS, 1);
						av_dir_update(drive);
					}
					break;
			case	MYHOMEPAGE:
					open_url(ob[m].ob_spec.tedinfo->te_ptext);
					break;
			default:
					m -= DISK_C;
					if (m < 0 || m >= 30)
						break;
					drive = (long)m + 2;
					enable(wd, SETPASS, 1);
					r = Dsetkey(0L, drive, 0L, 0);
					if (r < 0) {
some_error:					windial_error(r, -1);
						deselect(wd, drive+DISK_C-2, 1);
						disable(wd, SETPASS, 1);
						disable(wd, RESETPASS, 1);
						break;
					}
					if (r == 0)
						disable(wd, RESETPASS, 1);
					else
						enable(wd, RESETPASS, 1);
					break;
		}
	}
}

int
main()
{
	WINDIAL *wd;
	long r;

	/* Load the resource file and set the desk menu name
	 * to the object PNAME (alternatively an address could
	 * be given, but this is more elegant)
	 */
	r = appl_open("crypt.rsc", 0, (char *)PNAME);
	if (r < 0)
		return r;

	r = Ssystem(S_OSFEATURES, 0L, 0L);
	if (r < 0)
		goto error;

	if ((r & 0x04L) == 0)
	{
		bell();
		windial_alert(1, NO_CRYPTO);
		r = -ENOSYS;
		goto bye;
	}

	/* this initializes the entire WINDIAL structure */
	wd = (WINDIAL *)windial_create(0, WINDOW, ICON, PASSFIELD, WINTITLE);

	do_window(wd);		/* do all the stuff */

	/* Clear the password before exiting */
	r = passwdlen;
	while(r)
		editbuf[--r] = '\0';

	windial_close(wd);
	windial_delete(wd);

	return appl_close();

error:
	windial_error(r, -1);
bye:
	appl_close();
	return r;
}

/* EOF */
