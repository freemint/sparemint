/* Resource file indices for CRYPT. */

#define WINDOW           0   /* Form/Dialog-box */
#define DRIVES           1   /* IBOX in tree WINDOW */
#define DISK_C           2   /* BUTTON in tree WINDOW */
#define SETPASS          32  /* BUTTON in tree WINDOW */
#define RESETPASS        33  /* BUTTON in tree WINDOW */
#define EXIT             34  /* BUTTON in tree WINDOW */
#define PASSFIELD        35  /* FTEXT in tree WINDOW */
#define MYHOMEPAGE       38  /* TEXT in tree WINDOW */

#define ICON             1   /* Form/Dialog-box */
#define CHINESE          1   /* ICON in tree ICON */

#define NO_CRYPTO        0   /* Alert-string */

#define WINTITLE         1   /* Free String */

#define PNAME            2   /* Free String */
