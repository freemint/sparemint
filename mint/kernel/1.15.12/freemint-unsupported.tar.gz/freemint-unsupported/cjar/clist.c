/* An example of Cookie Jar access using Ssystem()
 * Lists all present tag ids and corresponding values. Draco, 7.XII.1997.
 * Little fix from Jo Even Skarstein (joska@nuts.edu) 16.III.1998.
 * Updated 18.XI.1999. by Draco, draco@atari.org
 */

#include <stdio.h>
#include <mintbind.h>
#include <ssystem.h>

int main()
{
	unsigned long count = 1;
	unsigned long cjaradr;
	long r = 0;
	unsigned long jarsize, tag_id[2]={0,0}, value;

	printf("\nSimple Cookie Jar lister for MiNT versions " \
		">= 1.15.0\nDone by Draco, Warszawa, 18.XI.1999.\n\n");

	r = Ssystem(-1, 0L, 0L);

	if (r) {
		printf("No kernel support to perform this action.\n");
		return r;
	}

	printf("ID   Hex val   Dec val\n---- --------- -------\n");

	/* Notice the first slot has number 1. Given 0 you'll get the
	   value of the LAST slot (i.e. NULL cookie) */

	while((Ssystem(S_GETCOOKIE, count, &tag_id)) >= 0) {
		count++;
		value = Ssystem(S_GETCOOKIE, tag_id[0], 0L);
		if (tag_id[0] != 0)
			printf("%s $%08lx %10ld\n", (char *)tag_id, \
				value, value);
		else {
			printf("NULL $%08lx %10ld\n", value, value);
			jarsize = value;
		}
	}
	/* Here's an example of obtaining Cookie Jar address */
	cjaradr = Ssystem(S_GETLVAL, 0x000005a0L, 0L);

	printf("\nThe Cookie Jar lives at $%08lx,\nits total size is %ld slots, %ld slots are free.\n\n", cjaradr, jarsize, jarsize-count+1);  
	return r;
}
