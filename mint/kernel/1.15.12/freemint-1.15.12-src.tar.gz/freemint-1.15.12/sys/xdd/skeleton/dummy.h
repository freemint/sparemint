/*
 * $Id: dummy.h,v 1.2.2.1 2001/07/03 21:07:55 fna Exp $
 * 
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

# ifndef _dummy_h
# define _dummy_h

/*
 * your definitions
 */


# endif /* _dummy_h */
