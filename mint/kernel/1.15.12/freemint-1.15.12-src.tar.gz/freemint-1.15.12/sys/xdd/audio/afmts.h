
# ifndef _afmts_h
# define _afmts_h

void *u8copy   (void *, const void *, long);
void *ulawcopy (void *, const void *, long);
void *u16copy  (void *, const void *, long);
void *m16copy  (void *, const void *, long);
void *mu16copy (void *, const void *, long);

# endif /* _afmts_h */
