/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file on other projects without my explicit
 * permission.
 */

/*
 * begin:	1999-02-19
 * last change: 1999-02-19
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 *  
 */

# ifndef _info_h
# define _info_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern ulong MiNT_version;
extern ulong MiNT_date;
extern ulong MiNT_time;

extern char COMPILER_NAME [];
extern char COMPILER_OPTS [];
extern char COMPILER_DEFS [];
extern char COMPILER_VERS [];


# endif /* _info_h */
