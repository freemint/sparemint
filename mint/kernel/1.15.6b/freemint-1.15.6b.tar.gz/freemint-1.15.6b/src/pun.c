/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * I copied this file originally from the MinixFS source tree
 * and adapt it to the MiNT sources.
 * 
 * last change:	1998-04-22
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 */

# include "pun.h"


# define PUN_PTR	(*((PUN_INFO **) 0x516L))

PUN_INFO *
get_pun (void)
{
	PUN_INFO *pun = PUN_PTR;
	if (pun)
		if (pun->cookie == 0x41484449L)
			if (pun->cookie_ptr == &(pun->cookie))
				if (pun->version_num >= 0x300)
					return pun;
	return NULL;
}
