/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1999-07-27
 * last change:	1999-07-27
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 * 
 * changes since last version:
 * 
 * 1999-07-27:
 * 
 * initial version; moved from biosfs.c
 * some cleanup
 * 
 * known bugs:
 * 
 * todo:
 * 
 * optimizations to do:
 * 
 */

# include "nullfs.h"


long _cdecl
null_chattr (fcookie *fc, int attrib)
{
	UNUSED (fc);
	UNUSED (attrib);
	
	return EACCES;
}

long _cdecl 
null_chown (fcookie *dir, int uid, int gid)
{
	UNUSED (dir);
	UNUSED (uid);
	UNUSED (gid);
	
	return ENOSYS;
}

long _cdecl 
null_chmode (fcookie *dir, unsigned int mode)
{
	UNUSED (dir);
	UNUSED (mode);
	
	return ENOSYS;
}

long _cdecl
null_mkdir (fcookie *dir, const char *name, unsigned int mode)
{
	UNUSED (dir);
	UNUSED (name);
	UNUSED (mode);
	
	return EACCES;
}

long _cdecl 
null_rmdir (fcookie *dir, const char *name)
{
	UNUSED (dir);
	UNUSED (name);
	
	/* the kernel already checked to see if the file exists */
	return EACCES;
}

long _cdecl
null_creat (fcookie *dir, const char *name, unsigned int mode, int attrib, fcookie *fc)
{
	UNUSED (dir);
	UNUSED (fc);
	UNUSED (name);
	UNUSED (mode);
	UNUSED (attrib);
	
	return EACCES;
}

long _cdecl 
null_remove (fcookie *dir, const char *name)
{
	UNUSED (dir);
	UNUSED (name);
	
	/* the kernel already checked to see if the file exists */
	return EACCES;
}

long _cdecl 
null_rename (fcookie *olddir, char *oldname, fcookie *newdir, const char *newname)
{
	UNUSED (olddir);
	UNUSED (oldname);
	UNUSED (newdir);
	UNUSED (newname);
	
	return EACCES;
}

long _cdecl 
null_opendir (DIR *dirh, int flags)
{
	UNUSED (flags);
	
	dirh->index = 0;
	return E_OK;
}

long _cdecl 
null_rewinddir (DIR *dirh)
{
	dirh->index = 0;
	return E_OK;
}

long _cdecl 
null_closedir (DIR *dirh)
{
	UNUSED (dirh);
	return E_OK;
}

long _cdecl
null_fscntl (fcookie *dir, const char *name, int cmd, long arg)
{
	UNUSED (dir);
	UNUSED (name);
	UNUSED (cmd);
	UNUSED (arg);
	
	return ENOSYS;
}

long _cdecl
null_symlink (fcookie *dir, const char *name, const char *to)
{
	UNUSED (dir);
	UNUSED (name);
	UNUSED (to);
	
	return ENOSYS;
}

long _cdecl
null_readlink (fcookie *dir, char *buf, int buflen)
{
	UNUSED (dir);
	UNUSED (buf);
	UNUSED (buflen);
	
	return ENOSYS;
}

long _cdecl
null_hardlink (fcookie *fromdir, const char *fromname, fcookie *todir, const char *toname)
{
	UNUSED (fromdir);
	UNUSED (todir);
	UNUSED (fromname);
	UNUSED (toname);
	
	return ENOSYS;
}

long _cdecl
null_writelabel (fcookie *dir, const char *name)
{
	UNUSED (dir);
	UNUSED (name);
	
	return EACCES;
}

long _cdecl
null_readlabel (fcookie *dir, char *name, int namelen)
{
	UNUSED (dir);
	UNUSED (name);
	UNUSED (namelen);
	
	return ENOENT;
}

long _cdecl
null_dskchng (int drv, int mode)
{
	UNUSED (mode);
	
	return E_OK;
}

long _cdecl
null_mknod (fcookie *dir, const char *name, ulong mode)
{
	UNUSED (dir);
	UNUSED (name);
	UNUSED (mode);
	
	return EACCES;
}
