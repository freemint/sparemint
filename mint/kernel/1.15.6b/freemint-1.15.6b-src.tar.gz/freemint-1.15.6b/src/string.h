/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1998-11-22
 * last change:	1998-
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 */

# ifndef _string_h
# define _string_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


long	_cdecl vsprintf		(char *buf, const char *fmt, va_list args);
long	_cdecl ksprintf		(char *buf, const char *fmt, ...);

long	_cdecl _mint_atol	(const char *s);

extern	uchar  _mint_ctype [];
int	_cdecl _mint_tolower	(int c);
int	_cdecl _mint_toupper	(int c);

long	_cdecl _mint_strlen	(const char *s);

long	_cdecl _mint_strcmp	(const char *str1, const char *str2);
long	_cdecl _mint_strncmp	(const char *str1, const char *str2, long len);

long	_cdecl _mint_stricmp	(const char *str1, const char *str2);
long	_cdecl _mint_strnicmp	(const char *str1, const char *str2, long len);

char *	_cdecl _mint_strcpy	(char *dst, const char *src);
char *	_cdecl _mint_strncpy	(char *dst, const char *src, long len);
void	_cdecl _mint_strncpy_f	(char *dst, const char *src, long len);

char *	_cdecl _mint_strlwr	(char *s);
char *	_cdecl _mint_strupr	(char *s);

char *	_cdecl _mint_strcat	(char *dst, const char *src);
char *	_cdecl _mint_strrchr	(const char *str, long which);
char *	_cdecl _mint_strrev	(char *s);

void *	_cdecl _mint_memchr	(void *s, long search, ulong size);

/* for backward compatibility */
int	_cdecl _mint_o_stricmp	(const char *str1, const char *str2);
int	_cdecl _mint_o_strnicmp	(const char *str1, const char *str2, int len);


# endif /* _string_h */
