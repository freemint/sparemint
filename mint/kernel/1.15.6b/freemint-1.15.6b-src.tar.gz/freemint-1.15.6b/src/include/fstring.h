/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1998-07
 * last change: 1998-11-23
 * 
 * Author: Frank Naumann
 * 
 * fnaumann@cs.uni-magdeburg.de
 * Frank Naumann @ L2
 * 
 * please send suggestions, patches or bug reports to me or the MiNT mailing list
 * 
 */

# ifndef _FSTRING_H
# define _FSTRING_H

# ifdef __TURBOC__
# include "include\misc.h"
# include "include\default.h"
# else
# include "misc.h"
# include "default.h"
# endif


# ifdef __KERNEL__

# ifdef __TURBOC__
# include "include\kctype.h"
# else
# include "kctype.h"
# endif

/*
 * Sigh. Some compilers are too clever for their
 * own good; gcc 2.1 now makes strcpy() and some
 * other string functions built-in; the built-in
 * definitions disagree with ours. So we redefine
 * them here. This also helps us to avoid conflict
 * with any library stuff, in the event that we
 * have to link in a library.
 */

# define atol		_mint_atol

# define _ctype		_mint_ctype
# define toupper	_mint_toupper
# define tolower	_mint_tolower

# define strlen		_mint_strlen

# define strcmp		_mint_strcmp
# define strncmp	_mint_strncmp

# define stricmp	_mint_stricmp
# define strnicmp	_mint_strnicmp

# define strcpy		_mint_strcpy
# define strncpy	_mint_strncpy
# define strncpy_f	_mint_strncpy_f

# define strlwr		_mint_strlwr
# define strupr		_mint_strupr

# define strcat		_mint_strcat
# define strrchr	_mint_strrchr

# define memcpy		quickmovb
# define sleep		_mint_sleep

# else

# include <ctype.h>
# include <string.h>

# endif

/*
 * fast string functions
 * (for use in time critical parts)
 */

# ifdef __KERNEL__
# define _TOUPPER(c)		_mint_ftoupper	(c)
# define _TOLOWER(c)		_mint_ftolower	(c)
# else
# define _TOUPPER(c)		toupper		(c)
# define _TOLOWER(c)		tolower		(c)
# endif

# define _STRLEN(s)		_mint_fstrlen	(s)
# define _STRCMP(s1, s2)	_mint_fstrcmp	(s1, s2)
# define _STRICMP(s1, s2)	_mint_fstricmp	(s1, s2)
# define _STRNCMP(s1, s2, l)	_mint_fstrncmp	(s1, s2, l)
# define _STRNICMP(s1, s2, l)	_mint_fstrnicmp	(s1, s2, l)
# define _STRCPY(d, s)		_mint_fstrcpy	(d, s)
# define _STRNCPY(d, s, l)	_mint_fstrncpy	(d, s, l)
# define _STRNCPY_F(d, s, l)	_mint_fstrncpy_f(d, s, l)
# define _STRLWR(s)		_mint_fstrlwr	(s)
# define _STRUPR(s)		_mint_fstrupr	(s)


# ifdef __KERNEL__
FASTFN int
_mint_ftoupper (register int c)
{
	return (islower (c) ? _toupper (c) : c);
}

FASTFN int
_mint_ftolower (register int c)
{
	return (isupper (c) ? _tolower (c) : c);
}
# endif


FASTFN long
_mint_fstrlen (register const char *scan)
{
	register const char *start = scan + 1;
	
	while (*scan++) ;
	
	return ((long) (scan - start));
}

FASTFN long
_mint_fstrcmp (register const char *str1, register const char *str2)
{
	register char c1, c2;
	
	do {
		c1 = *str1++;
		c2 = *str2++;
	}
	while (c1 && c1 == c2);
	
	return (c1 - c2);
}

FASTFN long
_mint_fstricmp (register const char *str1, register const char *str2)
{
	register char c1, c2;
	
	do {
		c1 = _TOLOWER (*str1); str1++;
		c2 = _TOLOWER (*str2); str2++;
	}
	while (c1 && c1 == c2);
	
	return (c1 - c2);
}

FASTFN long
_mint_fstrncmp (register const char *str1, register const char *str2, register long len)
{
	register char c1, c2;
	
	do {
		c1 = *str1++;
		c2 = *str2++;
	}
	while (--len >= 0 && c1 && c1 == c2);
	
	if (len < 0)
		return 0;
	
	return (c1 - c2);
}

FASTFN long
_mint_fstrnicmp (register const char *str1, register const char *str2, register long len)
{
	register char c1, c2;
	
	do {
		c1 = _TOLOWER (*str1); str1++;
		c2 = _TOLOWER (*str2); str2++;
	}
	while (--len >= 0 && c1 && c1 == c2);
	
	if (len < 0 || c1 == c2)
		return 0;
	
	return (c1 - c2);
}

FASTFN void
_mint_fstrcpy (register char *dst, register const char *src)
{
	while ((*dst++ = *src++) != 0)
		;
}

FASTFN void
_mint_fstrncpy (register char *dst, register const char *src, register long len)
{
	while (--len >= 0 && (*dst++ = *src++) != 0)
		;
}

FASTFN void
_mint_fstrncpy_f (register char *dst, register const char *src, register long len)
{
	while (*src && --len)
		*dst++ = *src++;
	
	*dst = '\0';
}

FASTFN void
_mint_fstrlwr (register char *s)
{
	register char c;
	
	while ((c = *s) != 0)
	{
		*s++ = _TOLOWER (c);
	}
}

FASTFN void
_mint_fstrupr (register char *s)
{
	register char c;
	while ((c = *s) != 0)
	{
		*s++ = _TOUPPER (c);
	}
}

# endif /* _FSTRING_H */
