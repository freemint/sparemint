/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

/*
 * Copyright 1991,1992 Eric R. Smith.
 * Copyright 1992,1993,1994 Atari Corporation.
 * All rights reserved.
 */

/*
 * Description: C declarations for functions defined in .s files
 */

# ifndef _SPROTO_H
# define _SPROTO_H


/*
 * context.s
 */
long _cdecl	build_context	(CONTEXT *sav, int fmt);
long _cdecl	save_context	(CONTEXT *sav);
void _cdecl	restore_context	(CONTEXT *sav);
void _cdecl	change_context	(CONTEXT *sav);


/*
 * cpu.s
 */
#ifndef MMU040
void _cdecl	set_mmu		(crp_reg, tc_reg);
#else
void _cdecl	set_mmu		(ulong *);
#endif
void _cdecl	save_mmu	(void);
void _cdecl	restr_mmu	(void);
void _cdecl	flush_pmmu	(void);

void _cdecl	init_cache	(void);
void _cdecl	cpush		(const void *base, long size);
void _cdecl	cpush000	(const void *base, long size);
void _cdecl	cpush030	(const void *base, long size);
void _cdecl	cpush040	(const void *base, long size);
void _cdecl	cpush060	(const void *base, long size);

void _cdecl	setstack	(long);


/*
 * intr.s
 */
void _cdecl	reboot		(void);
# if 0
short _cdecl	spl7		(void);
void _cdecl	spl		(short);
# endif
void _cdecl	newmvec		(void);
void _cdecl	newjvec		(void);
long _cdecl	new_rwabs	(void);
long _cdecl	new_mediach	(void);
long _cdecl	new_getbpb	(void);


/*
 * quickzer.s
 */
void _cdecl	quickzero	(char *place, long size);


/*
 * quickmov.s
 */
void _cdecl	quickmove	(void *dst, void *src, long nbytes);
void _cdecl	quickmovb	(void *dst, const void *src, long nbytes);


/*
 * quickswa.s
 */
void _cdecl	quickswap	(void *dst, void *src, long nbytes);


/*
 * syscall.s
 */
char * _cdecl	lineA0		(void);
void _cdecl	call_aes	(short **);
long _cdecl	callout		(long, ...);
long _cdecl	callout1	(long, int);
long _cdecl	callout2	(long, int, int);
long _cdecl	callout6	(long, int, int, int, int, int, int);
long _cdecl	callout6spl7	(long, int, int, int, int, int, int);
void _cdecl	do_usrcall	(void);

# endif /* _SPROTO_H */
