/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

/*
 * Copyright 1990,1991,1992 Eric R. Smith.
 * Copyright 1992,1993 Atari Corporation.
 * All rights reserved.
 */

/*
 * misc. utility routines
 */

# include "util.h"

/*
 * given an address, find the corresponding memory region in this program's
 * memory map
 */

MEMREGION *
addr2mem (virtaddr a)
{
	register long i;

	for (i = 0; i < curproc->num_reg; i++)
	{
		if (a == curproc->addr[i])
		{
			return curproc->mem[i];
		}
	}
	
	return NULL;
}

/*
 * given a pid, return the corresponding process
 */

PROC *
pid2proc (int pid)
{
	register PROC *p;

	for (p = proclist; p; p = p->gl_next)
	{
		if (p->pid == pid)
			return p;
	}
	
	return NULL;
}

/*
 * return a new pid
 */

static int _maxpid = 2;
	
int
newpid (void)
{
	register int i;
# ifndef NDEBUG
	register int j = 0;
# endif
	
	do {
		i = _maxpid++;
		if (_maxpid >= MAXPID)
			_maxpid = 2;
		
		assert (j++ < MAXPID);
	}
	while (pid2proc (i));
	
	return i;
}

/*
 * set up to run the init program as PID 1
 */
int
set_pid_1 (void)
{
	if (pid2proc (1))
		/* should never happen, only called once */
		return -1;
	
	_maxpid = 1;
	return 0;
}

/*
 * zero out a block of memory, quickly; the block must be word-aligned,
 * and should be long-aligned for speed reasons
 */

void
zero (char *place, long size)
{
	register long cruft;
	register long blocksize;
	
	cruft = size % 256;	/* quickzero does 256 byte blocks */
	blocksize = size / 256;	/* divide by 256 */
	if (blocksize > 0)
	{
		quickzero (place, blocksize);
		place += (blocksize * 256);
	}
	while (cruft > 0)
	{
		*place++ = 0;
		cruft--;
	}
}

# ifdef JUNK_MEM
void
fillwjunk (long *place, long size)
{
	while (size > 0)
	{
		*place++ = size;
		size -= 4;
	}
}
# endif

/*
 * convert a time in milliseconds to a GEMDOS style date/time
 * timeptr[0] gets the time, timeptr[1] the date.
 * BUG/FEATURE: in the conversion, it is assumed that all months have
 * 30 days and all years have 360 days.
 */

void _cdecl
ms_time (ulong ms, short int *timeptr)
{
	register ulong secs = ms;
	register short tsec, tmin, thour;
	register short tday, tmonth, tyear;

	secs /= 1000;
	tsec = secs % 60;
	
	secs /= 60;		/* secs now contains # of minutes */
	tmin = secs % 60;
	
	secs /= 60;		/* secs now contains # of hours */
	thour = secs % 24;
	
	secs /= 24;		/* secs now contains # of days */
	tday = secs % 30;
	
	secs /= 30;
	tmonth = secs % 12;
	tyear = secs / 12;
	
	*timeptr++ = (thour << 11) | (tmin << 5) | (tsec >> 1);
	*timeptr = (tyear << 9) | ((tmonth + 1) << 5) | (tday + 1);
}

/*
 * unixtim (time, date): convert a Dos style (time, date) pair into
 * a Unix time (seconds from midnight Jan 1., 1970)
 */

static int const
mth_start[13] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };

long _cdecl
unixtime (ushort time, ushort date)
{
	register int sec, min, hour;
	register int mday, mon, year;
	register long s;
	
	sec	= (time & 31) << 1;
	min	= (time >> 5) & 63;
	hour	= (time >> 11) & 31;
	
	mday	= date & 31;
	mon	= ((date >> 5) & 15) - 1;
	year	= 80 + ((date >> 9) & 127);
	
	/* calculate tm_yday here */
	s = (mday - 1) + mth_start[mon] + /* leap year correction */
		(((year % 4) != 0 ) ? 0 : (mon > 1));
	
	s = (sec) + (min * 60L) + (hour * 3600L) +
		(s * 86400L) + ((year - 70) * 31536000L) +
		((year - 69) / 4) * 86400L;
	
	return s;
}

/* convert a Unix time into a DOS time. The longword returned contains
 * the time word first, then the date word.
 * BUG: we completely ignore any time zone information.
 */
# define SECS_PER_MIN		(60L)
# define SECS_PER_HOUR		(3600L)
# define SECS_PER_DAY		(86400L)
# define SECS_PER_YEAR		(31536000L)
# define SECS_PER_LEAPYEAR	(SECS_PER_DAY + SECS_PER_YEAR)

static int
days_per_mth[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

long _cdecl
dostime (long time)
{
	register int tm_hour, tm_min, tm_sec;
	register int tm_year, tm_mon, tm_mday;
	register long t = time;
	
	if (t <= 0)
		return 0;
	
# if 0
	/* dates smaller than 1st Jan 1980 confuse dostime */
	if (t < 315532800L)
		t = 315532800L;
# endif
	
	tm_year = 70;
	while (t >= SECS_PER_YEAR)
	{
		if ((tm_year & 0x3) == 0)
		{
			if (t < SECS_PER_LEAPYEAR)
				break;
			t -= SECS_PER_LEAPYEAR;
		}
		else
		{
			t -= SECS_PER_YEAR;
		}
		tm_year++;
	}
	
	tm_mday = (int)(t / SECS_PER_DAY);
	days_per_mth[1] = (tm_year & 0x3) ? 28 : 29;
	{
		register long i;
		for (i = 0; tm_mday >= days_per_mth[i]; i++)
			tm_mday -= days_per_mth[i];
	
		tm_mon = i + 1L;
	}
	tm_mday++;
	
	t = t % SECS_PER_DAY;
	tm_hour = (int)(t / SECS_PER_HOUR);
	
	t = t % SECS_PER_HOUR;
	tm_min = (int)(t / SECS_PER_MIN);
	tm_sec = (int)(t % SECS_PER_MIN);
	
	if (tm_year < 80)
	{
		tm_year = 80;
		tm_mon = tm_mday = 1;
		tm_hour = tm_min = tm_sec = 0;
	}
	
	{
        	register ulong time;
        	register ulong date;
		
		time = (tm_hour << 11) | (tm_min << 5) | (tm_sec >> 1);
		date = ((tm_year - 80) & 0x7f) << 9;
		date |= ((tm_mon) << 5) | (tm_mday);
		
		return (time << 16) | date;
	}
}
