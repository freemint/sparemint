/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _shmfs_h
# define _shmfs_h

# ifdef __TURBOC__
# include "include\mint.h"
# include "include\file.h"
# else
# include "include/mint.h"
# include "include/file.h"
# endif

#include "memory.h"

# define SHMNAME_MAX 15

typedef struct shmfile
{
	struct shmfile *next;
	char filename[SHMNAME_MAX+1];
	int uid, gid;
	struct timeval mtime;
	struct timeval ctime;
	unsigned mode;
	int inuse;
	MEMREGION *reg;
} SHMFILE;

extern struct timeval shmstamp;
extern SHMFILE *shmroot;

extern FILESYS shm_filesys;

void shm_init (void);


# endif /* _shmfs_h */
