/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

/* welcome.c - MiNT welcome message
 * Copyright 1992,1993,1994 Atari Corp.  All Rights Reserved.
 *=======================================================================
 * 1992-06-25 kbad
 */

# include "welcome.h"
# include "version.h"
# include "string.h"


# ifdef DEV_RANDOM
const char *random_greet =
	"\033p High-quality random number generator \033q\r\n"
	" courtesy of Theodore Ts'o.\r\n"
	" Copyright \xbd 1994-1998 Theodore Ts'o\r\n"
	" All Rights Reserved.\r\n"
	" See the file COPYRAND for details.\r\n"
	"\r\n"
;
# endif

const char *memprot_notice =
	"You have used -m to turn off memory\r\n"
	"protection.  On a 68000, you don't\r\n"
	"need to do this because MiNT will\r\n"
	"do it for you automagically.\r\n"
;

const char *memprot_warning =
	"\033p"
	"            *** WARNING ***            \033q\r\n"
	"You have turned off memory protection.\r\n"
	"This is not recommended, and may not be\r\n"
	"supported in the future.\r\n"
;


# ifndef THIRD_PARTY

const char *greet1 =
	"\r\n\033p\033f"
	" MiNT is Now TOS (" __DATE__ ")         \033q\r\n"
	" MiNT v" VERS_STRING " "
;

const char *greet2 =
	"\r\n"
	" \xbd 1990,1991,1992 Eric R. Smith\r\n"
	" MultiTOS kernel\r\n"
	" \xbd 1992,1993,1994 Atari Corporation\r\n"
	" All Rights Reserved.\r\n\033p"
	" Use this program at your own risk!    \033q\r\n"
	"\r\n"
;

# else /* THIRD_PARTY */

const char *greet1 =
	"\r\n"
	"\033p                                      \r"
	" This is " MINT_NAME " v" VERS_STRING " "
;

const char *greet2 =
	"\033q\r\n"
	"compiled " __DATE__ "\r\n"
	"\r\n"
	MINT_NAME " is a modified version of MiNT\r\n"
	"\r\n"
	"MiNT \xbd 1990,1991,1992 Eric R. Smith\r\n"
	"MultiTOS kernel\r\n"
	"     \xbd 1992,1993,1994 Atari Corporation\r\n"
	"All Rights Reserved.\r\n"
	"\033p  Use this program at your own risk!  \033q\r\n"
	"\r\n"
;

# endif /* THIRD_PARTY */
