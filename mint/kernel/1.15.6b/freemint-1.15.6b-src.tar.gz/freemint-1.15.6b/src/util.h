/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _util_h
# define _util_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


MEMREGION *	addr2mem	(virtaddr a);
PROC *		pid2proc	(int pid);
int		newpid		(void);
int		set_pid_1	(void);
void		zero		(char *place, long size);
# ifdef JUNK_MEM
void		fillwjunk	(long *place, long size)
# endif

void	_cdecl	ms_time		(ulong ms, short *timeptr);
long	_cdecl	unixtime	(ushort time, ushort date);
long	_cdecl	dostime		(long time);


# endif /* _util_h */
