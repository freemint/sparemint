/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _mprot_h
# define _mprot_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern long page_table_size;

void init_tables (void);
int get_prot_mode (MEMREGION *);
void mark_region (MEMREGION *region, short int mode);
void mark_proc_region (PROC *proc, MEMREGION *region, short int mode);
int prot_temp (ulong loc, ulong len, int mode);
void init_page_table (PROC *proc);
void mem_prot_special (PROC *proc);
void QUICKDUMP (void);
void report_buserr (void);
void BIG_MEM_DUMP (int bigone, PROC *proc);
int mem_access_for (PROC *p, ulong where, long len);


# endif /* _mprot_h */
