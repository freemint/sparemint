/* SMS library for use with the SMS daemon
 * (c) 1999 by Konrad M. Kokoszkiewicz, draco@atari.org
 *
 * Based on sample code by Thomas Binder (Gryf)
 */

#include <mintbind.h>
#include <mint/basepage.h>
#include <errno.h>
#include <signal.h>
#include <stat.h>
#include <fcntl.h>

#define UNUSED(x)	(void)(x)

/* Cannot use "/pipe/sms" because silly MagiC does not
 * understand a slash as a separator
 */

char pipe[]="u:\\pipe\\sms";

long sms_init(void)
{
	return 0L;
}

void sms_exit(void)
{
}

/* BUG: the pipe should be really opened here below
 */

long sms_open(BASEPAGE *base)
{
	struct stat atr;
	UNUSED(base);

	return Fxattr(0, pipe, &atr);
}

long sms_send(BASEPAGE *base, long fn, short nargs, short *msg)
{
	short bytes, fd;
	long r;

	UNUSED(fn);

	if (nargs == 0)
		return EBADARG;

	/* Fetch the length of the message. The message must be max
	 * 1024 bytes to guarantee an atomic write. 
	 */

	bytes = msg[2] + 16;

	if (bytes > 1024)
		return ERANGE;

	fd = Fopen(pipe, O_WRONLY|O_DENYNONE);
	if (fd < 0)
		return (long)fd;

	r = Fwrite(fd, (long)bytes, msg);
	(void)Fclose(fd);

	return r;
}
