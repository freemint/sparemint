/* Example:
 * send an AES message from a signal handler using SMS.
 * to see the action you must send SIGTERM (signal 15)
 * to the program.
 */

#include <stdio.h>
#include <signal.h>
#include <osbind.h>
#include <ostruct.h>
#include <gem.h>
#include <errno.h>
#include <mint/mintbind.h>
#include <fcntl.h>

#define ushort	unsigned short

#define SM_JUSTSEND	0x0000		/* just send */
#define SM_REPLSEND	0x0001		/* replace sender's APID with own one, then send */
#define SM_PID2APID	0x8000		/* OR mask: accept PID (instead of APID) as destination */

char	pipe[]="u:\\pipe\\sms";
short	ap_id;

/* An example of using the 'just send' command
 * with MiNT PID as destination.
 */

void sighnd(void)
{
	short handle;
	ushort sms[16] =
	{
		SM_JUSTSEND|SM_PID2APID,		/* command */
		0x0000,					/* destination address */
		0x0010,					/* length of the msg body */
		0x0000,0x0000,0x0000,0x0000,0x0000,	/* reserved for future definition */

		0x7777,0x0000,0x0000,0x0000,		/* message itself */
		0x0000,0x0000,0x0000,0x0000
	};

	sms[1] = Pgetpid();
	sms[9] = ap_id;
	handle = Fopen(pipe, O_WRONLY|O_DENYNONE);
	(void)Fwrite(handle, sizeof(sms), &sms);
	(void)Fclose(handle);
}
	
int main(void)
{
	int aesmsg[8];
	char atr[64];

	ap_id = appl_init();
	if (Fxattr(0, pipe, (void *)atr) == E_OK) {
		Psignal(SIGTERM, &sighnd);

		for(;;) {
			evnt_mesag(aesmsg);
			if (aesmsg[0] == 0x7777) {
				form_alert(1,"[4][|Caught SIGTERM][ OK ]");
				appl_exit();
				break;
			}
		}
	} else {
		form_alert(1,"[3][|SMS not found][ Bye ]");
	}
	return 0;
}
