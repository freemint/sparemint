/* Based on Gryf's usage.c (SLB example)
 */

#include <stdio.h>
#include <signal.h>
#include <osbind.h>
#include <ostruct.h>
#include <gem.h>
#include <errno.h>
#include <mint/mintbind.h>
#include <stdlib.h>
#include "slb_bind.h"

SHARED_LIB	slb;
SLB_EXEC	slb_exec;

static long slb_init(void)
{
	long r = 0;

	char *sp;

	/* This (arrogantly) assumes the SLBPATH points
	 * to only one directory, e(xempli) g(ratia):
	 * SLBPATH=u:\c\multitos\slb
	 *
	 * If the var is not set, the lib will be loaded
	 * from the current folder.
	 */

	sp = getenv("SLBPATH");

	/* WARNING, WARNING, WARNING:
	 * this function crashes the system if an error occurs,
	 * e.g. name mismatch, Gryf, fix that please.
	 */

	r = Slbopen("sms.slb", sp, 1L, &slb, &slb_exec);
	if (r < 0)
		Salert("Slbopen() failed");

	return r;
}

/* Example:
 * send an AES message from a signal handler using SMS.
 * to see the action you must send SIGTERM (signal 15)
 * to the program.
 */

short	ap_id;

static void sighnd(void)
{
	long r;
	short sms[16] = {0x0000,0x0000,0x0010,0x0000,
			 0x0000,0x0000,0x0000,0x0000,
			 0x7777,0x0000,0x0000,0x0000,
			 0x0000,0x0000,0x0000,0x0000 };

	sms[1] = sms[9] = ap_id;
	r = (slb_exec)(slb, 0L, (short)1, &sms);
	if (r < 0)
		Salert("Dupa");
}
	
int main(void)
{
	int aesmsg[8];

	ap_id = appl_init();
	if (slb_init() >= 0)
	{
		Psignal(SIGTERM, &sighnd);
		for(;;)
		{
			evnt_mesag(aesmsg);
			if (aesmsg[0] == 0x7777)
			{
				form_alert(1,"[4][|Caught SIGTERM][ OK ]");
				appl_exit();
				break;
			}
		}
		(void)Slbclose(slb);
	}
	else
		form_alert(1,"[3][|SMS library error][ Bye ]");

	return 0;
}
