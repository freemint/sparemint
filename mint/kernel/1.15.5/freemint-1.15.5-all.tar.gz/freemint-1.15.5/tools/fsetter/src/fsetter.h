/* Resource Datei Indizes f�r FSETTER */

#define MAINBOX  0   /* Formular/Dialog */
#define LW_BOX   2   /* BUTTON in Baum MAINBOX */
#define LW_A     3   /* BOXCHAR in Baum MAINBOX */
#define LW_Z     28  /* BOXCHAR in Baum MAINBOX */
#define LW_1     29  /* BOXCHAR in Baum MAINBOX */
#define LW_6     34  /* BOXCHAR in Baum MAINBOX */
#define LW_INFO  35  /* BUTTON in Baum MAINBOX */
#define A_BOX    36  /* BUTTON in Baum MAINBOX */
#define A_VFAT   37  /* BUTTON in Baum MAINBOX */
#define A_SLNK   38  /* BUTTON in Baum MAINBOX */
#define A_CACHE  39  /* BUTTON in Baum MAINBOX */
#define A_WP     40  /* BUTTON in Baum MAINBOX */
#define N_BOX    41  /* BUTTON in Baum MAINBOX */
#define N_GEMDOS 42  /* BUTTON in Baum MAINBOX */
#define N_ISO    43  /* BUTTON in Baum MAINBOX */
#define N_MSDOS  44  /* BUTTON in Baum MAINBOX */
#define F_BOX    45  /* BUTTON in Baum MAINBOX */
#define F_KOPIE  46  /* BUTTON in Baum MAINBOX */
#define F_ANZAHL 48  /* STRING in Baum MAINBOX */
#define F_AKTIV  50  /* FTEXT in Baum MAINBOX */
#define SETZEN   51  /* BUTTON in Baum MAINBOX */
#define ENDE     52  /* BUTTON in Baum MAINBOX */
#define MB_VERS  53  /* TEXT in Baum MAINBOX */
#define SETENDE  54  /* BUTTON in Baum MAINBOX */

#define INFOBOX  1   /* Formular/Dialog */
#define I_TITEL  1   /* STRING in Baum INFOBOX */
#define I_SYS    4   /* STRING in Baum INFOBOX */
#define I_CASE   6   /* STRING in Baum INFOBOX */
#define I_NLEN   8   /* STRING in Baum INFOBOX */
#define I_PLEN   10  /* STRING in Baum INFOBOX */
#define I_GESAMT 12  /* TEXT in Baum INFOBOX */
#define I_BELEGT 14  /* TEXT in Baum INFOBOX */
#define I_FREI   16  /* TEXT in Baum INFOBOX */
#define I_INODES_FREE 21  /* TEXT in Baum INFOBOX */
#define I_INODES_USED 22  /* TEXT in Baum INFOBOX */
#define I_INODES_ALL 23  /* TEXT in Baum INFOBOX */
#define I_OK     24  /* BUTTON in Baum INFOBOX */
#define I_DRIVER 27  /* STRING in Baum INFOBOX */
#define I_DRIVER_VERSION 29  /* STRING in Baum INFOBOX */

#define WINICON  2   /* Formular/Dialog */
#define WIBOX    0   /* BOX in Baum WINICON */

#define STRINGS  3   /* Formular/Dialog */
#define S_VERSION 1   /* STRING in Baum STRINGS */
#define S_TITEL  2   /* STRING in Baum STRINGS */
#define S_JA     3   /* STRING in Baum STRINGS */
#define S_NEIN   4   /* STRING in Baum STRINGS */
#define S_HALB   5   /* STRING in Baum STRINGS */
#define S_BEL    6   /* STRING in Baum STRINGS */
#define S_UNBK   7   /* STRING in Baum STRINGS */
#define S_MENU   8   /* STRING in Baum STRINGS */

#define NO_DRIVE 0   /* Alert String */

#define NO_INFO  1   /* Alert String */
