/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _shmfs_h
# define _shmfs_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern FILESYS shm_filesys;

void shm_init (void);


# endif /* _shmfs_h */
