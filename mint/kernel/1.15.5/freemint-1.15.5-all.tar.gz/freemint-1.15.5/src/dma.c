/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1999-01-05
 * last change: 1999-10-13
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions or bug reports to me or
 * the MiNT mailing list
 * 
 * 
 * changes since last version:
 * 
 * 
 * 
 * known bugs:
 * 
 * - nothing
 * 
 * todo:
 * 
 * 
 * explanation:
 * 
 * - every DMA driver first registers with the kernel. The kernel allocates a
 *   unique channel descriptor for the driver which is then used for further
 *   function calls.
 * 
 * - A DMA driver can unregister (if it wants to terminate).
 * 
 * - When entering the driver, the driver calls dma_start. The kernel
 *   automatically sets a semaphore for the driver and blocks here if another
 *   process is already using the driver.
 * 
 * - Then the driver can do whatever is necessary to start operation and
 *   enable an interrupt. When this is done, the driver calls
 *   dma_block(channel) which will block the current process and give up the
 *   processor.
 * 
 * - Now another process can run; if this process also tries to access the
 *   driver, it will automatically be blocked because the semaphore is locked.
 * 
 * - When the device has finished its operation, it causes an interrupt which
 *   calls the ISR in the driver. The driver can either restart the device (if
 *   further processing is required for the current task, eg. when doing
 *   scatter-gather DMA), *or* it can call dma_deblock(channel). In either
 *   case, the ISR ends and control returns to the process that was running
 *   when the interrupt happened.  A call to dma_deblock(channel) unblocks the
 *   driver task. The kernel then switches back to the driver task, which
 *   continues by returning from dma_block. The driver may now either restart
 *   the device (using operations that take too long to do this in the ISR, or
 *   that need kernel calls) and call dma_block again, or it finishes by
 *   cleaning up and calling dma_end.
 * 
 * - When leaving the driver, the driver calls dma_end. This resets the
 *   semaphore and unblocks other processes (one at a time) waiting to enter
 *   the driver.
 * 
 * - dma_deblock is the only routine that may be called from within an
 *   interrupt service routine.
 * 
 */

//# include "dma.h"
# include "include/mint.h"

# include "proc.h"


# define DMA_VERS	1		/* internal version */


/****************************************************************************/
/* BEGIN definition part */

typedef struct channel CHANNEL;

typedef struct dma DMA;
struct dma
{
	CHANNEL * _cdecl (*get_channel)	(void);
	void	  _cdecl (*free_channel)(CHANNEL *channel);
	void	  _cdecl (*dma_start)	(CHANNEL *channel);
	void	  _cdecl (*dma_end)	(CHANNEL *channel);
	void	  _cdecl (*block)	(CHANNEL *channel);
	void	  _cdecl (*deblock)	(CHANNEL *channel);
};


static CHANNEL * _cdecl dma_get_channel	(void);
static void _cdecl dma_free_channel	(CHANNEL *channel);
static void _cdecl dma_start		(CHANNEL *channel);
static void _cdecl dma_end		(CHANNEL *channel);
static void _cdecl dma_block		(CHANNEL *channel);
static void _cdecl dma_deblock		(CHANNEL *channel);

DMA dma =
{
	dma_get_channel,
	dma_free_channel,
	dma_start,
	dma_end,
	dma_block,
	dma_deblock
};

/* END definition part */
/****************************************************************************/

/****************************************************************************/
/* BEGIN global data */

# define CHANNELS 32
struct channel
{
	ushort	lock;
	ushort	sleepers;
	ushort	pid;
	ushort	used;
};

static CHANNEL channels [CHANNELS];

/* END global data */
/****************************************************************************/

/****************************************************************************/
/* BEGIN  */

static CHANNEL * _cdecl
dma_get_channel (void)
{
	int i;
	
	for (i = 0; i < CHANNELS; i++)
	{
		if (!(channels [i].used))
		{
			channels [i].lock	=  0;
			channels [i].sleepers	=  0;
			channels [i].pid	= -1;
			channels [i].used	=  1;
			
			return &channels [i];
		}
	}
	
	return 0;
}

static void _cdecl
dma_free_channel (CHANNEL *channel)
{
	if (channel)
		channel->used = 0;
}

/* only synchronus callable [to kernel]
 */
static void _cdecl
dma_start (CHANNEL *channel)
{
	while (channel->lock)
	{
		channel->pid = -1;
		
		channel->sleepers++;
		sleep (IO_Q, (long) channel);
		channel->sleepers--;
	}
	
	channel->lock = 1;
}

/* only synchronus callable [to kernel]
 */
static void _cdecl
dma_end (CHANNEL *channel)
{
	channel->lock = 0;
	
	if (channel->sleepers)
		wake (IO_Q, (long) channel);
}

/* only synchronus callable [to kernel]
 */
static void _cdecl
dma_block (CHANNEL *channel)
{
	channel->pid = curproc->pid;
	sleep (0x100 | IO_Q, (long) &(channel->pid));
	channel->pid = -1;
}

/* synchronus/asynchronus callable
 */
static void _cdecl
dma_deblock (CHANNEL *channel)
{
	iwake (IO_Q, (long) &(channel->pid), channel->pid);
}

/* END  */
/****************************************************************************/

/****************************************************************************/
/* BEGIN  */

/* END  */
/****************************************************************************/
