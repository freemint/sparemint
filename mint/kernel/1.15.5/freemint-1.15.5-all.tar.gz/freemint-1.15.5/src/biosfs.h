/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _biosfs_h
# define _biosfs_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern FILESYS bios_filesys;

void biosfs_init (void);

long rsvf_ioctl (int f, void *arg, int mode);
long iwrite	(int bdev, const char *buf, long bytes, int ndelay, struct bios_file *b);
long iread	(int bdev, char *buf, long bytes, int ndelay, struct bios_file *b);
long iocsbrk	(int bdev, int mode, struct bios_tty *t);

int set_auxhandle (PROC *, int);


# endif /* _biosfs_h */
