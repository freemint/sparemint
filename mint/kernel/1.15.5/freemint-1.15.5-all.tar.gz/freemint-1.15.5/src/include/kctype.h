/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

/*
 * Copyright 1991,1992 Eric R. Smith.
 * Copyright 1992,1993,1994 Atari Corporation.
 * All rights reserved.
 */

/*
 * Description: kernel Character classification and conversion
 */

# ifndef _KCTYPE_H
# define _KCTYPE_H


extern	unsigned char	_mint_ctype[];

# define _CTc		0x01	/* control character */
# define _CTd		0x02	/* numeric digit */
# define _CTu		0x04	/* upper case */
# define _CTl		0x08	/* lower case */
# define _CTs		0x10	/* whitespace */
# define _CTp		0x20	/* punctuation */
# define _CTx		0x40	/* hexadecimal */

# define isalnum(c)	(  _mint_ctype[(unsigned char)(c)] & (_CTu|_CTl|_CTd))
# define isalpha(c)	(  _mint_ctype[(unsigned char)(c)] & (_CTu|_CTl))
# define isascii(c)	(!((c) & ~0x7f))
# define iscntrl(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTc)
# define isdigit(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTd)
# define isgraph(c)	(!(_mint_ctype[(unsigned char)(c)] & (_CTc|_CTs)) && (_mint_ctype[(unsigned char)(c)]))
# define islower(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTl)
# define isprint(c)	(!(_mint_ctype[(unsigned char)(c)] &  _CTc)       && (_mint_ctype[(unsigned char)(c)]))
# define ispunct(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTp)
# define isspace(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTs)
# define isupper(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTu)
# define isxdigit(c)	(  _mint_ctype[(unsigned char)(c)] &  _CTx)
# define iswhite(c)	(isspace (c))

# define _toupper(c)	((c) ^ 0x20)
# define _tolower(c)	((c) ^ 0x20)
# define toascii(c)	((c) & 0x7f)

# define toint(c)	((c) <= '9' ? (c) - '0' : toupper (c) - 'A')
# define isodigit(c)	((c) >= '0' && (c) <= '7')
# define iscymf(c)	(isalpha(c) || ((c) == '_'))
# define iscym(c)	(isalnum(c) || ((c) == '_'))


# endif /* _KCTYPE_H */
