/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

/*
 * Copyright 1991,1992 Eric R. Smith.
 * Copyright 1992,1993,1994 Atari Corporation.
 * All rights reserved.
 */

# ifndef _TYPES_H
# define _TYPES_H

# ifdef __TURBOC__
# include "include\misc.h"
# else
# include "misc.h"
# endif


typedef unsigned char			uchar;
typedef unsigned short			ushort;
typedef unsigned long 			ulong;

# ifndef LLONG
# define LLONG
# ifdef __GNUC__
typedef long long			llong;
# else
typedef struct { long hi; ulong lo; }	llong;
# endif
# endif

/* signed basic types */
typedef signed char			__s8;
typedef signed short			__s16;
typedef signed long			__s32;
# ifdef __GNUC__
typedef signed long long		__s64;
# else
# error signed long long		__s64;
# endif

/* unsigned basic types */
typedef unsigned char			__u8;
typedef unsigned short			__u16;
typedef unsigned long			__u32;
# ifdef __GNUC__
typedef unsigned long long		__u64;
# else
# error unsigned long long		__u64;
# endif


typedef long _cdecl (*Func)();

/* forward declarations: file.h
 */
typedef struct fcookie		fcookie;
typedef struct timeval		TIMEVAL;
typedef struct dtabuf		DTABUF;
typedef struct dirstruct	DIR;
typedef struct xattr		XATTR;
typedef struct stat		STAT;
typedef struct fileptr		FILEPTR;
typedef struct ilock		LOCK;
typedef struct filesys		FILESYS;
typedef struct devdrv		DEVDRV;	
typedef struct tty		TTY;

/* forward declarations: proc.h
 */
typedef struct context		CONTEXT;
typedef struct timeout		TIMEOUT;
typedef struct proc		PROC;

typedef struct bf_key		BF_KEY;

/* structure used to hold i/o buffers */
typedef struct io_rec
{
	char *bufaddr;
	short buflen;
	volatile short head;
	volatile short tail;
	short low_water;
	short hi_water;
	
} IOREC_T;

/* Bconmap struct, * returned by Bconmap (-2) */
typedef struct
{
	struct
	{
		long bconstat;
		long bconin;
		long bcostat;
		long bconout;
		long rsconf;
		IOREC_T	*iorec;
		
	} *maptab;
	short	maptabsize;
	
} BCONMAP2_T;


# endif /* _TYPES_H */
