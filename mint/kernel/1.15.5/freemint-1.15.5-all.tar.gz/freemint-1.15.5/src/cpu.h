/* This file belongs to FreeMiNT,
 * it is not a part of the original MiNT distribution.
 */

# ifndef _cpu_h
# define _cpu_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif

long _cdecl ccw_getdmask(void);
long _cdecl ccw_get(void);
long _cdecl ccw_set(ulong ctrl, ulong mask);

# endif /* _cpu_h */
