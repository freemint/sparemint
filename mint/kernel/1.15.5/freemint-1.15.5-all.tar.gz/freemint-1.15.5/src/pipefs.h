/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _pipefs_h
# define _pipefs_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern FILESYS pipe_filesys;


# endif /* _pipefs_h */
