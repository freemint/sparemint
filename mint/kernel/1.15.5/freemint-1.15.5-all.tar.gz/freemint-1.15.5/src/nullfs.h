/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file on other projects without my explicit
 * permission.
 */

/*
 * begin:	1999-07-27
 * last change: 1999-07-27
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 *  
 */

# ifndef _nullfs_h
# define _nullfs_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


long _cdecl null_mkdir		(fcookie *dir, const char *name, unsigned mode);
long _cdecl null_creat		(fcookie *dir, const char *name, unsigned mode, int attrib, fcookie *fc);
long _cdecl null_fscntl		(fcookie *dir, const char *name, int cmd, long arg);
long _cdecl null_symlink	(fcookie *dir, const char *name, const char *to);
long _cdecl null_readlink	(fcookie *dir, char *buf, int buflen);
long _cdecl null_hardlink	(fcookie *fromdir, const char *fromname, fcookie *todir, const char *toname);
long _cdecl null_writelabel	(fcookie *dir, const char *name);
long _cdecl null_readlabel	(fcookie *dir, char *name, int namelen);
long _cdecl null_dskchng	(int drv, int mode);
long _cdecl null_mknod		(fcookie *dir, const char *name, ulong mode);


# endif /* _nullfs_h */
