/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _main_h
# define _main_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


/* global exported variables
 */

extern long mch;		/* machine */
extern long mcpu;		/* cpu type */
extern long fputype;		/* fpu type */
extern short fpu;		/* flag if fpu is present */
extern int tosvers;		/* the underlying TOS version */
extern int secure_mode;
extern int screen_boundary;
extern int gl_lang;
extern int flk;
extern int FalconVideo;
extern short ste_video;

# ifdef OLDTOSFS
extern long gemdos_version;
# endif

# ifdef VM_EXTENSION
extern int vm_in_use;
extern ulong st_left_after_vm;
# endif


void	boot_print	(const char *s);
void	boot_printf	(const char *fmt, ...);

void	restr_intr	(void);
int	main		(int argc, char **argv);
void	install_cookies	(void);


# endif /* _main_h */
