/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _unifs_h
# define _unifs_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif

extern FILESYS uni_filesys;

FILESYS *get_filesys (int);
void unifs_init (void);

# endif /* _unifs_h */
