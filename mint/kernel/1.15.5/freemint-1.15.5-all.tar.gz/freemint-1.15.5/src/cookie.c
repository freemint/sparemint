/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1999-08-07
 * last change:	1999-08-07
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 * 
 * cookie jar handling routines
 * 
 * The "cookie jar" is an area of memory reserved by TOS for TSR's and utility
 * programs. The idea is that you put a cookie in the jar to notify people of
 * available services. The BIOS uses the cookie jar in TOS 1.6 and higher. For
 * earlier versions of TOS, the jar is always empty (unless someone added a
 * cookie before us; POOLFIX does, for example). MiNT establishes an entirely
 * new cookie jar (with the old cookies copied over) and frees it on exit.
 * That's because TSR's run under MiNT will no longer be accessible after MiNT
 * exits. MiNT also puts a cookie in the jar, with tag field 'MiNT' (of course)
 * and with the major version of MiNT in the high byte of the low word,
 * and the minor version in the low byte.
 * 
 * 
 * changes since last version:
 * 
 * 1999-08-07:
 * 
 * initial version; moved from main.c
 * some cleanup
 * 
 * known bugs:
 * 
 * todo:
 * 
 * optimizations to do:
 * 
 */

# include "cookie.h"

# include "main.h"
# include "memory.h"	/* get_region, attach_region */
# include "version.h"	/* MAJ_VERSION, MIN_VERSION */


/* TOS and MiNT cookie jars, respectively.
 */

COOKIE *oldcookie;
COOKIE *newcookie;

/* memory region that hold the cookie jar
 */
MEMREGION *newjar_region;


void
install_cookies (void)
{
	COOKIE *cookie;
	ushort i = 0, ncookies = 0;
	
	long ncsize;
	extern long rsvf;
	
	cookie = oldcookie = *CJAR;
	if (cookie)
	{
		while (cookie->tag != 0)
		{
			/* check for _FLK cookie */
			if (cookie->tag == COOKIE__FLK)
				flk = 1;
		
			/* ..and for RSVF */
			else if (cookie->tag == COOKIE_RSVF)
				rsvf = cookie->value;

			cookie++;
			ncookies++;
		}
	}
	
	ncsize = MIN (cookie->value, 240);	/* avoid to big tag values */
	if (ncookies > ncsize)
		ncsize = ncookies;
	
	/*
	 * We allocate the cookie jar in global memory so anybody can read
	 * it or write it. This code allocates at least 16 more cookies,
	 * then rounds up to a QUANTUM boundary (that's what ROUND does). 
	 * Probably, nobody will have to allocate another cookie jar :-)
	 * 
	 * NOTE: obviously, we can do this only if init_intr is called
	 * _after_ memory, processes, etc. have been initialized
	 */
	ncsize = (ncsize + 16) * sizeof (COOKIE);
	ncsize = ROUND (ncsize);
	newjar_region = get_region (core, ncsize, PROT_G);
	newcookie = (COOKIE *) attach_region (rootproc, newjar_region);
	
	
	/* set the hardware detected CPU and FPU rather
	 * than trust the TOS
	 */
	newcookie[i].tag = COOKIE__CPU;
	newcookie[i].value = mcpu; 
	i++;
	
	newcookie[i].tag = COOKIE__FPU;
	newcookie[i].value = fputype;
	i++;
	
	/* copy the old cookies to the new jar */
	cookie = oldcookie;
	
	while (ncookies)
	{
		/* but don't copy RSVF, MiNTs /dev is for real...
		 * (if you want to know whats in there use ls :)
		 * don't copy _CPU & _FPU, we already installed own
		 * _CPU and _FPU cookies
		 */
		if (cookie->tag == COOKIE_RSVF
			|| cookie->tag == COOKIE__CPU
			|| cookie->tag == COOKIE__FPU)
		{
			cookie++;
		}
		else
		{
			newcookie[i++] = *cookie++;
		}
		
		ncookies--;
	}
	
	/* install MiNT cookie
	 */
	newcookie[i].tag   = COOKIE_MiNT;
	newcookie[i].value = (MAJ_VERSION << 8) | MIN_VERSION;
	i++;
	
	/* install _FLK cookie to indicate that file locking works
	 */
	if (!flk)
	{
		newcookie[i].tag   = COOKIE__FLK;
		newcookie[i].value = 0;
		i++;
	}
	
	/* jr: install PMMU cookie if memory protection is used
	 * Draco: also do the same if VM is active; memory protection
	 * and VM exclude each other, but some day we can get both
	 * working simultaneously, who knows...
	 */
# ifdef	VM_EXTENSION
	if (!no_mem_prot || vm_in_use)
	{
# else
	if (!no_mem_prot)
	{
# endif
		newcookie[i].tag   = COOKIE_PMMU;
		newcookie[i].value = 0;
		i++;
	}
	
	/* the last cookie should have a 0 tag, and a value indicating
	 * the number of slots, total
	 */
	newcookie[i].tag   = 0;
	newcookie[i].value = ncsize / sizeof(COOKIE);
	
	*CJAR = newcookie;
}
