
# include <stdlib.h>
# include <stdio.h>

# include "../include/mint.h"

# include "../include/basepage.h"
# include "../include/block_IO.h"
# include "../include/dcntl.h"
# include "../include/default.h"
# include "../include/file.h"
# include "../include/mem.h"
# include "../include/proc.h"
# include "../include/types.h"
# include "../include/xbra.h"

int
main (void)
{
	printf ("sizeof (BASEPAGE)\t= %li\n", sizeof (BASEPAGE));
	printf ("sizeof (DI)\t\t= %li\n", sizeof (DI));
	printf ("sizeof (UNIT)\t\t= %li\n", sizeof (UNIT));
	printf ("sizeof (fcookie)\t= %li\n", sizeof (fcookie));
	printf ("sizeof (DTABUF)\t\t= %li\n", sizeof (DTABUF));
	printf ("sizeof (DIR)\t\t= %li\n", sizeof (DIR));
	printf ("sizeof (XATTR)\t\t= %li\n", sizeof (XATTR));
	printf ("sizeof (FILEPTR)\t= %li\n", sizeof (FILEPTR));
	printf ("sizeof (LOCK)\t\t= %li\n", sizeof (LOCK));
	printf ("sizeof (DEVDRV)\t\t= %li\n", sizeof (DEVDRV));
	printf ("sizeof (FILESYS)\t= %li\n", sizeof (FILESYS));
	printf ("sizeof (MEMREGION)\t= %li\n", sizeof (MEMREGION));
	printf ("sizeof (SHTEXT)\t\t= %li\n", sizeof (SHTEXT));
	printf ("sizeof (FILEHEAD)\t= %li\n", sizeof (FILEHEAD));
	printf ("sizeof (crp_reg)\t= %li\n", sizeof (crp_reg));
	printf ("sizeof (page_type)\t= %li\n", sizeof (page_type));
	printf ("sizeof (long_desc)\t= %li\n", sizeof (long_desc));
	printf ("sizeof (tc_reg)\t\t= %li\n", sizeof (tc_reg));
	printf ("sizeof (KBDVEC)\t\t= %li\n", sizeof (KBDVEC));
	printf ("sizeof (CONTEXT)\t= %li\n", sizeof (CONTEXT));
	printf ("sizeof (TIMEOUT)\t= %li\n", sizeof (TIMEOUT));
	printf ("sizeof (PROC)\t\t= %li\n", sizeof (PROC));
	printf ("sizeof (IOREC_T)\t= %li\n", sizeof (IOREC_T));
	printf ("sizeof (BCONMAP2_T)\t= %li\n", sizeof (BCONMAP2_T));
	printf ("sizeof (xbra_vec)\t= %li\n", sizeof (xbra_vec));
	
	return 0;
}