/* This is an automatically generated file.
 * Do not edit, edit cdef.sh instead
 */

# ifndef _cdef_h
# define _cdef_h

# define _COMPILER_NAME gcc version 2.8.1
# define _COMPILER_OPTS -fomit-frame-pointer -O3
# define _COMPILER_DEFS -DMULTITOS -DVERBOSE_BOOT -DTRAPS_PRIVATE -DONLY030 -DMMU040 -DMILAN -DCPU040

# endif /* _cdef_h */
