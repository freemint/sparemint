==============================================================================
 ==                                                                        ==
    ==                  FreeMiNT 1.16.1 beta release                    ==
 ==                                                                        ==
==============================================================================

The different FreeMiNT 1.16.1 beta kernel. Place the right kernel for
your hardware in the AUTO folder of your boot drive. Please see in the
release notes for more details.


mint000.prg - kernel for 68000 CPU based ATARI's

               --> ATARI ST/STE
               --> MEGA ST/STE

mint030.prg - kernel for 68020/68030 CPU based ATARI's

               --> ATARI TT
               --> ATARI Falcon
               --> 68030 based accelerators (CT2, PAK/30)

mint040.prg - kernel for 68040 AND(!) 68060 CPU based ATARI's

               --> Falcon with Afterburner
               --> Falcon with CT60
               --> Hades

mintmil.prg - kernel for Milan computer

               --> Milan
               --> Milan with 68060 CPU

mintara.prg - kernel for Aranym generic ATARI emulator
