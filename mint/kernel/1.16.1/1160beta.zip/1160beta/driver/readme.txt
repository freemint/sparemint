==============================================================================
 ==                                                                        ==
    ==                  FreeMiNT 1.16.1 beta release                    ==
 ==                                                                        ==
==============================================================================

These are various useful drivers.

If you want to use one of them just copy them into the <sysdir> directory
and reboot. Take a look on the bootmessages if the driver find the hardware
card and is correctly installed.


The drivers:

assemsoft     - Ethernet drivers for RTL8139 and NE2000 based network cards.
                Supported are PCI, ISA and EtherneC connected cards.

audiodev.xdd  - Audio device for ST, STE, TT, Falcon and XBIOS compatible
                sound hardware

dsp56k.xdd    - generic DSP device abstraction (supports the Falcon DSP at the
                moment)

flop_raw.xdd  - raw floppy driver; create a device under /dev that can be used
                for raw floppy access

lp.xdd        - parallel port driver for ATARI ST/E/TT/Falcon and compatible
                parallel ports through MFP

xif           - Various ethernet drivers from the MiNTNet distribution
