
# ifndef _bitmap_h
# define _bitmap_h

# include "minix.h"

long	count_bits	(ushort *buf, long num);

long	alloc_zone	(int drive);
int	free_zone	(long zone, int drive);

ushort	alloc_inode	(int drive);
int	free_inode	(unsigned inum, int drive);

# endif /* _bitmap_h */
