
# ifndef _inode_h
# define _inode_h

# include "minix.h"

int		read_inode	(unsigned num, d_inode *rip, int drv);
int		write_inode	(unsigned num, d_inode *rip, int drv);

void		trunc_inode	(d_inode *rip, int drive, long count, int zap);
long		itruncate	(unsigned inum, int drive, long length);

# endif /* _inode_h */
