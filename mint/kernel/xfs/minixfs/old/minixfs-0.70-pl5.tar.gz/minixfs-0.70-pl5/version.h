
# ifndef _version_h
# define _version_h


/* Version of Minixfs */

# define MFS_MAJOR	0
# define MFS_MINOR	70
# define MFS_PLEV	5

# define PRE_RELEASE

# endif /* _version_h */
