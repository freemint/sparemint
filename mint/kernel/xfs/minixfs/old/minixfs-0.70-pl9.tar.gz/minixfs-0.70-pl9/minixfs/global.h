
# ifndef _global_h
# define _global_h

# include "minix.h"

/* error UNIT */
extern UNIT error;

/* Pointer to drive info */
extern super_info *super_ptr[NUM_DRIVES];

/* First FILEPTR in chained list */
extern FILEPTR *firstptr;

/* Kernel info structure */
extern struct kerinfo *kernel;

/*
 * Binary readable parameters
 */

/* Magic number */
extern long mfs_magic;

/* Minixfs version */
extern int mfs_maj;
extern int mfs_min;
extern int mfs_plev;

/*
 * Binary configurable parameters
 */

/* Translation modes */
extern long fs_mode[NUM_DRIVES];

# endif /* _global_h */
