
# ifndef _main_h
# define _main_h

# include "minix.h"

FILESYS *minix_init	(struct kerinfo *k);
int	minix_sanity	(int drv);

# endif /* _main_h */
