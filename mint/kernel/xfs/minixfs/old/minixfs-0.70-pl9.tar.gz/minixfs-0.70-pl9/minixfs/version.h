
# ifndef _version_h
# define _version_h


/* Version of Minixfs */

# define MFS_MAJOR	0
# define MFS_MINOR	70
# define MFS_PLEV	9

# if 0
# define PRE_RELEASE
# endif

# endif /* _version_h */
