
# ifndef _trans_h
# define _trans_h

# include "global.h"


int	do_trans	(long flag, int drive);
char *	tosify		(const char *name, int flag, char *first, int mnamlength);


# endif /* _trans_h */
