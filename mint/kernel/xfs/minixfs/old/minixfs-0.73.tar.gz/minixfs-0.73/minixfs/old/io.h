
# ifndef _io_h
# define _io_h

# include "minix.h"

void	crwabs		(int rw, void *buf, unsigned num, long recno, int dev);

# endif /* _io_h */
