
# ifndef _main_h
# define _main_h

# include "global.h"


FILESYS *init	(struct kerinfo *k);

int	minix_sanity	(int drv);


# endif /* _main_h */
