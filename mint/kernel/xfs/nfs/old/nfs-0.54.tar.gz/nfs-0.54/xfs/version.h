/*
 * File : version.h
 *        Version numbers and patchlevel info
 */

#ifndef VERSION_H
#define VERSION_H


#define VERSION  "0.54�"

#if 1
#define PATCHLEVEL   "1"
#endif

#endif
