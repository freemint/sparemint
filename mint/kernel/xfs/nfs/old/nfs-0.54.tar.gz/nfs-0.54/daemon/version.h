/*
 * Copyright 1993, 1994 by Ulrich K�hn. All rights reserved.
 *
 * THIS PROGRAM COMES WITH ABSOLUTELY NO WARRANTY, NOT
 * EVEN THE IMPLIED WARRANTIES OF MERCHANTIBILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE. USE AT YOUR OWN
 * RISK.
 */

/*
 * File: version.h
 *       this file identifies the version of the nfs and mount daemon
 *
 * Author: Ulrich Kuehn
 */

#ifndef VERSION_H
#define VERSION_H

#define VERSION "v0.54�"

#endif
