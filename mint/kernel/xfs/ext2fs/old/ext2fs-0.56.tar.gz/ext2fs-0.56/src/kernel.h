/*
 * Filename:     kernel.h
 * Project:      FreeMiNT xfs skeleton
 * 
 * Note:         Please send suggestions, patches or bug reports to me
 *               or the MiNT mailing list (mint@).
 * 
 * Copying:      Copyright 1999 Frank Naumann (fnaumann@cs.uni-magdeburg.de)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

# ifndef _kernel_h
# define _kernel_h

/* Macros for kernel, bios and gemdos functions
 */

# define KERNEL	kernel
extern struct kerinfo *KERNEL;

# define MINT_MAJOR	(KERNEL->maj_version)
# define MINT_MINOR	(KERNEL->min_version)
# define DEFAULT_MODE	(KERNEL->default_perm)
# define DEFAULT_DMODE	(0777)

# define c_conws	(void)(*KERNEL->dos_tab[0x09])
# define f_select	(*KERNEL->dos_tab[0x11d])
# define d_cntl		(*KERNEL->dos_tab[0x130])
# define d_lock		(*KERNEL->dos_tab[0x135])
# define timestamp	(*KERNEL->dos_tab[0x2c])  ()
# define datestamp	(*KERNEL->dos_tab[0x2a])  ()
# define p_domain	(*KERNEL->dos_tab[0x119]) (-1)
# define FreeMemory	(*KERNEL->dos_tab[0x48])  (-1L)
# define p_getpid	(*KERNEL->dos_tab[0x10b])
# define p_getuid	(*KERNEL->dos_tab[0x10f])
# define p_getgid	(*KERNEL->dos_tab[0x114])
# define p_geteuid	(*KERNEL->dos_tab[0x138])
# define p_getegid	(*KERNEL->dos_tab[0x139])

# define changedrive	(*KERNEL->drvchng)
# define KERNEL_TRACE	(*KERNEL->trace)
# define KERNEL_DEBUG	(*KERNEL->debug)
# define KERNEL_ALERT	(*KERNEL->alert)
# define FATAL		(*KERNEL->fatal)
# define kmalloc	(*KERNEL->kmalloc)
# define kfree		(*KERNEL->kfree)
# define umalloc	(*KERNEL->umalloc)
# define ufree		(*KERNEL->ufree)
# define strnicmp	(*KERNEL->strnicmp)
# define stricmp	(*KERNEL->stricmp)
# define strlwr		(*KERNEL->strlwr)
# define strupr		(*KERNEL->strupr)
# define ksprintf	(*KERNEL->sprintf)
# define ms_time	(*KERNEL->millis_time)
# define unixtime	(*KERNEL->unixtim)
# define dostime	(*KERNEL->dostim)
# define nap		(*KERNEL->nap)
# define sleep		(*KERNEL->sleep)
# define wake		(*KERNEL->wake)
# define wakeselect	(*KERNEL->wakeselect)
# define denyshare	(*KERNEL->denyshare)
# define denylock	(*KERNEL->denylock)
# define addtimeout	(*KERNEL->addtimeout)
# define canceltimeout	(*KERNEL->canceltimeout)
# define addroottimeout	(*KERNEL->addroottimeout)
# define canroottimeout	(*KERNEL->cancelroottimeout)
# define ikill		(*KERNEL->ikill)
# define iwake		(*KERNEL->iwak)
# define bio		(*KERNEL->bio)


# endif /* _kernel_h */
