/*
 * Filename:     main.c
 * Project:      ext2 file system driver for MiNT
 * 
 * Note:         Please send suggestions, patches or bug reports to me
 *               or the MiNT mailing list (mint@).
 * 
 * Copying:      Copyright 1999 Frank Naumann (fnaumann@cs.uni-magdeburg.de)
 *               Copyright 1998, 1999 Axel Kaiser (DKaiser@AM-Gruppe.de)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

# include "ext2sys.h"
# include "kernel.h"
# include "version.h"


# define MSG_VERSION	str (VER_MAJOR) "." str (VER_MINOR)
# define MSG_BUILDDATE	__DATE__

# define MSG_BOOT	\
	"\033p Ext2 filesystem driver version " MSG_VERSION " \033q\r\n"

# define MSG_GREET	\
	"� 1998, 1999 by Axel Kaiser.\r\n" \
	"� " MSG_BUILDDATE " by Frank Naumann.\r\n"

# define MSG_ALPHA	\
	"\033p WARNING: This is an unstable version - alpha! \033q\7\r\n"

# define MSG_OLDMINT	\
	"\033pMiNT to old, this xfs requires at least a FreeMiNT 1.15!\033q\r\n"

# define MSG_BIOVERSION	\
	"\033pIncompatible FreeMiNT buffer cache version!\033q\r\n"

# define MSG_BIOREVISION	\
	"\033pFreeMiNT buffer cache revision to old!\033q\r\n"

# define MSG_FAILURE	\
	"\7Sorry, ext2.xfs NOT installed!\r\n\r\n"


struct kerinfo *KERNEL;

FILESYS *
ext2_init (struct kerinfo *k)
{
	KERNEL = k;
	
	c_conws (MSG_BOOT);
	c_conws (MSG_GREET);
# ifdef ALPHA
	c_conws (MSG_ALPHA);
# endif
	c_conws ("\r\n");
	
	DEBUG (("ext2 (%s): init", __FILE__));
	
	/* version check */
	if (MINT_MAJOR < 1 || (MINT_MAJOR == 1 && MINT_MINOR < 15))
	{
		c_conws (MSG_OLDMINT);
		c_conws (MSG_FAILURE);
		
		return NULL;
	}
	
	/* check buffer cache revision */
	if (bio.version != 3)
	{
		c_conws (MSG_BIOVERSION);
		c_conws (MSG_FAILURE);
		
		return NULL;		
	}
	
	/* check for revision 1 features */
	if (bio.revision < 1)	
	{
		c_conws (MSG_BIOREVISION);
		c_conws (MSG_FAILURE);
		
		return NULL;		
	}
	
	DEBUG (("ext2 (%s): loaded and ready (k = %lx).", __FILE__, k));
	return &ext2_filesys;
}
