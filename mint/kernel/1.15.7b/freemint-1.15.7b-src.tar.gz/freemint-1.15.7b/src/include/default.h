/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1998-06
 * last change: 1999-01-17
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 */

# ifndef _DEFAULT_H
# define _DEFAULT_H

# include "misc.h"


/*
 * configuration modes
 */

# define ASK		(-1)
# define DISABLE	( 0)
# define ENABLE		( 1)


/*
 * useful makros
 */

# define MAX(a,b)	(a > b ? a : b)
# define MIN(a,b)	(a > b ? b : a)
# define ABS(val)	(val < 0 ? -val : val)


# ifdef __TURBOC__

/* Inline-Assembler: Intel-WORD <-> Motorola-WORD */
unsigned short SWAP68_W(unsigned short d0) 0xE058; /* ror.w #8,D0 */

/* Inline-Assembler: Intel-LONG <-> Motorola-LONG */
unsigned long rorw_8_d0(unsigned long d0) 0xE058;  /* ror.w #8,D0 */
unsigned long swap_d0(unsigned long d0) 0x4840;    /* swap  D0    */
# define SWAP68_L(d0) rorw_8_d0(swap_d0(rorw_8_d0(d0)))

# elif defined(__GNUC__)

# define SWAP68_W(val)	\
	(__builtin_constant_p (val) ? __const_SWAP16 (val) : __asm_SWAP16 (val))

FASTFN unsigned short
__const_SWAP16 (register unsigned short val)
{
	return (val >> 8) | (val << 8);
}

FASTFN unsigned short
__asm_SWAP16 (register unsigned short val)
{
	__asm__
	(
		"rolw #8, %0"
		: "=d" (val)
		: "0" (val)
	);
	
	return val;
}

# define SWAP68_L(val)	\
	(__builtin_constant_p (val) ? __const_SWAP32 (val) : __asm_SWAP32 (val))

FASTFN unsigned long
__const_SWAP32 (unsigned long val)
{
	register unsigned long ret;
	
	ret  = (val << 24);
	ret |= (val <<  8) & 0x00ff0000;
	ret |= (val >>  8) & 0x0000ff00;
	ret |= (val >> 24);
	
	return ret;
}

FASTFN unsigned long
__asm_SWAP32 (register unsigned long val)
{
	__asm__
	(
		"rolw #8, %0;"
		"swap %0;"
		"rolw #8, %0;"
		: "=d" (val)
		: "0" (val)
	);
	
	return val;
}

# else /* !__TURBOC__ && !__GNUC__ */

# error "not defined for your compiler"

# endif /* __TURBOC__ */


# define str(x)		_stringify (x)
# define _stringify(x)	#x


# endif /* _DEFAULT_H */
