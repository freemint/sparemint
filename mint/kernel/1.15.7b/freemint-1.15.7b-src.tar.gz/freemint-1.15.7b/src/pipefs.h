/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _pipefs_h
# define _pipefs_h

#ifdef __TURBOC__
# include "include\mint.h"
# include "include\file.h"
#else
# include "include/mint.h"
# include "include/file.h"
#endif


struct fifo {
	char	name[NAME_MAX+1]; /* FIFO's name */
	struct timeval mtime;	/* mtime */
	struct timeval ctime;	/* ctime */
	short	dosflags;	/* DOS flags, e.g. FA_RDONLY, FA_HIDDEN */
	ushort	mode;		/* file access mode, for XATTR */
	ushort	uid, gid;	/* file owner; uid and gid */
	short	flags;		/* various other flags (e.g. O_TTY) */
	short	lockpid;	/* pid of locking process */
	short	cursrate;	/* cursor flash rate for pseudo TTY's */
	struct tty *tty;	/* tty struct for pseudo TTY's */
	struct pipe *inp;	/* pipe for reads */
	struct pipe *outp;	/* pipe for writes (0 if unidirectional) */
	struct fifo *next;	/* link to next FIFO in list */
	FILEPTR *open;		/* open file pointers for this fifo */
};

extern struct fifo* piperoot;
extern struct timeval pipestamp;

extern FILESYS pipe_filesys;


# endif /* _pipefs_h */
