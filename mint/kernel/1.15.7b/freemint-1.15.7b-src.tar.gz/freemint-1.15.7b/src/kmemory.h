/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1998-09-10
 * last change:	1998-
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 */

# ifndef _kmemory_h
# define _kmemory_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


MEMREGION *	_kmr_get	(void);
void		_kmr_free	(MEMREGION *ptr);

void *	_cdecl	_kcore		(ulong size);	/* ST-RAM alloc */
void *	_cdecl	_kmalloc	(ulong size);	/* TT-RAM alloc */
void	_cdecl	_kfree		(void *place);
void *	_cdecl	_umalloc	(ulong size);	/* user space alloc */
void	_cdecl	_ufree		(void *place);	/* user space free */


void	init_kmemory		(void);		/* initalize km allocator */
long	km_config		(long mode, long arg);

# define KM_STAT_DUMP	1


# define kmr_get		_kmr_get
# define kmr_free		_kmr_free


# if 1
# define kcore			_kcore
# else
FASTFN void *
__kcore (ulong size, char *file, long line)
{
	void *ptr = _kcore (size);
	FORCE ("%s, %ld: kcore (%lu -> %lx) called!", file, line, size, ptr);
	return ptr;
}
# define kcore			__kcore (size, __FILE__, __LINE__)
# endif

# if 1
# define kmalloc		_kmalloc
# else
FASTFN void *
__kmalloc (ulong size, char *file, long line)
{
	void *ptr;
	FORCE ("%s, %ld: kmalloc (%lu) called!", file, line, size);
	ptr = _kmalloc (size);
	FORCE ("%s, %ld: kmalloc return %lx.", file, line, ptr);
	return ptr;
}
# define kmalloc(size)		__kmalloc (size, __FILE__, __LINE__)
# endif


# if 1
# define kfree			_kfree
# else
FASTFN void
__kfree (void *place, char *file, long line)
{
	FORCE ("%s, %ld: kfree (%lx) called!", file, line, place);
	return _kfree (place);
}
# define kfree(place)		__kfree (place, __FILE__, __LINE__)
# endif


# if 1
# define umalloc		_umalloc
# else
FASTFN void *
__umalloc (ulong size, char *file, long line)
{
	void *ptr = _umalloc (size);
	FORCE ("%s, %ld: umalloc (%lu -> %lx) called!", file, line, size, ptr);
	return ptr;
}
# define umalloc(size)		__umalloc (size, __FILE__, __LINE__)
# endif


# if 1
# define ufree			_ufree
# else
FASTFN void
__ufree (void *place, char *file, long line)
{
	FORCE ("%s, %ld: ufree (%lx) called!", file, line, place);
	return _ufree (place);
}
# define ufree(place)		__ufree (place, __FILE__, __LINE__)
# endif


# endif /* _kmemory_h */
