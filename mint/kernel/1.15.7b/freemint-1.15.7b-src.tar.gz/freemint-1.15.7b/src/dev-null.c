/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1999-07-27
 * last change:	1999-07-27
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 * 
 * changes since last version:
 * 
 * 1999-07-27:
 * 
 * initial version; moved from biosfs.c
 * some cleanup
 * 
 * known bugs:
 * 
 * todo:
 * 
 * optimizations to do:
 * 
 */

# include "dev-null.h"

# include "util.h"	/* zero() */


DEVDRV null_device =
{
	null_open,
	null_write, null_read, null_lseek,
	null_ioctl, null_datime,
	null_close,
	null_select, null_unselect,
	NULL, NULL
};

DEVDRV zero_device =
{
	null_open,
	null_write, zero_read, null_lseek,
	zero_ioctl, null_datime,
	null_close,
	null_select, null_unselect,
	NULL, NULL
};


/* Driver routines for /dev/null
 */

long _cdecl
null_open (FILEPTR *f)
{
	UNUSED (f);
	
	return E_OK;
}

long _cdecl
null_write (FILEPTR *f, const char *buf, long bytes)
{
	UNUSED (f);
	UNUSED (buf);
	
	return bytes;
}

long _cdecl
null_read (FILEPTR *f, char *buf, long bytes)
{
	UNUSED (f);
	UNUSED (buf);
	UNUSED (bytes);
	
	return 0;
}

long _cdecl
null_lseek (FILEPTR *f, long where, int whence)
{
	UNUSED (f);
	UNUSED (whence);
	
	return (where == 0) ? 0 : EBADARG;
}

long _cdecl
null_ioctl (FILEPTR *f, int mode, void *buf)
{
	UNUSED (f);
	
	switch	(mode)
	{
		case FIONREAD:
			*((long *) buf) = 0;
			break;
		case FIONWRITE:
			*((long *) buf) = 1;
			break;
		case FIOEXCEPT:
			*((long *) buf) = 0;
		default:
			return ENOSYS;
	}
	
	return E_OK;
}

long _cdecl
null_datime (FILEPTR *f, ushort *timeptr, int rwflag)
{
	UNUSED (f);
	
	if (rwflag)
		return EACCES;
	
	*timeptr++ = timestamp;
	*timeptr = datestamp;
	
	return E_OK;
}

long _cdecl
null_close (FILEPTR *f, int pid)
{
	UNUSED (f);
	UNUSED (pid);
	
	return E_OK;
}

long _cdecl
null_select (FILEPTR *f, long p, int mode)
{
	UNUSED (f);
	UNUSED (p);
	
	if ((mode == O_RDONLY) || (mode == O_WRONLY))
	{
		/* we're always ready to read/write */
		return 1;
	}
	
	/* other things we don't care about */
	return E_OK;
}

void _cdecl
null_unselect (FILEPTR *f, long p, int mode)
{
	UNUSED (f); UNUSED (p); UNUSED (mode);
	/* nothing to do */
}


/* Driver routines for /dev/zero
 */

long _cdecl
zero_read (FILEPTR *f, char *buf, long bytes)
{
	UNUSED (f);
	
	zero (buf, bytes);
	return bytes;
}

long _cdecl
zero_ioctl (FILEPTR *f, int mode, void *buf)
{
	UNUSED (f);

	switch	(mode)
	{
		case FIONREAD:
			*((long *) buf) = 1;
			break;
		case FIONWRITE:
			*((long *) buf) = 0;
			break;
		case FIOEXCEPT:
			*((long *) buf) = 0;
		default:
			return ENOSYS;
	}
	
	return E_OK;
}
