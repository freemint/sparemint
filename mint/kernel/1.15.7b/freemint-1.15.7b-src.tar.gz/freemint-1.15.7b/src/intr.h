/* This file belongs to FreeMiNT,
 * it is not a part of the original MiNT distribution.
 */

# ifndef _intr_h
# define _intr_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


# if 0
short _cdecl	spl7		(void);
void _cdecl	spl		(short);
# endif
void _cdecl	reboot		(void);
void _cdecl	newmvec		(void);
void _cdecl	newjvec		(void);
long _cdecl	new_rwabs	(void);
long _cdecl	new_mediach	(void);
long _cdecl	new_getbpb	(void);


# endif /* _intr_h */
