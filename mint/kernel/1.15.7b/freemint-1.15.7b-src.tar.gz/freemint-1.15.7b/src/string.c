/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1998-11-22
 * last change: 1998-11-22
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions or bug reports to me or
 * the MiNT mailing list
 * 
 * 
 * changes since last version:
 * 
 * 1998-11-22:
 * 
 * - initial revision
 * 
 * known bugs:
 * 
 * todo:
 * 
 */

# include "string.h"


/*
 * ksprintf implements a very crude sprintf() function that provides only
 * what MiNT needs...
 *
 * NOTE: this sprintf probably doesn't conform to any standard at
 * all. It's only use in life is that it won't overflow fixed
 * size buffers (i.e. it won't try to write more than SPRINTF_MAX
 * characters into a string)
 */

static int
PUTC (char *p, int c, int *cnt, int width)
{
	int put = 1;
	
	if (*cnt <= 0) return 0;
	*p++ = c;
	*cnt -= 1;
	while (*cnt > 0 && --width > 0)
	{
		*p++ = ' ';
		*cnt -= 1;
		put++;
	}
	
	return put;
}

static int
PUTS (char *p, const char *s, int *cnt, int width)
{
	int put = 0;
	
	if (s == 0) s = "(null)";
	
	while (*cnt > 0 && *s)
	{
		*p++ = *s++;
		put++;
		*cnt -= 1;
		width--;
	}
	
	while (width-- > 0 && *cnt > 0)
	{
		*p++ = ' ';
		put++;
		*cnt -= 1;
	}
	
	return put;
}

static int
PUTL (char *p, ulong u, int base, int *cnt, int width, int fill_char)
{
	int put = 0;
	static char obuf[32];
	char *t;
	
	t = obuf;
	
	do {
		*t++ = "0123456789ABCDEF"[u % base];
		u /= base;
		width--;
	}
	while (u > 0);
	
	while (width-- > 0 && *cnt > 0)
	{
		*p++ = fill_char;
		put++;
		*cnt -= 1;
	}
	
	while (*cnt > 0 && t != obuf)
	{
		*p++ = *--t;
		put++;
		*cnt -= 1;
	}
	
	return put;
}

long _cdecl
vsprintf (char *buf, const char *fmt, va_list args)
{
	char *p = buf;
	
	char *s_arg;
	char c;
	char fill_char;
	
	int cnt = SPRINTF_MAX - 1;
	int width;
	int long_flag;
	
	int i_arg;
	long l_arg;
	
	
	while ((c = *fmt++) != 0)
	{
		if (c != '%')
		{
			p += PUTC (p, c, &cnt, 1);
			continue;
		}
		
		c = *fmt++;
		width = 0;
		long_flag = 0;
		fill_char = ' ';
		if (c == '0') fill_char = '0';
		
		while (c && isdigit (c))
		{
			width = 10 * width + (c - '0');
			c = *fmt++;
		}
		
		if (c == 'l' || c == 'L')
		{
			long_flag = 1;
			c = *fmt++;
		}
		
		if (!c) break;
		
		switch (c)
		{
			case '%':
			{
				p += PUTC (p, c, &cnt, width);
				break;
			}
			case 'c':
			{
				i_arg = va_arg (args, int);
				p += PUTC (p, i_arg, &cnt, width);
				break;
			}
			case 's':
			{
				s_arg = va_arg (args, char *);
				p += PUTS (p, s_arg, &cnt, width);
				break;
			}
			case 'i':
			case 'd':
			{
				if (long_flag)
					l_arg = va_arg (args, long);
				else
					l_arg = va_arg (args, int);
				
				if (l_arg < 0)
				{
					p += PUTC (p, '-', &cnt, 1);
					width--;
					l_arg = -l_arg;
				}
				
				p += PUTL (p, l_arg, 10, &cnt, width, fill_char);
				break;
			}
			case 'o':
			{
				if (long_flag)
					l_arg = va_arg (args, long);
				else
					l_arg = va_arg (args, unsigned int);
				
				p += PUTL (p, l_arg, 8, &cnt, width, fill_char);
				break;
			}
			case 'x':
			{
				if (long_flag)
					l_arg = va_arg (args, long);
				else
					l_arg = va_arg (args, unsigned int);
				
				p += PUTL (p, l_arg, 16, &cnt, width, fill_char);
				break;
			}
			case 'u':
			{
				if (long_flag)
					l_arg = va_arg (args, long);
				else
					l_arg = va_arg (args, unsigned);
				
				p += PUTL (p, l_arg, 10, &cnt, width, fill_char);
				break;
			}
		}
	}
	
	*p = 0;
	
	return (p - buf);
}

long _cdecl
ksprintf (char *buf, const char *fmt, ...)
{
	va_list args;
	long foo;
	
	va_start (args, fmt);
	foo = vsprintf (buf, fmt, args);	
	va_end (args);
	
	return foo;
}


/*
 * converts a decimal string to an integer
 */

long _cdecl
_mint_atol (const char *s)
{
	long d = 0;
	int negflag = 0;
	int c;

	while (*s && isspace (*s)) s++;
	while (*s == '-' || *s == '+')
	{
		if (*s == '-')
			negflag ^= 1;
		s++;
	}
	while ((c = *s++) != 0 && isdigit (c))
	{
		d = 10 * d + (c - '0');
	}
	if (negflag) d = -d;
	
	return d;
}


uchar _mint_ctype[256] =
{
	_CTc, _CTc, _CTc, _CTc,				/* 0x00..0x03 */
	_CTc, _CTc, _CTc, _CTc,				/* 0x04..0x07 */
	_CTc, _CTc|_CTs, _CTc|_CTs, _CTc|_CTs,		/* 0x08..0x0B */
	_CTc|_CTs, _CTc|_CTs, _CTc, _CTc,		/* 0x0C..0x0F */

	_CTc, _CTc, _CTc, _CTc,				/* 0x10..0x13 */
	_CTc, _CTc, _CTc, _CTc,				/* 0x14..0x17 */
	_CTc, _CTc, _CTc, _CTc,				/* 0x18..0x1B */
	_CTc, _CTc, _CTc, _CTc,				/* 0x1C..0x1F */

	_CTs, _CTp, _CTp, _CTp,				/* 0x20..0x23 */
	_CTp, _CTp, _CTp, _CTp,				/* 0x24..0x27 */
	_CTp, _CTp, _CTp, _CTp,				/* 0x28..0x2B */
	_CTp, _CTp, _CTp, _CTp,				/* 0x2C..0x2F */

	_CTd|_CTx, _CTd|_CTx, _CTd|_CTx, _CTd|_CTx,	/* 0x30..0x33 */
	_CTd|_CTx, _CTd|_CTx, _CTd|_CTx, _CTd|_CTx,	/* 0x34..0x37 */
	_CTd|_CTx, _CTd|_CTx, _CTp, _CTp,		/* 0x38..0x3B */
	_CTp, _CTp, _CTp, _CTp,				/* 0x3C..0x3F */

	_CTp, _CTu|_CTx, _CTu|_CTx, _CTu|_CTx,		/* 0x40..0x43 */
	_CTu|_CTx, _CTu|_CTx, _CTu|_CTx, _CTu,		/* 0x44..0x47 */
	_CTu, _CTu, _CTu, _CTu,				/* 0x48..0x4B */
	_CTu, _CTu, _CTu, _CTu,				/* 0x4C..0x4F */

	_CTu, _CTu, _CTu, _CTu,				/* 0x50..0x53 */
	_CTu, _CTu, _CTu, _CTu,				/* 0x54..0x57 */
	_CTu, _CTu, _CTu, _CTp,				/* 0x58..0x5B */
	_CTp, _CTp, _CTp, _CTp,				/* 0x5C..0x5F */

	_CTp, _CTl|_CTx, _CTl|_CTx, _CTl|_CTx,		/* 0x60..0x63 */
	_CTl|_CTx, _CTl|_CTx, _CTl|_CTx, _CTl,		/* 0x64..0x67 */
	_CTl, _CTl, _CTl, _CTl,				/* 0x68..0x6B */
	_CTl, _CTl, _CTl, _CTl,				/* 0x6C..0x6F */

	_CTl, _CTl, _CTl, _CTl,				/* 0x70..0x73 */
	_CTl, _CTl, _CTl, _CTl,				/* 0x74..0x77 */
	_CTl, _CTl, _CTl, _CTp,				/* 0x78..0x7B */
	_CTp, _CTp, _CTp, _CTc,				/* 0x7C..0x7F */

	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x80..0x8F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x90..0x9F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xA0..0xAF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xB0..0xBF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xC0..0xCF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xD0..0xDF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xE0..0xEF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  /* 0xF0..0xFF */
};

int _cdecl
_mint_toupper (int c)
{
	return (islower (c) ? _toupper (c) : c);
}

int _cdecl
_mint_tolower(int c)
{
	return (isupper (c) ? _toupper (c) : c);
}


long _cdecl
_mint_strlen (const char *scan)
{
	register const char *start;
	
	start = scan + 1;
	while (*scan++)
		;
	
	return (long) (scan - start);
}


/*
 * Case sensitive comparison functions.
 */

long _cdecl
_mint_strcmp (const char *str1, const char *str2)
{
	register char c1, c2;
	
	do {
		c1 = *str1++;
		c2 = *str2++;
	}
	while (c1 && c1 == c2);
	
	return (long) (c1 - c2);
}

long _cdecl
_mint_strncmp (const char *str1, const char *str2, long len)
{
	register char c1, c2;

	do {
		c1 = *str1++;
		c2 = *str2++;
	}
	while (--len >= 0 && c1 && c1 == c2);
	
	if (len < 0)
		return 0L;
	
	return (long) (c1 - c2);
}


/*
 * Case insensitive string comparison. Note that this only returns
 * 0 (match) or nonzero (no match), and that the returned value
 * is not a reliable indicator of any "order".
 */

long _cdecl
_mint_stricmp (const char *str1, const char *str2)
{
	register char c1, c2;
	
	do {
		c1 = *str1++; if (isupper(c1)) c1 = _tolower(c1);
		c2 = *str2++; if (isupper(c2)) c2 = _tolower(c2);
	}
	while (c1 && c1 == c2);
	
	return (long) (c1 - c2);
}

long _cdecl
_mint_strnicmp (const char *str1, const char *str2, long len)
{
	register char c1, c2;

	do {
		c1 = *str1++; if (isupper(c1)) c1 = _tolower(c1);
		c2 = *str2++; if (isupper(c2)) c2 = _tolower(c2);
	}
	while (--len >= 0 && c1 && c1 == c2);
	
	if (len < 0 || c1 == c2)
		return 0;
	
	return (long) (c1 - c2);
}


char * _cdecl
_mint_strcpy (char *dst, const char *src)
{
	register char *_dst = dst;
	
	while ((*_dst++ = *src++) != 0) ;
	
	return dst;
}

char * _cdecl
_mint_strncpy (char *dst, const char *src, long len)
{
	register char *_dst = dst;
	
	while (--len >= 0 && (*_dst++ = *src++) != 0)
		continue;
	
	while (--len >= 0)
		*_dst++ = 0;
	
	return dst;
}

void _cdecl
_mint_strncpy_f (char *dst, const char *src, long len)
{
	while (*src && --len)
		*dst++ = *src++;
	
	*dst = '\0';
}

/*
 * string utilities: strlwr() converts a string to lower case,
 *                   strupr() converts it to upper case
 */

char * _cdecl
_mint_strlwr (char *s)
{
	char c;
	char *old = s;
	
	while ((c = *s) != 0)
	{
		if (isupper (c))
		{
			*s = _tolower(c);
		}
		s++;
	}
	
	return old;
}

char * _cdecl
_mint_strupr (char *s)
{
	char c;
	char *old = s;

	while ((c = *s) != 0)
	{
		if (islower (c))
		{
			*s = _toupper(c);
		}
		s++;
	}
	
	return old;
}


/*
 * strcat: concat two strings
 */

char * _cdecl
_mint_strcat (char *dst, const char *src)
{
	register char *_dscan;
	
	for (_dscan = dst; *_dscan; _dscan++) ;
	while ((*_dscan++ = *src++) != 0) ;
	
	return dst;
}

/*
 * strrchr: find the last occurence of a character in a string
 */

char * _cdecl
_mint_strrchr (const char *str, long which)
{
	register const char *s = str;
	register char *place = NULL;
	register uchar c;
	
	do {
		c = *s++;
		if (c == which)
			place = (char *) s - 1;
	}
	while (c);
	
	return place;
}

char * _cdecl
_mint_strrev (char *s)
{
	register char *q = s;
	
	if (*q)
	{
		register char *p = q;
		
		while (*++q)
			;
		
		while (--q > p)
		{
			register char c = *q;
			*q = *p;
			*p++ = c;
		}
	}
	
	return s;
}

void *
_mint_memchr (void *s, long search, ulong size)
{
	register char *scan = s;
	register char c = search;
	register ulong i;
	
	for (i = size; i > 0; i--)
	{
		if (*scan == c)
			return scan;
		else
			scan++;
	}
	
	return NULL;
}

/*
 * Case insensitive string comparison. note that this only returns
 * 0 (match) or nonzero (no match), and that the returned value
 * is not a reliable indicator of any "order".
 */

int _cdecl
_mint_o_stricmp (const char *str1, const char *str2)
{
	return _mint_o_strnicmp (str1, str2, 0x7fff);
}

int _cdecl
_mint_o_strnicmp (const char *str1, const char *str2, int len)
{
	register char c1, c2;

	do {
		c1 = *str1++; if (isupper(c1)) c1 = _tolower(c1);
		c2 = *str2++; if (isupper(c2)) c2 = _tolower(c2);
	}
	while (--len >= 0 && c1 && c1 == c2);
	
	if (len < 0 || c1 == c2)
		return 0;
	
	return (c1 - c2);
}
