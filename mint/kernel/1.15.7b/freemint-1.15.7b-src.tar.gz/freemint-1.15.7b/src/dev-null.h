/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file on other projects without my explicit
 * permission.
 */

/*
 * begin:	1999-07-27
 * last change: 1999-07-27
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 *  
 */

# ifndef _dev_null_h
# define _dev_null_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern DEVDRV null_device;
extern DEVDRV zero_device;

long	_cdecl null_open	(FILEPTR *f);
long	_cdecl null_write	(FILEPTR *f, const char *buf, long bytes);
long	_cdecl null_read	(FILEPTR *f, char *buf, long bytes);
long	_cdecl null_lseek	(FILEPTR *f, long where, int whence);
long	_cdecl null_ioctl	(FILEPTR *f, int mode, void *buf);
long	_cdecl null_datime	(FILEPTR *f, ushort *time, int rwflag);
long	_cdecl null_close	(FILEPTR *f, int pid);
long	_cdecl null_select	(FILEPTR *f, long p, int mode);
void	_cdecl null_unselect	(FILEPTR *f, long p, int mode);

long	_cdecl zero_read	(FILEPTR *f, char *buf, long bytes);
long	_cdecl zero_ioctl	(FILEPTR *f, int mode, void *buf);


# endif /* _dev_null_h */
