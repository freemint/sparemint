/* This file belongs to FreeMiNT,
 * it is not a part of the original MiNT distribution.
 */

# ifndef _quickzero_h
# define _quickzero_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


void _cdecl	quickzero	(char *place, long size);


# endif /* _quickzero_h */
