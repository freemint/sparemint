/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _filesys_h
# define _filesys_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif

# include "proc.h"


/* external variables
 */

extern FILESYS *drives[NUM_DRIVES];
# define follow_links	((char *) -1L)


/* exported functions
 */

void xfs_block (FILESYS *fs, ushort dev);
void xfs_deblock (FILESYS *fs, ushort dev);

long getxattr (FILESYS *fs, fcookie *fc, XATTR *xattr);

void kill_cache (fcookie *dir, char *name);
long cache_lookup (fcookie *dir, char *name, fcookie *res);
void cache_init (void);
void clobber_cookie (fcookie *fc);
void init_drive (int drv);
void init_filesys (void);
void xfs_add (FILESYS *fs);
void load_modules (long type);
void close_filesys (void);
long _s_ync (void);
long _cdecl s_ync (void);
void _cdecl changedrv (ushort drv);
long disk_changed (int drv);
long relpath2cookie (fcookie *dir, const char *path, char *lastnm, fcookie *res, int depth);
long path2cookie (const char *path, char *lastname, fcookie *res);
void release_cookie (fcookie *fc);
void dup_cookie (fcookie *new, fcookie *old);
FILEPTR *new_fileptr (void);
void dispose_fileptr (FILEPTR *f);
int _cdecl denyshare (FILEPTR *list, FILEPTR *newfileptr);
int ngroupmatch (int group);
int denyaccess (XATTR *, unsigned);
LOCK * _cdecl denylock (LOCK *list, LOCK *newlock);
long dir_access (fcookie *, unsigned, unsigned *);
int has_wild (const char *name);
void copy8_3 (char *dest, const char *src);
int pat_match (const char *name, const char *template);
int samefile (fcookie *, fcookie *);


FASTFN void
xfs_lock (FILESYS *fs, ushort dev)
{
	if (!(fs->fsflags & FS_REENTRANT_L2))
		xfs_block (fs, dev);
}

FASTFN void
xfs_unlock (FILESYS *fs, ushort dev)
{
	if (!(fs->fsflags & FS_REENTRANT_L2))
		xfs_deblock (fs, dev);
}


FASTFN long
xfs_root (FILESYS *fs, int drv, fcookie *fc)
{
	register long r;
	
	xfs_lock (fs, drv);
	r = (*fs->root)(drv, fc);
	xfs_unlock (fs, drv);
	
	return r;
}

FASTFN long
xfs_lookup (FILESYS *fs, fcookie *dir, const char *name, fcookie *fc)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->lookup)(dir, name, fc);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN DEVDRV *
xfs_getdev (FILESYS *fs, fcookie *fc, long *devsp)
{
	return (*fs->getdev)(fc, devsp);
}
FASTFN long
xfs_getxattr (FILESYS *fs, fcookie *fc, XATTR *xattr)
{
	if (fs->getxattr)
	{
		register long r;
		
		xfs_lock (fs, fc->dev);
		r = (*fs->getxattr)(fc, xattr);
		xfs_unlock (fs, fc->dev);
		
		return r;
	}
	
	return getxattr (fs, fc, xattr);
}

FASTFN long
xfs_chattr (FILESYS *fs, fcookie *fc, int attr)
{
	register long r;
	
	xfs_lock (fs, fc->dev);
	r = (*fs->chattr)(fc, attr);
	xfs_unlock (fs, fc->dev);
	
	return r;
}
FASTFN long
xfs_chown (FILESYS *fs, fcookie *fc, int uid, int gid)
{
	register long r;
	
	xfs_lock (fs, fc->dev);
	r = (*fs->chown)(fc, uid, gid);
	xfs_unlock (fs, fc->dev);
	
	return r;
}
FASTFN long
xfs_chmode (FILESYS *fs, fcookie *fc, unsigned mode)
{
	register long r;
	
	xfs_lock (fs, fc->dev);
	r = (*fs->chmode)(fc, mode);
	xfs_unlock (fs, fc->dev);
	
	return r;
}

FASTFN long
xfs_mkdir (FILESYS *fs, fcookie *dir, const char *name, unsigned mode)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->mkdir)(dir, name, mode);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_rmdir (FILESYS *fs, fcookie *dir, const char *name)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->rmdir)(dir, name);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_creat (FILESYS *fs, fcookie *dir, const char *name, unsigned mode, int attr, fcookie *fc)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->creat)(dir, name, mode, attr, fc);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_remove (FILESYS *fs, fcookie *dir, const char *name)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->remove)(dir, name);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_getname (FILESYS *fs, fcookie *root, fcookie *dir, char *buf, int len)
{
	register long r;
	
	xfs_lock (fs, root->dev);
	r = (*fs->getname)(root, dir, buf, len);
	xfs_unlock (fs, root->dev);
	
	return r;
}
FASTFN long
xfs_rename (FILESYS *fs, fcookie *olddir, char *oldname, fcookie *newdir, const char *newname)
{
	register long r;
	
	xfs_lock (fs, olddir->dev);
	r = (*fs->rename)(olddir, oldname, newdir, newname);
	xfs_unlock (fs, olddir->dev);
	
	return r;
}

FASTFN long
xfs_opendir (FILESYS *fs, DIR *dirh, int flags)
{
	register long r;
	
	xfs_lock (fs, dirh->fc.dev);
	r = (*fs->opendir)(dirh, flags);
	xfs_unlock (fs, dirh->fc.dev);
	
	return r;
}
FASTFN long
xfs_readdir (FILESYS *fs, DIR *dirh, char *nm, int nmlen, fcookie *fc)
{
	register long r;
	
	xfs_lock (fs, dirh->fc.dev);
	r = (*fs->readdir)(dirh, nm, nmlen, fc);
	xfs_unlock (fs, dirh->fc.dev);
	
	return r;
}
FASTFN long
xfs_rewinddir (FILESYS *fs, DIR *dirh)
{
	register long r;
	
	xfs_lock (fs, dirh->fc.dev);
	r = (*fs->rewinddir)(dirh);
	xfs_unlock (fs, dirh->fc.dev);
	
	return r;
}
FASTFN long
xfs_closedir (FILESYS *fs, DIR *dirh)
{
	register long r;
	
	xfs_lock (fs, dirh->fc.dev);
	r = (*fs->closedir)(dirh);
	xfs_unlock (fs, dirh->fc.dev);
	
	return r;
}

FASTFN long
xfs_pathconf (FILESYS *fs, fcookie *dir, int which)
{
	return (*fs->pathconf)(dir, which);
}
FASTFN long
xfs_dfree (FILESYS *fs, fcookie *dir, long *buf)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->dfree)(dir, buf);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_writelabel (FILESYS *fs, fcookie *dir, const char *name)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->writelabel)(dir, name);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_readlabel (FILESYS *fs, fcookie *dir, char *name, int namelen)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->readlabel)(dir, name, namelen);
	xfs_unlock (fs, dir->dev);
	
	return r;
}

FASTFN long
xfs_symlink (FILESYS *fs, fcookie *dir, const char *name, const char *to)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->symlink)(dir, name , to);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_readlink (FILESYS *fs, fcookie *fc, char *buf, int len)
{
	register long r;
	
	xfs_lock (fs, fc->dev);
	r = (*fs->readlink)(fc, buf, len);
	xfs_unlock (fs, fc->dev);
	
	return r;
}
FASTFN long
xfs_hardlink (FILESYS *fs, fcookie *fromdir, const char *fromname, fcookie *todir, const char *toname)
{
	register long r;
	
	xfs_lock (fs, fromdir->dev);
	r = (*fs->hardlink)(fromdir, fromname, todir, toname);
	xfs_unlock (fs, fromdir->dev);
	
	return r;
}
FASTFN long
xfs_fscntl (FILESYS *fs, fcookie *dir, const char *name, int cmd, long arg)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->fscntl)(dir, name, cmd, arg);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_dskchng (FILESYS *fs, int drv, int mode)
{
	register long r;
	
	xfs_lock (fs, drv);
	r = (*fs->dskchng)(drv, mode);
	xfs_unlock (fs, drv);
	
	return r;
}

FASTFN long
xfs_release (FILESYS *fs, fcookie *fc)
{
	return (*fs->release)(fc);
}
FASTFN long
xfs_dupcookie (FILESYS *fs, fcookie *dst, fcookie *src)
{
	return (*fs->dupcookie)(dst, src);
}

FASTFN long
xfs_mknod (FILESYS *fs, fcookie *dir, const char *name, ulong mode)
{
	register long r;
	
	xfs_lock (fs, dir->dev);
	r = (*fs->mknod)(dir, name, mode);
	xfs_unlock (fs, dir->dev);
	
	return r;
}
FASTFN long
xfs_unmount (FILESYS *fs, int drv)
{
	register long r;
	
	xfs_lock (fs, drv);
	r = (*fs->unmount)(drv);
	xfs_unlock (fs, drv);
	
	return r;
}
FASTFN long
xfs_stat64 (FILESYS *fs, fcookie *fc, STAT *stat)
{
	register long r;
	
	xfs_lock (fs, fc->dev);
	r = (*fs->stat64)(fc, stat);
	xfs_unlock (fs, fc->dev);
	
	return r;
}


# endif /* _filesys_h */
