/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _procfs_h
# define _procfs_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


extern struct timeval procfs_stmp;

void procfs_init (void);

extern FILESYS proc_filesys;


# endif /* _procfs_h */
