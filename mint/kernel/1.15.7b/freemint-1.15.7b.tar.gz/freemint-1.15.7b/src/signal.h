/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _signal_h
# define _signal_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


long _cdecl killgroup (int pgrp, int sig, int priv);
void post_sig (PROC *p, int sig);
long _cdecl ikill (int p, int sig);
void check_sigs (void);
void raise (int sig);
void bombs (int sig);
void handle_sig (int sig);
long _cdecl p_sigreturn (void);
void stop (int sig);
void exception (int sig);
void sigbus (void);
void sigaddr (void);
void sigill (void);
void sigpriv (void);
void sigfpe (void);
void sigtrap (void);
void haltformat (void);
void haltcpv (void);

# endif /* _signal_h */
