/*
 * This file belongs to FreeMiNT, it is not a part
 * of the original MiNT distribution.
 */

# ifndef _memset_h
# define _memset_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


void *memset (void *s, int ucharfill, ulong size);


# endif /* _memset_h */
