/* This file belongs to FreeMiNT,
 * it is not a part of the original MiNT distribution.
 */

# ifndef _quickmove_h
# define _quickmove_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


void _cdecl	quickmove	(void *dst, void *src, long nbytes);
void _cdecl	quickmovb	(void *dst, const void *src, long nbytes);


# endif /* _quickmove_h */
