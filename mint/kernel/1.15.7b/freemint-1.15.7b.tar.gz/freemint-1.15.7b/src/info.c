/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file for other projects without my
 * explicit permission.
 */

/*
 * begin:	1999-02-19
 * last change:	1999-02-19
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 * 
 * Set compilation time variables.
 */  

# include "info.h"

# include "build.h"
# include "cdef.h"
# include "version.h"


/* definitions in automatically created build.h
 */

ulong MiNT_version =
	  ((ulong) MAJ_VERSION << 24)
	| ((ulong) MIN_VERSION << 16)
	| ((ulong) PATCH_LEVEL << 8)
	| ((ulong) BETA_IDENT);

ulong MiNT_date =
	  ((ulong) BUILD_DAY << 24)
	| ((ulong) BUILD_MONTH << 16)
	| ((ulong) BUILD_YEAR);

ulong MiNT_time =
	  ((ulong) BUILD_DAY_OF_WEEK << 24)
	| ((ulong) BUILD_HOUR << 16)
	| ((ulong) BUILD_MIN << 8)
	| ((ulong) BUILD_SEC);


/* definitions in automatically created cdef.h
 */

char COMPILER_NAME [] = str (_COMPILER_NAME);
char COMPILER_OPTS [] = str (_COMPILER_OPTS);
char COMPILER_DEFS [] = str (_COMPILER_DEFS);

# ifdef __GNUC__
char COMPILER_VERS [] = str (__GNUC__) "." str (__GNUC_MINOR__);
# else
# error Unknown compiler
# endif
