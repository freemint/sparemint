/* This file belongs to FreeMiNT,
 * it is not a part of the original MiNT distribution.
 */

# ifndef _quickswap_h
# define _quickswap_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


void _cdecl	quickswap	(void *dst, void *src, long nbytes);


# endif /* _quickswap_h */
