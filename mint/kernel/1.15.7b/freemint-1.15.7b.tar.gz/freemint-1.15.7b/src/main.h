/*
 * This file has been modified as part of the FreeMiNT project. See
 * the file Changes.MH for details and dates.
 */

# ifndef _main_h
# define _main_h

# ifdef __TURBOC__
# include "include\mint.h"
# else
# include "include/mint.h"
# endif


/* global exported variables
 */

extern long mch;		/* machine */
extern long mcpu;		/* cpu type */
extern long fputype;		/* fpu type */
extern short fpu;		/* flag if fpu is present */
extern int tosvers;		/* the underlying TOS version */
extern int secure_mode;
extern int screen_boundary;
extern int flk;
extern int FalconVideo;
extern short ste_video;

extern int mint_errno;

# define MAXLANG 6	/* languages supported */
extern int gl_lang;

# ifdef OLDTOSFS
extern long gemdos_version;
# endif

# ifdef VM_EXTENSION
extern int vm_in_use;
extern ulong st_left_after_vm;
# endif


typedef struct kbdvbase KBDVEC;
struct kbdvbase
{
	long	midivec;
	long	vkbderr;
	long	vmiderr;
	long	statvec;
	long	mousevec;
	long	clockvec;
	long	joyvec;
	long	midisys;
	long	ikbdsys;
	short	drvstat;	/* Non-zero if a packet is currently transmitted. */
};

extern KBDVEC *syskey;


void	boot_print	(const char *s);
void	boot_printf	(const char *fmt, ...);

void	restr_intr	(void);
void	init		(void);
void	install_cookies	(void);


# endif /* _main_h */
