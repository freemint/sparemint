#include "file.h"
#include "kerbind.h"
#include "cookie.h"

short
get_cookie (long tag, long *val)
{
	COOKIE *jar = *CJAR;

	if (!jar)
		return -1;
	for ( ; jar->tag; ++jar) {
		if (jar->tag == tag) {
			*val = jar->value;
			return 0;
		}
	}
	return -1;
}
