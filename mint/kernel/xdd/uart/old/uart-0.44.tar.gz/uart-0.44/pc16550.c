/*
 * Filename:     
 * Version:      
 * Author:       Frank Naumann
 * Started:      1999-07-28
 * Last Updated: 1999-12-15
 * Target O/S:   TOS/MiNT
 * Description:  
 * 
 * Note:         Please send suggestions, patches or bug reports to me
 *               or the MiNT mailing list <mint@fishpool.com>.
 * 
 * Copying:      Copyright 1999 Frank Naumann <fnaumann@cs.uni-magdeburg.de>
 *               Portions copyright 1998, 1999 Rainer Mannigel, Michael Schwingen.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * 
 * changes since last version:
 * 
 * 1999-12-15:	(v0.44)
 * 
 * - new: software handshake work now also correct
 * - new: rewritten completly top & bottom half synchronization
 *        it's now hopefully almost ok :-) without any blocking
 *        in the top half and without any negative interaction
 * - new: completed BIOS emulation code (rsconf)
 * 
 * 1999-12-14:	(v0.43)
 * 
 * - new: CTS handling completly rewritten
 *        lot of code reorganisation and movement
 * 
 * 1999-12-01:	(v0.42)
 * 
 * - fix: added CTS checking in the write interrupt routine
 * - fix: forced HSMODEM devices to be opened in non blocking mode
 * - new: added BIOS emulation code
 * - new: support new DEV_INSTALL2 opcode for BIOS remap
 * 
 * 1999-10-04:	(v0.41)
 * 
 * - new: changed to new errno header
 * - new: changed base name of the tty devices from tty to ttyS
 * 
 * 1999-08-21:	(v0.40)
 * 
 * - new: added MiNT version and Milan check
 * - new: added tty tread & twrite functions, ttys work now
 * - new: added automatic tty install (init, open)
 * - new: check & evaluate file sharing modes (open, close)
 * - new: wakeup sleeping processes on close
 * - fix: wrong return value in read & write for N_DELAY
 * 
 * 1999-08-14:	(v0.30b)
 * 
 * - new: optimized read data interrupt routine
 * - new: return EWOULDBLOCK in read & write if N_DELAY is set
 * 
 * 1999-08-09:	(v0.20b)
 * 
 * - inital revision
 * 
 * 
 * known bugs:
 * 
 * 
 * todo:
 * 
 * 
 * 
 * UART BIOS and XBIOS Routinen for Milan.
 * Rainer Mannigel, Michael Schwingen
 * 
 * We now support lots (currently 10) of UARTs, and interrupt sharing
 * between them. We install one interrupt handler for each physical
 * interrupt line that belongs to one or more UARTs, and that gets the
 * pointer to the first UART's iovar in its corresponding intr_iovar. The
 * iovars are chained together by the next field, so the interrupt handler
 * services one UART at a time as long as there are events left to be
 * handled and then goes on to the next UART.
 * 
 * Due to the braindamaged design using Bconmap() to access more than one
 * serial port, we do not get a useable device number in the BIOS calls
 * (Bconin/out/stat/ostat), which means that we have to provide one entry
 * point for each of these routines (and for Rsconf, which gets no device
 * numbger at all) for every port we want to handle - this is why there is a 
 * statical limit - these routines are in stubs.s
 */

/* FreeMiNT header */
# include <default.h>
# include <dcntl.h>
# include <file.h>
# include <fstring.h>
# define __KERNEL__
# include <errno.h>

# include <osbind.h>

# include "kernel.h"
# include "rsvf.h"
# include "pc16550.h"


/*
 * version
 */

# define VER_MAJOR	0
# define VER_MINOR	44
# define VER_STATUS	


/*
 * debugging stuff
 */

# if 0
# define DEV_DEBUG	1
# endif

# if 0
# define INT_DEBUG	1
# endif


/*
 * default settings
 */

# define RSVF_BASENAME	"serial"
# define RSVF_OFFSETT	1

# define TTY_BASENAME	"ttyS"
# define TTY_OFFSETT	1

# define BDEV_OFFSET	7


# define IOBUFSIZE	4096

# define MAX_PORTS	10
# define MAX_INTS	 5	/* 2 onboard + 3 ISA cards */


/*
 * messages
 */

# define MSG_VERSION	str (VER_MAJOR) "." str (VER_MINOR) str (VER_STATUS) 
# define MSG_BUILDDATE	__DATE__

# define MSG_BOOT	\
	"\033p Milan UART serial driver version " MSG_VERSION " \033q\r\n"

# define MSG_GREET	\
	"� 1998, 1999 by Rainer Mannigel, Michael Schwingen.\r\n" \
	"� " MSG_BUILDDATE " by Frank Naumann <fnaumann@cs.uni-magdeburg.de>.\r\n\r\n"

# define MSG_MINT	\
	"\033pMiNT to old!\033q\r\n"

# define MSG_MILAN	\
	"\033pThis driver require a Milan!\033q\r\n"

# define MSG_FAILURE	\
	"\7\r\nSorry, driver NOT installed - initialization failed!\r\n\r\n"


/****************************************************************************/
/* BEGIN kernel interface */

struct kerinfo *kernel;

/* END kernel interface */
/****************************************************************************/

/****************************************************************************/
/* BEGIN definition part */

typedef struct iorec IOREC;
struct iorec
{
	uchar	*buffer;	/* buffer location pointer */
        ushort	size;		/* maximum size of this buffer */
	volatile ushort head;	/* offset to next byte to be taken
				 * from this buffer */
	volatile ushort tail;	/* offset to next location available
		        	 * to insert a new byte */
	ushort	low_water;	/* amount of space in buffer before a "xon"
				 * may be sent to restore normal use of
				 * buffer */
	ushort	high_water;	/* amount of space used in buffer that
				 * trigger's the sending of a "xoff" signal
				 * to the host */
	ushort	res;		/* alignment */
};

typedef struct iovar IOVAR;
struct iovar
{
	UART	*regs;		/* UART register base address */
	IOVAR	*next;		/* for Interrupt-Sharing */
	
	ushort	state;		/* receiver state */
# define STATE_HARD		0x1		/* CTS is low */
# define STATE_SOFT		0x2		/* XOFF is set */
	
	ushort	shake;		/* handshake mode */
# define SHAKE_HARD		STATE_HARD	/* RTS/CTS handshake enabled */
# define SHAKE_SOFT		STATE_SOFT	/* XON/XOFF handshake enabled */
	
	uchar	rx_full;	/* input buffer full */
	uchar	tx_empty;	/* output buffer empty */
	
	uchar	sendnow;	/* one byte of control data, bypasses buffer */
	uchar	res1;		/* alignment */
	
	IOREC	input;		/* input buffer */
	IOREC	output;		/* output buffer */
	
	long	baudrate;	/* current baud rate value */
	long	baudbase;	/* crystal frequency / 16 */
	
	ushort	intr;		/* intr number */
	ushort	lockpid;	/* */
	
	FILEPTR	*open;		/* */
	TTY	tty;		/* */
};


# define XON		0x11
# define XOFF		0x13


/*
 * inline assembler primitives - atomic
 */
FASTFN ushort	splhigh		(void);
FASTFN void	splx		(ushort old_sr);

FASTFN void	dtr_off		(UART *regs);
FASTFN void	dtr_on		(UART *regs);

FASTFN void	rts_off		(UART *regs);
FASTFN void	rts_on		(UART *regs);

FASTFN uchar	intrs_off	(UART *regs);
FASTFN void	intrs_on	(UART *regs, uchar mask);

FASTFN void	brk_off		(UART *regs);
FASTFN void	brk_on		(UART *regs);

FASTFN void	txint_off	(UART *regs);
FASTFN void	txint_on	(UART *regs);


/*
 * initialization - top half
 */
FASTFN int	detect_uart	(UART *regs, ulong *baudbase);
FASTFN int	init_uart	(IOVAR **iovar, ushort base, int intr, long baudbase);
FASTFN void	init_pc16550	(void);
FASTFN void	reset_uart	(IOVAR *iovar);
DEVDRV *	_cdecl init	(struct kerinfo *k);


/*
 * buffer manipulation - mixed
 */
FASTFN int	iorec_empty	(IOREC *iorec);
FASTFN int	iorec_full	(IOREC *iorec);
FASTFN uchar	iorec_get	(IOREC *iorec);
FASTFN int	iorec_put	(IOREC *iorec, uchar data);
FASTFN long	iorec_used	(IOREC *iorec);
FASTFN long	iorec_free	(IOREC *iorec);


/*
 * interrupt handling - bottom half
 */
FASTFN void	pc16550_read_x	(IOVAR *iovar, UART *regs);
FASTFN void	pc16550_read_o	(IOVAR *iovar, UART *regs);
FASTFN void	pc16550_read	(IOVAR *iovar, UART *regs);
FASTFN void	pc16550_write	(IOVAR *iovar, UART *regs);
static void	pc16550_int	(void);

       void	pc16550_intx	(void);
       void	pc16550_int0	(void);
       void	pc16550_int1	(void);
       void	pc16550_int2	(void);
       void	pc16550_int3	(void);
       void	pc16550_int4	(void);


/* control functions - top half
 *
 */
static long	ctl_TIOCBAUD	(IOVAR *iovar, long *buf);
static void	ctl_TIOCGFLAGS	(IOVAR *iovar, ushort *buf);
static long	ctl_TIOCSFLAGS	(IOVAR *iovar, ushort flags);


/*
 * start primitives - top half
 */
static void	rx_start	(IOVAR *iovar);
static void	tx_start	(IOVAR *iovar);


/*
 * bios emulation - top half
 */
static long _cdecl	uart_instat	(int dev);
static long _cdecl	uart_in		(int dev);
static long _cdecl	uart_outstat	(int dev);
static long _cdecl	uart_out	(int dev, int c);
static long _cdecl	uart_rsconf	(int dev, int speed, int flowctl, int ucr, int rsr, int tsr, int scr);


/*
 * device driver routines - top half
 */
static long _cdecl	uart_open	(FILEPTR *f);
static long _cdecl	uart_writeb	(FILEPTR *f, const char *buf, long bytes);
static long _cdecl	uart_readb	(FILEPTR *f, char *buf, long bytes);
static long _cdecl	uart_twrite	(FILEPTR *f, const char *buf, long bytes);
static long _cdecl	uart_tread	(FILEPTR *f, char *buf, long bytes);
static long _cdecl	uart_lseek	(FILEPTR *f, long where, int whence);
static long _cdecl	uart_ioctl	(FILEPTR *f, int mode, void *buf);
static long _cdecl	uart_datime	(FILEPTR *f, ushort *timeptr, int rwflag);
static long _cdecl	uart_close	(FILEPTR *f, int pid);
static long _cdecl	uart_select	(FILEPTR *f, long proc, int mode);
static void _cdecl	uart_unselect	(FILEPTR *f, long proc, int mode);


/*
 * device driver maps
 */
static BDEVMAP bios_devtab =
{
	uart_instat, uart_in,
	uart_outstat, uart_out,
	uart_rsconf
};

static DEVDRV raw_devtab =
{
	uart_open,
	uart_writeb, uart_readb, uart_lseek, uart_ioctl, uart_datime,
	uart_close,
	uart_select, uart_unselect,
	NULL, NULL
};

static DEVDRV tty_devtab =
{
	uart_open,
	uart_twrite, uart_tread, uart_lseek, uart_ioctl, uart_datime,
	uart_close,
	uart_select, uart_unselect,
	uart_writeb, uart_readb
};


/*
 * debugging stuff
 */

# ifdef DEV_DEBUG
#  define DEBUG(x)	KERNEL_DEBUG x
#  define TRACE(x)	KERNEL_TRACE x
#  define ALERT(x)	KERNEL_ALERT x
# else
#  define DEBUG(x)
#  define TRACE(x)
#  define ALERT(x)	KERNEL_ALERT x
# endif

# ifdef INT_DEBUG
#  define DEBUG_I(x)	KERNEL_DEBUG x
#  define TRACE_I(x)	KERNEL_TRACE x
#  define ALERT_I(x)	KERNEL_ALERT x
# else
#  define DEBUG_I(x)
#  define TRACE_I(x)
#  define ALERT_I(x)	KERNEL_ALERT x
# endif

/* END definition part */
/****************************************************************************/

/****************************************************************************/
/* BEGIN global data definition & access implementation */

/*
 * global data structures
 */

static IOVAR *pc16550_iovar [MAX_PORTS * 2];

# define IOVARS(nr)		(pc16550_iovar [nr])
# define IOVAR_TTY_OFFSET	(MAX_PORTS)
# define IOVAR_MAX		(MAX_PORTS * 2 - 1)


/*
 * interrupt data structures
 */

/* ptr to first UART struct for each interrupt handler
 */
static IOVAR *intr_iovar [MAX_INTS];

/* ptr to interrupt handler routine, used for Setexc
 */
static void (*intr_handler [MAX_INTS])(void) =
{
	pc16550_int0,
	pc16550_int1,
	pc16550_int2,
	pc16550_int3,
	pc16550_int4
};

/* END global data & access implementation */
/****************************************************************************/

/****************************************************************************/
/* BEGIN inline assembler primitives - atomic */

FASTFN ushort
splhigh (void)
{
	ushort old_sr;
	
	__asm__ volatile
	(
		"move.w %%sr,%0;"
		"ori #0x0700,%%sr"
		: "=d" (old_sr)			/* output register */
		: 				/* input registers */
		: "cc"				/* clobbered */
	);
	
	return old_sr;
}

FASTFN void
splx (ushort old_sr)
{
	__asm__ volatile
	(
		"move.w %0,%%sr"
		: 				/* output register */
		: "d" (old_sr)			/* input registers */
		: "cc"				/* clobbered */
	);
}


FASTFN void
dtr_off (UART *regs)
{
# if 0
	regs->mcr &= ~DTRO;
# else
	asm volatile
	(
		"bclr.b #0,4(%0)" 	/* delete DTRO in MCR */
		:
		: "a" (regs)
		: "cc"
	);
# endif
	DEBUG_I (("PC16550 DTR off"));
}

FASTFN void
dtr_on (UART *regs)
{
# if 0
	regs->mcr |= DTRO;
# else
	asm volatile
	(
		"bset.b #0,4(%0)" 	/* set DTRO in MCR */
		:
		: "a" (regs)
		: "cc"
	);
# endif
	DEBUG_I (("PC16550 DTR on"));
}


FASTFN void
rts_off (UART *regs)
{
# if 0
	ushort sr = splhigh ();
	regs->mcr &= ~RTSO;
	splx (sr);
# else
	asm volatile
	(
		"bclr.b #1,4(%0)" 	/* delete RTSO in MCR */
		:
		: "a" (regs)
		: "cc"
	);
# endif  
	DEBUG_I (("PC16550 RTS off"));
}

FASTFN void
rts_on (UART *regs)
{
# if 0
	ushort sr = splhigh ();
	regs->mcr |= RTSO;
	splx (sr);
# else
	asm volatile
	(
		"bset.b #1,4(%0)" 	/* set RTSO in MCR */
		:
		: "a" (regs)
		: "cc"
	);
# endif
	DEBUG_I (("PC16550 RTS on"));
}


FASTFN uchar
intrs_off (UART *regs)
{
	register ushort sr;
	register uchar oldmask;
	
	sr = splhigh ();
	
	/* save old interrupts */
	oldmask = regs->ier;
	
	/* and lock */ 
	regs->ier = 0;
	
	splx (sr);
	
	DEBUG_I (("PC16550 intrs off"));
	return oldmask;
}

FASTFN void
intrs_on (UART *regs, uchar mask)
{
	ushort sr;
	
	sr = splhigh ();
	
	/* set new mask */ 
	regs->ier = mask;
	
	splx (sr);
	
	DEBUG_I (("PC16550 intrs on"));
}


FASTFN void
brk_off (UART *regs)
{
	regs->lcr &= ~SBRK;
	DEBUG_I (("PC16550 BRK off"));
}

FASTFN void
brk_on (UART *regs)
{
	regs->lcr |= SBRK;
	DEBUG_I (("PC16550 BRK on"));
}


FASTFN void
txint_off (UART *regs)
{
	DEBUG_I (("PC16550 TXINT off"));
# if 0
	regs->ier &= ~TXLDL_IE;
# else
	asm volatile
	(
		"bclr.b #1,1(%0)" 	/* delete TXLDL_IE in IER */
		:
		: "a" (regs)
		: "cc"
	);
# endif
}

FASTFN void
txint_on (UART *regs)
{
	DEBUG_I (("PC16550 TXINT on"));
# if 0
	regs->ier |= TXLDL_IE;
# else
	asm volatile
	(
		"bset.b #1,1(%0)" 	/* set TXLDL_IE in IER */
		:
		: "a" (regs)
		: "cc"
	);
# endif
}

/* END inline assembler primitives - atomic */
/****************************************************************************/

/****************************************************************************/
/* BEGIN initialization - top half */

/*
 * Autodetect a UART.
 * 
 * This routine first does some sanity checks to be sure that there is a
 * UART at the diven address. It then enables the interrupt and toggles the
 * IER to generate an interrupt, to autodetect the interrupt line. The
 * interrupt driver is disabled after this, which means that multiple UARTs
 * using the same interrupt will be detected OK even if the hardware does
 * not support sharing the interrupt line once all UARTs are enabled later.
 * The last thing is to measure the BRG crystal by transmitting some
 * characters (in loopback mode) with disabled FIFOs and measuring the time
 * needed by using MFP timer A.
 * 
 * We time sending 18 characters (or 180 bits) at the highest possible speed
 * (BRG divide by 1, or 115200 bps at 1.8432MHz). At a MFP clock of
 * 2.4576MHz and a :16 prescaler, this gives the following counted values:
 * 
 * Crystal (MHz)   count    BRG=1 rate
 * 1.8432          240      115200
 * 3.6864          120      230400
 * 7.3728           60      460800
 * 
 * 4.0             111      250000 (for MIDI cards)
 * 6.0              74      375000 (for MIDI cards)
 * 
 */

/* only in one place used -> FASTFN
 */
FASTFN int
detect_uart (UART *regs, ulong *baudbase)
{
	ulong rate = 115200;
	int intr = 0;
	int i;
	
	
	*baudbase = 0L;
	
	/* read LSR */ 
	(void) regs->lsr;
	/* now LSR may not be $FF! */
	if (regs->lsr == 0xff)
		return 0;
	
	regs->scr = 0x55;
	if (regs->scr != 0x55)
		return 0;
	
	regs->scr = 0xAA;
	if (regs->scr != 0xAA)
		return 0;
	
	/* set DLAB */
	regs->lcr = 0x83;
	
	/* set baudrate */
	regs->dlm = (115200 / rate) >> 8;
	regs->dll = (115200 / rate) & 0xFF;
	
	/* 8N1 */
	regs->lcr = 0x03;
	regs->ier = 0;
	
	/* Reset FIFOs */
	regs->fcr = RXFR | TXFR;
	/* Disable FIFOs */
	regs->fcr = 0;
	
	/* enable loopback */
	regs->mcr = LOOP;
	
	/* check loopback */
	if ((regs->msr & 0xf0) != 0)
		return 0;
	
	/* enable loopback */
	regs->mcr = LOOP | 0x0f;
	
	/* check loopback */
	if ((regs->msr & 0xf0) != 0xf0)
		return 0;
	
	DEBUG (("uart: on %lx seems to be a 16550, check intr", regs));
	
# if 0
	int_autoprobe_start ();
	
	regs->mcr = GI_EN;
	
	/* this will create enough INTs */
	regs->ier = 0x00;
	regs->ier = 0x0f;
	regs->ier = 0x00;
	regs->ier = 0x0f;
	
	/* short delay */
	for (i = 255; i >= 0; i--)
		(void) regs->rbr;
	
	regs->ier = 0;
	regs->mcr = 0;
	
	intr = int_autoprobe_end ();
# else
	if ((UART *) (0x03f8L + 0xc0000000L) == regs)
	{
		/* builtin port 1 */
		intr = 4;
	}
	else if ((UART *) (0x02f8L + 0xc0000000L) == regs)
	{
		/* builtin port 2 */
		intr = 3;
	}
	else
	{
		/* no detection available yet */
		intr = 0;
	}
# endif
	
	if (intr > 0)
	{
# if 0
		*baudbase = 115200L;
# else
/*		volatile uchar *tcdr = (volatile uchar *) 0xffffc103L + 17 * 4; */
		volatile uchar *tadr = (volatile uchar *) 0xffffc103L + 15 * 4;
		volatile uchar *tacr = (volatile uchar *) 0xffffc103L + 12 * 4;
		
		ushort sr;
		short time;
		
		
		sr = splhigh ();
		
		/* enable loopback */
		regs->mcr = LOOP; 
		
		*tacr = 0;
		*tadr = 0xff;
		while (*tadr != 0xff)
			;
		
		for (i = 0; i < 19; i++)
		{
			/* send 1 char */
			regs->thr = 0x00;
			
			/* wait until done */
			while ((regs->lsr & TXDE) == 0)
				;
			
			if (i == 0)
				*tacr = 3;
		}
		
		/* stop timer */
		*tacr = 0;
		time = 255 - *tadr;
		
		/* get Rx data */
		while ((regs->lsr & RXDA))
			(void) regs->rbr;
		
		/* disable loopback */
		regs->mcr = GI_EN;
		(void) regs->iir;
		(void) regs->msr;
		
		splx (sr);
		
		
		if      (time > 230 && time <= 250)	*baudbase = 115200L;
		else if (time > 115 && time <= 125)	*baudbase = 230400L;
		else if (time >  55 && time <=  65)	*baudbase = 460800L;
		else if (time > 105 && time <= 115)	*baudbase = 250000L;
		else if (time >  70 && time <=  80)	*baudbase = 375000L;
# endif
		
		DEBUG (("detect_clock: t = %d, baudbase = %lu", time, *baudbase));
	}
	
	/* Reset FIFOs */
	regs->fcr = FIFO_EN | RXFR | TXFR;
	regs->fcr = FIFO_EN | RXFTH_8;
	
	if ((regs->iir & 0xc0) != 0xc0)
	{
		DEBUG (("no 16550A at %lx, INT %i", regs, intr));
		return 0;
	}
	
	DEBUG (("detected 16550A at %lx, INT %i", regs, intr));
	return intr;
}

/* only in one place used -> FASTFN
 */
FASTFN int
init_uart (IOVAR **iovar, ushort base, int intr, long baudbase)
{
	char *buffer;
	
	*iovar = kmalloc (sizeof (**iovar));
	if (!*iovar)
		goto error;
	
	bzero (*iovar, sizeof (**iovar));
	
	buffer = kmalloc (2 * IOBUFSIZE);
	if (!buffer)
		goto error;
	
	(*iovar)->input.buffer = buffer;
	(*iovar)->output.buffer = buffer + IOBUFSIZE;
	
	(*iovar)->input.size = (*iovar)->output.size = IOBUFSIZE;
	(*iovar)->input.low_water = (*iovar)->output.low_water = 1 * (IOBUFSIZE / 4);
	(*iovar)->input.high_water = (*iovar)->output.high_water = 3 * (IOBUFSIZE / 4);
	
	(*iovar)->regs = (UART *) (0xC0000000L | base);
	(*iovar)->intr = intr;
	(*iovar)->baudbase = baudbase;
	
	return 1;
	
error:
	if (*iovar)
		kfree (*iovar);
	
	ALERT (("uart.xdd: kmalloc(%li, %li) fail, out of memory?", sizeof (**iovar), IOBUFSIZE));
	return 0;
}

FASTFN void
reset_uart (IOVAR *iovar)
{
	UART *regs = iovar->regs;
	long div;
	
	regs->mcr = 0;
	regs->ier = 0;
	
	iovar->baudrate = 9600;
	div = iovar->baudbase / iovar->baudrate;
	
	regs->lcr |= BNKSE;
	regs->dll = (div     ) & 0xFF;
	regs->dlm = (div >> 8) & 0xFF;
	regs->lcr &= ~BNKSE;
	
	/* Reset FIFOs */
	regs->fcr = FIFO_EN | RXFR | TXFR;
	/* Enable FIFOs, set Rcv Threshold */
	regs->fcr = FIFO_EN | RXFTH_8;
	
	/* 8bit char, 1 stopbit, no parity */
	regs->lcr = 3;
	
	/* soft line always on */
	iovar->state = STATE_SOFT;
	
	/* read current CTS state */
	if (!(regs->msr & CTSI))
		iovar->state |= STATE_HARD;
	
	/* RTS/CTS handshake */
	iovar->shake = SHAKE_HARD;
	
	/* tx buffer is empty here */
	iovar->tx_empty = 1;
	
	/* enable interrupts */
	regs->ier = RXHDL_IE | LS_IE | MS_IE;
	
	/* RTS on, DTR on, global interrupt enable */
	regs->mcr |= DTRO | RTSO | GI_EN;
}	

/* only in one place used -> FASTFN
 */
FASTFN void
init_pc16550 (void)
{
# define NUM_BASES 12
	ushort bases[NUM_BASES] =
	{
		0x03f8L, 0x02f8L,			/* on-board SERIAL1 + SERIAL2 */
		0x03e8L, 0x02e8L,
		0x02a0L, 0x02a8L, 0x02b0, 0x02b8,	/* first AST fourport */
		0x01a0L, 0x01a8L, 0x01b0, 0x01b8	/* second AST fourport */ 
	};
	ulong baudbase[NUM_BASES];
	uchar intr[NUM_BASES];
	
	static int did_init;
	
	int i, j;
	ushort sr;
	
	int current_iovar = 0;
	int intr_num = 0;
	
	
	if (!did_init)
	{
		for (i = 0; i < NUM_BASES; i++)
			intr[i] = detect_uart ((UART *) (bases[i] + 0xc0000000L), &baudbase[i]);
		
		did_init = 1;
	}
	
	DEBUG (("UARTS found:"));
	
	sr = splhigh ();
	for (i = 0; i < NUM_BASES; i++)
	{
		if (intr[i] && baudbase[i] && current_iovar < MAX_PORTS)
		{
			DEBUG (("base %x, intr %i, baudbase %lu", bases[i], intr[i], baudbase[i]));
			
			if (init_uart (&(IOVARS (current_iovar)), bases[i], intr[i], baudbase[i]))
				current_iovar++;
		}
	}
	
	/* install interrupt handlers
	 * chain iovars into a linked list per shared interrupt
	 */
	for (i = 0; i < current_iovar; i++)
	{
		int chain_int = 0;
		
		DEBUG (("installing INT for UART %d:",i));
		
		for (j = 0; j < i; j++)
			if (IOVARS (i)->intr == IOVARS (j)->intr)
				chain_int = j;
		
		if (chain_int)
		{
			DEBUG (("chaining iovar %d to iovar %d", i, chain_int));
			
			IOVARS (chain_int)->next = IOVARS (i);
			/* set_int_levelmode (IOVARS (i)->intr); */
		}
		else if (intr_num < MAX_INTS)
		{
			void *old;
			
			DEBUG (("allocating new int handler %d to iovar %d, INT %d", intr_num, i, IOVARS (i)->intr));
			
			intr_iovar[intr_num] = IOVARS (i);
			old = Setexc (80 + IOVARS (i)->intr, intr_handler[intr_num]);
			DEBUG (("old int handler = %lx", old));
			
			intr_num++;
		}
		else
			DEBUG (("ERROR: no free int handler for UART using int %d", IOVARS (i)->intr));
	}
	
	for (i = 0; i < MAX_PORTS && IOVARS (i); i++)
	{
		reset_uart (IOVARS (i));
	}
	
	splx (sr);
}

DEVDRV * _cdecl
init (struct kerinfo *k)
{
	RSVF *rsvfptr;
	RSVF *rsvf;
	char *ptr;
	long mch;
	int initialized;
	int i;
	
	struct dev_descr raw_dev_descriptor =
	{
		&raw_devtab,
		0,		/* dinfo -> fc.aux */
		0,		/* flags */
		NULL,		/* struct tty * */
		0,		/* drvsize */
		S_IFCHR |
		S_IRUSR |
		S_IWUSR |
		S_IRGRP |
		S_IWGRP |
		S_IROTH |
		S_IWOTH,	/* fmode */
		&bios_devtab,	/* bdevmap */
		0,		/* bdev */
		0		/* reserved */
	};
	
	struct dev_descr tty_dev_descriptor =
	{
		&tty_devtab,
		0,		/* dinfo -> fc.aux */
		O_TTY,		/* flags */
		NULL,		/* struct tty * */
		44,		/* drvsize */
		S_IFCHR |
		S_IRUSR |
		S_IWUSR |
		S_IRGRP |
		S_IWGRP |
		S_IROTH |
		S_IWOTH,	/* fmode */
		NULL,		/* bdevmap */
		0,		/* bdev */
		0		/* reserved */
	};
	
	
	kernel = k;
	
	c_conws (MSG_BOOT);
	c_conws (MSG_GREET);
	
	DEBUG (("%s: enter init", __FILE__));
	
	if ((MINT_MAJOR == 0)
		|| ((MINT_MAJOR == 1) && (MINT_MINOR < 15)))
	{
		c_conws (MSG_MINT);
		goto failure;
	}
	
# define SSYS_GETCOOKIE	8
# define COOKIE__MCH	0x5f4d4348L
# define MILAN_C	0x00040000L
	if ((s_system (SSYS_GETCOOKIE, COOKIE__MCH, (long) &mch) != 0)
		|| (mch != MILAN_C))
	{
		c_conws (MSG_MILAN);
		goto failure;
	}
	
	/* temporary until MiNT will do this */
# define RSVF_BUF 1024L
	rsvf = rsvfptr = (RSVF *) m_xalloc (RSVF_BUF, 0x40);
	if (!rsvf)
	{
		DEBUG (("%s: m_xalloc fail!", __FILE__));
		goto failure;
	}
	
	bzero (rsvf, RSVF_BUF);
	
	ptr = (char *) rsvf;
	ptr += 512;
	
	init_pc16550 ();
	initialized = 1;
	
	for (i = 0; i < MAX_PORTS && IOVARS (i); i++)
	{
		char name [64];
		
		
		ksprintf (name, "u:\\dev\\%s%i", RSVF_BASENAME, i + RSVF_OFFSETT);
		
		raw_dev_descriptor.dinfo = i;
		raw_dev_descriptor.tty = &(IOVARS (i)->tty);
		raw_dev_descriptor.bdev = BDEV_OFFSET + i;
		if ((d_cntl (DEV_INSTALL2, name, (long) &raw_dev_descriptor) >= 0)
			|| (d_cntl (DEV_INSTALL, name, (long) &raw_dev_descriptor) >= 0))
		{
			DEBUG (("%s: %s installed with BIOS remap", __FILE__, name));
			
			rsvfptr->data = ptr;
			rsvfptr->type = RSVF_PORT | RSVF_GEMDOS | RSVF_BIOS;
			rsvfptr->bdev = raw_dev_descriptor.bdev;
			
			ksprintf (rsvfptr->data, "%s%i", RSVF_BASENAME, i + RSVF_OFFSETT);
			
			DEBUG (("uart: installed %s on %i", rsvfptr->data, 7 + i));
			
			ptr += ((strlen (rsvfptr->data) + 1) + 3) & ~3;
			rsvfptr++;
		}
		
		
		ksprintf (name, "u:\\dev\\%s%i", TTY_BASENAME, i + TTY_OFFSETT);
		
		tty_dev_descriptor.dinfo = i + IOVAR_TTY_OFFSET;
		tty_dev_descriptor.tty = &(IOVARS (i)->tty);
		if (d_cntl (DEV_INSTALL, name, (long) &tty_dev_descriptor) >= 0)
		{
			DEBUG (("%s: %s installed", __FILE__, name));
			
			IOVARS (i + IOVAR_TTY_OFFSET) = IOVARS (i);
		}
	}
	
	if (initialized)
	{
# define COOKIE_RSVF	0x52535646L
# define SSYS_SETCOOKIE	9
		s_system (SSYS_SETCOOKIE, COOKIE_RSVF, (long) rsvf);
		
		return (DEVDRV *) 1;
	}
	
failure:
# if 0
	if (rsvf)
		m_free (rsvf);
# endif
	
	c_conws (MSG_FAILURE);
	return NULL;
}

/* END initialization - top half */
/****************************************************************************/

/****************************************************************************/
/* BEGIN buffer manipulation - mixed */

/* input:
 * 
 * - iorec_empty : top
 * - iorec_full  : -
 * - iorec_get   : top
 * - iorec_put   : bottom
 * - iorec_used  : bottom & top - uncritical
 * - iorec_free  : -
 * 
 * -> interrupt safe interaction
 * 
 * 
 * output:
 * 
 * - iorec_empty : bottom
 * - iorec_full  : -
 * - iorec_get   : bottom
 * - iorec_put   : top
 * - iorec_used  : top
 * - iorec_free  : top
 * 
 * -> interrupt safe interaction
 */

/* helper function */
FASTFN ushort
inc_ptr (ushort ptr, ushort size)
{
	if (++ptr >= size)
		ptr = 0;
	
	return ptr;
}

FASTFN int
iorec_empty (IOREC *iorec)
{
	return (iorec->head == iorec->tail);
}

FASTFN int
iorec_full (IOREC *iorec)
{
	return (iorec->head == inc_ptr (iorec->tail, iorec->size));
}

FASTFN uchar
iorec_get (IOREC *iorec)
{
	register ushort i = inc_ptr (iorec->head, iorec->size);
	register uchar data;
	
	data = iorec->buffer[i];
	iorec->head = i;
	
	return data;
}

FASTFN int
iorec_put (IOREC *iorec, uchar data)
{
	register ushort i = inc_ptr (iorec->tail, iorec->size);
	
	if (i == iorec->head)
	{
		/* buffer full */
		return 0;
	}
	
	iorec->buffer[i] = data;
	iorec->tail = i;
	
	return 1;
}

FASTFN long
iorec_used (IOREC *iorec)
{
	register long tmp;
	
	tmp = iorec->tail;
	tmp -= iorec->head;
	
	if (tmp < 0)
		tmp += iorec->size;
	
	return tmp;
}

FASTFN long
iorec_free (IOREC *iorec)
{
	register long tmp;
	
	tmp = iorec->head;
	tmp -= iorec->tail;
	
	if (tmp <= 0)
		tmp += iorec->size;
	
	return tmp;
}

/* END buffer manipulation - mixed */
/****************************************************************************/

/****************************************************************************/
/* BEGIN interrupt handling - bottom half */

/*
 * pc16550_read(): uart receive buffer full.
 * Holt Zeichen vom UART und schreibt es in den Puffer.
 * XON/XOFF- oder RTS/CTS-Mode wird beachtet.
 * 
 * only called from pc16550_int
 */

FASTFN void
pc16550_read_x (IOVAR *iovar, UART *regs)
{
	while (regs->lsr & RXDA)
	{
		register uchar data = regs->rbr;
		
		if (data == XOFF)
		{
			/* otherside can't accept more data */
			
			DEBUG_I (("pc16550_read_x: XOFF"));
			
			iovar->state |= STATE_SOFT;
			txint_off (iovar->regs);
		}
		else if (data == XON)
		{
			/* otherside ready now */
			
			DEBUG_I (("pc16550_read_x: XON"));
			
			iovar->state &= ~STATE_SOFT;
			txint_on (iovar->regs);
		}
		else
		{
			if (!iorec_put (&iovar->input, data))
			{
				DEBUG_I (("pc16550_read_x: buffer full!"));
			}
		}
	}
}

FASTFN void
pc16550_read_o (IOVAR *iovar, UART *regs)
{
	while (regs->lsr & RXDA)
	{
		register uchar data = regs->rbr;
		
		if (!iorec_put (&iovar->input, data))
		{
			DEBUG_I (("pc16550_read_o: buffer full!"));
		}
	}
}

FASTFN void
pc16550_read (IOVAR *iovar, UART *regs)
{
	if (iovar->shake & SHAKE_SOFT)	pc16550_read_x (iovar, regs);
	else				pc16550_read_o (iovar, regs);
	
	/* test the free space
	 */
	if (!iovar->rx_full && (iorec_used (&iovar->input) > iovar->input.high_water))
	{
		DEBUG_I (("pc16550_read: stop rx"));
		
		iovar->rx_full = 1;
		
		if (iovar->shake & SHAKE_HARD)
		{
			/* set rts off */
			rts_off (regs);
		}
		
		if (iovar->shake & SHAKE_SOFT)
		{
			/* send XOFF */
			iovar->sendnow = XOFF;
			
			/* enable interrupt */
			txint_on (regs);
		}
	}
}

/*
 * pc16550_write(): 
 * 
 * only called from pc16550_int
 */
FASTFN void
pc16550_write (IOVAR *iovar, UART *regs)
{
	register int count = 16;
	
	if (iovar->sendnow)
	{
		/* control byte
		 */
		
		DEBUG_I (("pc16550_write: send control %i", iovar->sendnow));
		
		regs->thr = iovar->sendnow;
		iovar->sendnow = 0;
		
		count--;
	}
	
	/* real data
	 */
	
	/* is somebody ready to receive data? */
	if (iovar->shake && (iovar->shake & iovar->state))
	{
		DEBUG_I (("pc16550_write: tx disabled - INT turned off, ier=$%x", regs->ier));
		
		/* disable interrupt */
		txint_off (regs);
	}
	else
	{
		while (count--)
		{
			if (iorec_empty (&iovar->output))
			{
				DEBUG_I (("pc16550_write: buffer empty, ier=$%x", regs->ier));
				
				/* buffer empty */
				iovar->tx_empty = 1;
				
				/* disable interrupt */
				txint_off (regs);
				
				break;
			}
			
			/* send character from buffer */
			regs->thr = iorec_get (&iovar->output);
		}
	}
}

/*
 * Der eigentliche Interrupthandler. Wird vom Assemblerteil aufgerufen.
 * HACK: Der IOVAR-Zeiger wird in A0 uebergeben!
 */
static void
pc16550_int (void)
{
	IOVAR *iovar;
	UART *regs;
	ushort sr;
	uchar event;
	
	asm volatile
	(
		"move.l %%a0,%0"
		: "=da" (iovar)		/* output register */
		: 			/* input registers */
		: "cc"			/* clobbered */
	);
	
next_uart:
	
	regs = iovar->regs;
	DEBUG_I (("pc16550_int: handling UART at %lx", regs));
	
	sr = splhigh ();
	
	while (!((event = (regs->iir & 0x0f)) & 1))
	{
		/* Int pending */
		
		DEBUG_I (("pc16550_int: event %d ", event));
		
		switch (event)
		{
			case 6:		/* Highest priority */
			{
				/* Parity error, framing error, data overrun
				 * or break event
				 */
				if (regs->lsr & OE)
					pc16550_read (iovar, regs);
				else
					(void) regs->rbr;
				
				break;
			}
			case 4:
			{
				/* Receive Buffer Register (RBR) full, or
				 * reception FIFO level equal to or above
				 * treshold
				 */
			}
			case 12:
			{
				/* At least one character is in the reception
				 * FIFO, and no character has been input to or
				 * read from the reception FIFO for four
				 * character times
				 */
				pc16550_read (iovar, regs);
				
				break;
			}
			case 2:
			{
				/* Transmitter Data Register Empty
				 */
				pc16550_write (iovar, regs);
				
				break;
			}
			case 0:
			{
				/* Any transition on /CTS, /DSR or /DCD or a low to
				 * high transition on /RI
				 */
				register uchar msr = regs->msr;
				
				if (msr & DCTS)
				{
					DEBUG_I (("pc16550_int: CTS state change -> %i", (msr & CTSI)));
					
					if (msr & CTSI)
					{
						/* CTS is on */
						
						iovar->state &= ~STATE_HARD;
						
						if (iovar->shake & SHAKE_HARD)
							txint_on (iovar->regs);
					}
					else
					{
						/* CTS is off */
						
						iovar->state |= STATE_HARD;
						
						if (iovar->shake & SHAKE_HARD)
							txint_off (iovar->regs);
					}
				}
				
				/* (msr & DDSR)
					; */
				
				/* (msr & TERI)
					; */
				
				/* (msr & DDCD)
					; */
				
				break;
			}
			default:
			{
				/* unknown event
				 */
				
				(void) regs->lsr;
				(void) regs->msr;
				
				DEBUG_I (("pc16550_int: unknown event, ignored"));
				break;
			}
		}
	}
	
	splx (sr);
	
	iovar = iovar->next;
	if (iovar)
	{
		DEBUG_I (("pc16550_int: continuing on next IOVAR!"));
		goto next_uart;
	}
	
	DEBUG_I (("pc16550_int: done"));
}

/* Interrupt-Routinen fuer PC16550 - rufen die eigentlichen C-Routinen auf
 */
void
pc16550_intx (void)
{
	(void) pc16550_int;	/* tell the compiler that we need it */
	
	asm volatile
	(
		"_pc16550_int0:
		 movem.l %%a0-%%a2/%%d0-%%d2,-(%%sp)
		 move.l  _intr_iovar,%%a0
		 bsr     _pc16550_int
		 movem.l (%%sp)+,%%a0-%%a2/%%d0-%%d2
		 rte"
		: 			/* output register */
		:  			/* input registers */
		 			/* clobbered */
	);
	
	asm volatile
	(
		"_pc16550_int1:
		 movem.l %%a0-%%a2/%%d0-%%d2,-(%%sp)
		 move.l  _intr_iovar+4,%%a0
		 bsr     _pc16550_int
		 movem.l (%%sp)+,%%a0-%%a2/%%d0-%%d2
		 rte"
		: 			/* output register */
		:  			/* input registers */
		 			/* clobbered */
	);
	
	asm volatile
	(
		"_pc16550_int2:
		 movem.l %%a0-%%a2/%%d0-%%d2,-(%%sp)
		 move.l  _intr_iovar+8,%%a0
		 bsr     _pc16550_int
		 movem.l (%%sp)+,%%a0-%%a2/%%d0-%%d2
		 rte"
		: 			/* output register */
		:  			/* input registers */
		 			/* clobbered */
	);
	
	asm volatile
	(
		"_pc16550_int3:
		 movem.l %%a0-%%a2/%%d0-%%d2,-(%%sp)
		 move.l  _intr_iovar+12,%%a0
		 bsr     _pc16550_int
		 movem.l (%%sp)+,%%a0-%%a2/%%d0-%%d2
		 rte"
		: 			/* output register */
		:  			/* input registers */
		 			/* clobbered */
	);
	
	asm volatile
	(
		"_pc16550_int4:
		 movem.l %%a0-%%a2/%%d0-%%d2,-(%%sp)
		 move.l  _intr_iovar+16,%%a0
		 bsr     _pc16550_int
		 movem.l (%%sp)+,%%a0-%%a2/%%d0-%%d2
		 rte"
		: 			/* output register */
		:  			/* input registers */
		 			/* clobbered */
	);
}

/* END interrupt handling - bottom half */
/****************************************************************************/

/****************************************************************************/
/* BEGIN  */

static void _cdecl
check_select (void)
{
	int flag = 0;
	int i;
	
	for (i = 0; IOVARS (i); i++)
	{
		IOVAR *iovar = IOVARS (i);
		
		if (iovar->tty.rsel)
		{
			if (!iorec_empty (&iovar->input))
				wakeselect (iovar->tty.rsel);
			else
				flag = 1;
		}
		
		if (iovar->tty.wsel)
		{
			if (iorec_free (&iovar->output))
				wakeselect (iovar->tty.wsel);
			else
				flag = 1;
		}
	}
	
	if (flag)
		addroottimeout (1000L, check_select, 0);
}

/* END  */
/****************************************************************************/

/****************************************************************************/
/* BEGIN ioctl functions */

static long
ctl_TIOCBAUD (IOVAR *iovar, long *buf)
{
	long speed = *buf;
	
	if (speed == -1)
	{
		/* current baudrate */
		
		*buf = iovar->baudrate;
	}
	else if (speed == 0)
	{
		/* clear dtr */
		
		dtr_off (iovar->regs);
	}
	else
	{
		/* set baudrate to speed, enable dtr */
		
		static const long table [] =
		{
			300, 600,
			1200, 1800, 2400, 3600, 4800, 9600,
			14400, 19200, 28800, 38400, 57600,
			115200, 230400, 460800,
			0
		};
		
		long baudrate;
		long div;
		
		div = iovar->baudbase / speed;
		
		if (div < 1)
			div = 1;
		if (div > 65534)
			div = 65534;
		
		baudrate = iovar->baudbase / div;
		
		if ((baudrate != speed) || (iovar->baudbase % div))
		{
			if (speed > iovar->baudbase)
			{
				baudrate = iovar->baudbase;
			}
			else
			{
				int i;
				
				baudrate = table [0];
				
				for (i = 0; table [i] != 0; i++)
				{
					if (speed > table [i] && speed <= iovar->baudbase)
						baudrate = table [i];
				}
			}
			
			*buf = baudrate;
			
			DEBUG (("ctl_TIOCBAUD: EBADARG error -> %li", baudrate));
			return EBADARG;
		}
		
		if (baudrate != iovar->baudrate)
		{
			UART *regs = iovar->regs;
			uchar oldmask;
			
			oldmask = intrs_off (regs);
			
			/* set new daudrate
			 */
			iovar->baudrate = baudrate;
			div = iovar->baudbase / baudrate;
			
			regs->lcr |= BNKSE;
			regs->dll = (div) & 0xFF;
			regs->dlm = (div >> 8) & 0xFF;
			regs->lcr &= ~BNKSE;
			
			/* Reset FIFOs */
			regs->fcr = FIFO_EN | RXFR | TXFR;
			/* Enable FIFOs, set Rcv Threshold */
			regs->fcr = FIFO_EN | RXFTH_8;
			
			intrs_on (regs, oldmask);
		}
		
		/* always enable dtr */
		dtr_on (iovar->regs);
	}
	
	return E_OK;
}

static void
ctl_TIOCGFLAGS (IOVAR *iovar, ushort *buf)
{
	ushort flags = 0;
	uchar lcr = iovar->regs->lcr;
	
	switch (lcr & WLS)
	{
		case 0: flags |= TF_5BIT; break;
		case 1: flags |= TF_6BIT; break;
		case 2: flags |= TF_7BIT; break;
		case 3: flags |= TF_8BIT; break;
	}
	
	if (lcr & STB)	flags |= TF_2STOP;
	else		flags |= TF_1STOP;
	
	if (lcr & PEN)
	{
		if (lcr & EPS)	flags |= T_EVENP;
		else		flags |= T_ODDP;
	}
	
	if (iovar->shake & SHAKE_SOFT)
		flags |= T_TANDEM;
	
	if (iovar->shake & SHAKE_HARD)
		flags |= T_RTSCTS;
	
	*buf = flags;
}

static long
ctl_TIOCSFLAGS (IOVAR *iovar, ushort flags)
{
	ushort lcr = iovar->regs->lcr;
	ushort flag = 0;
	
	lcr &= ~WLS;
	switch (flags & TF_CHARBITS)
	{
		case TF_5BIT:	lcr |= 0;		break;
		case TF_6BIT:	lcr |= 1;		break;
		case TF_7BIT:	lcr |= 2;		break;
		case TF_8BIT:	lcr |= 3;		break;
		default:	return EBADARG;		break;
	}
	
	switch (flags & TF_STOPBITS)
	{
		case TF_1STOP:	lcr &= ~STB;		break;
		case TF_15STOP:	return EBADARG;		break;
		case TF_2STOP:	lcr |= STB;		break;
		default:	return EBADARG;		break;
	}
	
	if (flags & (T_EVENP | T_ODDP))
	{
		if ((flags & (T_EVENP | T_ODDP)) == (T_EVENP | T_ODDP))
			return EBADARG;
		
		/* enable parity */
		lcr |= PEN;
		
		/* set even/odd parity */
		if (flags & T_EVENP)	lcr |= EPS;
		else			lcr &= ~EPS;
	}
	else
	{
		/* disable parity */
		lcr &= ~PEN;
		
		/* even/odd bit ignored in this case */
	}
	
	/* setup in register */
	iovar->regs->lcr = lcr;
	
	/* soft handshake */
	if (iovar->shake & SHAKE_SOFT)
	{
		if (!(flags & T_TANDEM))
		{
			iovar->shake &= ~SHAKE_SOFT;
			flag = 1;
		}
	}
	else
	{
		if (flags & T_TANDEM)
		{
			iovar->shake |= SHAKE_SOFT;
			iovar->state &= ~STATE_SOFT;
			flag = 1;
		}
	}
	
	/* hard handshake */
	if (iovar->shake & SHAKE_HARD)
	{
		if (!(flags & T_RTSCTS))
		{
			iovar->shake &= ~SHAKE_HARD;
			flag = 1;
		}
	}
	else
	{
		if (flags & T_RTSCTS)
		{
			iovar->shake |= SHAKE_HARD;
			
			/* update the CTS state bit manually
			 * to be safe, or???
			 */
			if (iovar->regs->msr & CTSI)
				iovar->state &= ~STATE_HARD;
			else
				iovar->state = STATE_HARD;
			
			flag = 1;
		}
	}
	
	/* enable transmitter
	 * otherwise we end in deadlocks because
	 * tx_empty && handshake interaction
	 */
	if (flag)
		txint_on (iovar->regs);
	
	return E_OK;
}

/* END ioctl functions */
/****************************************************************************/

/****************************************************************************/
/* BEGIN start primitives - top half */

static void
rx_start (IOVAR *iovar)
{
	if (iovar->rx_full)
	{
		DEBUG (("rx_start: start receiver"));
		
		if (iovar->shake & SHAKE_HARD)
		{
			/* set rts on */
			rts_on (iovar->regs);
		}
		
		if (iovar->shake & SHAKE_SOFT)
		{
			/* send XON */
			iovar->sendnow = XON;
			
			/* enable interrupt */
			txint_on (iovar->regs);
		}
		
		/* buffer no longer full */
		iovar->rx_full = 0;
	}
	else
	{
		DEBUG (("rx_start: buffer not full"));
	}
}

static void
tx_start (IOVAR *iovar)
{
	if (iovar->tx_empty)
	{
		DEBUG (("tx_start: start transmitter"));
		
		/* buffer contain data */
		iovar->tx_empty = 0;
		
		/* enable interrupt */
		txint_on (iovar->regs);
	}
	else
	{
		DEBUG (("tx_start: buffer not empty"));
	}
}

/* END start primitives - top half */
/****************************************************************************/

/****************************************************************************/
/* BEGIN bios emulation - top half */

static long _cdecl
uart_instat (int dev)
{
	IOVAR *iovar = IOVARS (dev - BDEV_OFFSET);
	IOREC *iorec = &iovar->input;
	long used;
	
	used = iorec_used (iorec);
	
	DEBUG (("uart_instat: leave (%li)", (used ? -1 : 0)));
	return (used ? -1 : 0);
}

static long _cdecl
uart_in (int dev)
{
	IOVAR *iovar = IOVARS (dev - BDEV_OFFSET);
	IOREC *iorec = &iovar->input;
	long ret;
	
	while (iorec_empty (iorec))
	{
		/* start receiver */
		rx_start (iovar);
		
		sleep (READY_Q, 0L);
	}
	
	ret = iorec_get (iorec);
	
	DEBUG (("uart_in: leave (%li)", ret));
	return ret;
}

static long _cdecl
uart_outstat (int dev)
{
	IOVAR *iovar = IOVARS (dev - BDEV_OFFSET);
	IOREC *iorec = &iovar->output;
	long free;
	
	free = iorec_free (iorec);
	free -= 4;
	if (free < 0)
		free = 0;
	
	DEBUG (("uart_outstat: leave (%li)", (free ? -1 : 0)));
	return (free ? -1 : 0);
}

static long _cdecl
uart_out (int dev, int c)
{
	IOVAR *iovar = IOVARS (dev - BDEV_OFFSET);
	IOREC *iorec = &iovar->output;
	
	while (!iorec_put (iorec, c))
	{
		sleep (READY_Q, 0L);
	}
	
	/* start transfer - interrupt controlled */
	tx_start (iovar);
	
	DEBUG (("uart_out: leave (E_OK)"));
	return E_OK;
}

/* 
 * rsconf modes
 * 
 * speed:
 * 
 * -2 - return current baudrate
 * -1 - no change
 *  0 - 19200
 *  1 - 9600
 *  2 - 4800
 *  3 - 3600
 *  4 - 2400
 *  5 - 2000
 *  6 - 1800
 *  7 - 1200
 *  8 - 600
 *  9 - 300
 * 10 - 200
 * 11 - 150	-> 115200	(HSMODEM)
 * 12 - 134	-> 57600	(HSMODEM)
 * 13 - 110	-> 38400	(HSMODEM)
 * 14 - 75
 * 15 - 50
 * 
 * flowctl:
 * 
 * -1 - no change
 *  0 - no handshake
 *  1 - soft (XON/XOFF)
 *  2 - hard (RTS/CTS)
 *  3 - hard & soft
 * 
 * ucr:
 * bit 5..6: wordlength: 00: 8, 01: 7, 10: 6, 11: 5
 * bit 3..4: stopbits: 01: 1, 10: 1.5, 11: 2, 00: invalid
 * bit 2   : 0: parity off  1: parity on
 * bit 1   : 0: odd parity, 1: even parity - only valid if parity is enabled
 * 
 * rsr: - not used, 0
 * tsr: - bit 3 break on/off
 * scr: - not used, 0
 */
static long _cdecl
uart_rsconf (int dev, int speed, int flowctl, int ucr, int rsr, int tsr, int scr)
{
	static ulong baud [16] =
	{
		19200, 9600, 4800, 3600, 2400, 2000, 1800, 1200,
		600, 300, 200, 115200, 57600, 38400, 75, 50
	};
	
	IOVAR *iovar = IOVARS (dev - BDEV_OFFSET);
	ushort modified = 0;
	ushort flags;
	ulong ret = 0;
	
	DEBUG (("uart_rsconf: enter %i, %i", dev, speed));
	
	if (speed != -1)
	{
		if (speed == -2)
			return iovar->baudrate;
		
		if ((ushort) speed < 16)
		{
			long baudrate = baud [(ushort) speed];
			
			ctl_TIOCBAUD (iovar, &baudrate);
		}
	}
	
	/* get the current flags */
	ctl_TIOCGFLAGS (iovar, &flags);
	
	if (flowctl != -1)
	{
		switch (flowctl)
		{
			case 0:
			{
				flags &= ~T_TANDEM;
				flags &= ~T_RTSCTS;
				break;
			}
			case 1:
			{
				flags |= T_TANDEM;
				flags &= ~T_RTSCTS;
				break;
			}
			case 2:
			{
				flags &= ~T_TANDEM;
				flags |= T_RTSCTS;
				break;
			}
			case 3:
			{
				flags |= T_TANDEM;
				flags |= T_RTSCTS;
				break;
			}
		}
		
		modified = 1;
	}
	
	if (ucr != -1)
	{
		flags &= ~TF_CHARBITS;
		flags |= (ucr & 0x60) >> 3;
		
		flags &= ~TF_STOPBITS;
		flags |= (ucr & 0x18) >> 3;
		
		if ((flags & TF_CHARBITS) == TF_15STOP)
		{
			flags &= ~TF_STOPBITS;
			flags |= TF_1STOP;
		}
		
		flags &= ~(T_EVENP | T_ODDP);
		if (ucr & 0x4)
		{
			if (ucr & 0x2)
				flags |= T_EVENP;
			else
				flags |= T_ODDP;
		}
		
		modified = 1;
	}
	
	if (modified)
	{
		/* set the new flags */
		ctl_TIOCSFLAGS (iovar, flags);
	}
	
	if (tsr != -1)
	{
		if (tsr & 0x8)
			brk_on (iovar->regs);
		else
			brk_off (iovar->regs);
	}
	
	
	/* now construct the return value
	 */
	
	/* get the current flags */
	ctl_TIOCGFLAGS (iovar, &flags);
	
	/* ucr */
	ret |= ((((long) (flags & TF_CHARBITS)) << 3) << 24);
	ret |= ((((long) (flags & TF_STOPBITS)) << 3) << 24);
	
	if (flags & (T_EVENP | T_ODDP))
	{
		ret |= (0x4L << 24);
		if (flags & T_EVENP)
			ret |= (0x2L << 24);
	}
	
	/* tsr */
	if (iovar->regs->lcr & SBRK)
		ret |= (0x8L << 8);
	
	return ret;
}

/* END bios emulation - top half */
/****************************************************************************/

/****************************************************************************/
/* BEGIN device driver routines - top half */

static long _cdecl
uart_open (FILEPTR *f)
{
	ushort dev = f->fc.aux;
	IOVAR *iovar;
	
	DEBUG (("uart_open [%i]: enter (%lx)", f->fc.aux, f->flags));
	
	if (dev > IOVAR_MAX)
		return EACCES;
	
	iovar = IOVARS (dev);
	
	if (iovar->open && denyshare (iovar->open, f))
	{
		DEBUG (("uart_open: file sharing denied"));
		return EACCES;
	}
	
	f->pos = 0;
	f->next = iovar->open;
	iovar->open = f;
	
	if (dev >= IOVAR_TTY_OFFSET)
		f->flags |= O_TTY;
	else
		f->flags |= O_NDELAY;
	
	return E_OK;
}

static long _cdecl
uart_writeb (FILEPTR *f, const char *buf, long bytes)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	IOREC *iorec = &iovar->output;
	long done = 0;
	
	DEBUG (("uart_writeb [%i]: enter (%lx, %ld)", f->fc.aux, buf, bytes));
	for (;;)
	{
		/* copy as much as possible */
		while ((bytes > 0) && iorec_put (iorec, *buf))
		{
			/* DEBUG (("%x - %c", (int) *buf, *buf)); */
			
			buf++; done++;
			bytes--;
		}
		
		/* start transfer - interrupt controlled */
		tx_start (iovar);
		
		if (f->flags & O_NDELAY)
		{
			if (!done)
			{
				/* return EWOULDBLOCK only for non HSMODEM devices */
				if (f->flags & O_TTY)
					done = EWOULDBLOCK;
			}
			
			break;
		}
		
		if (!bytes)
			break;
		
		/* sleep until there is enough room in the buffer
		 * to continue
		 */
		while (iorec_used (iorec) > iorec->high_water)
			sleep (READY_Q, 0L);
	}
	
	DEBUG (("uart_writeb: leave (%ld)", done));
	return done;
}

static long _cdecl
uart_readb (FILEPTR *f, char *buf, long bytes)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	IOREC *iorec = &iovar->input;
	long done = 0;
	
	DEBUG (("uart_readb [%i]: enter (%lx, %ld)", f->fc.aux, buf, bytes));
	for (;;)
	{
		/* copy as much as possible */
		while ((bytes > 0) && !iorec_empty (iorec))
		{
			*buf = iorec_get (iorec);
			/* DEBUG (("%x - %c", (int) *buf, *buf)); */
			
			buf++; done++;
			bytes--;
		}
		
		if (iorec_used (iorec) < iorec->low_water)
			/* start receiver */
			rx_start (iovar);
		
		if (f->flags & O_NDELAY)
		{
			if (!done)
			{
				/* return EWOULDBLOCK only for non HSMODEM devices */
				if (f->flags & O_TTY)
					done = EWOULDBLOCK;
			}
			
			break;
		}
		
		if (!bytes)
			break;
		
		/* sleep until we received enough data or the buffer
		 * become to full
		 */
		{
			long i;
			
			i = iorec_used (iorec);
			while ((i < bytes) && (i < iorec->high_water))
			{
				sleep (READY_Q, 0L);
				i = iorec_used (iorec);
			}
		}
	}
	
	DEBUG (("uart_readb: leave (%ld)", done));
	return done;
}

/*
 * Note: when a BIOS device is a terminal (i.e. has the O_TTY flag
 * set), bios_read and bios_write will only ever be called indirectly, via
 * tty_read and tty_write. That's why we can afford to play a bit fast and
 * loose with the pointers ("buf" is really going to point to a long) and
 * why we know that "bytes" is divisible by 4.
 */

static long _cdecl
uart_twrite (FILEPTR *f, const char *buf, long bytes)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	IOREC *iorec = &iovar->output;
	long done = 0;
	const long *r = (const long *) buf;
	
	DEBUG (("uart_twrite [%i]: enter (%lx, %ld)", f->fc.aux, buf, bytes));
	for (;;)
	{
		/* copy as much as possible */
		while ((bytes > 0) && iorec_put (iorec, (char) *r))
		{
			/* DEBUG (("%lx - %c", *r, (char) *r)); */
			
			r++; done += 4;
			bytes -= 4;
		}
		
		/* start transfer - interrupt controlled */
		tx_start (iovar);
		
		if (f->flags & O_NDELAY)
		{
			if (!done)
				done = EWOULDBLOCK;
			
			break;
		}
		
		if (!bytes)
			break;
		
		/* sleep until there is enough room in the buffer
		 * to continue
		 */
		while (iorec_used (iorec) > iorec->high_water)
			sleep (READY_Q, 0L);
	}
	
	DEBUG (("uart_twrite: leave (%ld)", done));
	return done;
}

static long _cdecl
uart_tread (FILEPTR *f, char *buf, long bytes)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	IOREC *iorec = &iovar->input;
	long done = 0;
	long *r = (long *) buf;
	
	DEBUG (("uart_tread [%i]: enter (%lx, %ld)", f->fc.aux, buf, bytes));
	for (;;)
	{
		/* copy as much as possible */
		while ((bytes > 0) && !iorec_empty (iorec))
		{
			*r = (long) iorec_get (iorec);
			/* DEBUG (("%lx - %c", *r, (char) *r)); */
			
			r++; done += 4;
			bytes -= 4;
		}
		
		if (iorec_used (iorec) < iorec->low_water)
			/* start receiver */
			rx_start (iovar);
		
		if (f->flags & O_NDELAY)
		{
			if (!done)
				done = EWOULDBLOCK;
			
			break;
		}
		
		if (!bytes)
			break;
		
		/* sleep until we received enough data or the buffer
		 * become to full
		 */
		{
			long i;
			
			i = iorec_used (iorec);
			while ((i < bytes) && (i < iorec->high_water))
			{
				sleep (READY_Q, 0L);
				i = iorec_used (iorec);
			}
		}
	}
	
	DEBUG (("uart_tread: leave (%ld)", done));
	return done;
}

static long _cdecl
uart_lseek (FILEPTR *f, long where, int whence)
{
	DEBUG (("uart_lseek [%i]: enter (%ld, %d)", f->fc.aux, where, whence));
	
	/* (terminal) devices are always at position 0 */
	return 0;
}

static long _cdecl
uart_ioctl (FILEPTR *f, int mode, void *buf)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	long r = E_OK;
	
	DEBUG (("uart_ioctl [%i]: (%x, (%c %i), %lx)", f->fc.aux, mode, (char) (mode >> 8), (mode & 0xff), buf));
	
	switch (mode)
	{
		case FIONREAD:
		{
			*(long *) buf = iorec_used (&iovar->input);
			break;
		}
		case FIONWRITE:
		{
			long bytes;
			
			bytes = iorec_free (&iovar->output);
			bytes -= 4;
			if (bytes < 0)
				bytes = 0;
			
			*(long *) buf = bytes;
			break;
		}
		case FIOEXCEPT:		/* anywhere documented? */
		{
			*(long *) buf = 0;
			break;
		}
		case TIOCFLUSH:
		{
			int flushtype;
			
			/* HSMODEM put the value itself in arg
			 * MiNT use arg as a pointer to the value
			 * 
			 * if opened as terminal we assume MiNT convention
			 * otherwise HSMODEM convention
			 * 
			 * ok, or?
			 */
			if (f->fc.aux >= IOVAR_TTY_OFFSET)
				flushtype = *(int *) buf;
			else
				flushtype = (int) ((long) buf);
			
			if (flushtype <= 0)
			{
				r = ENOSYS;
				break;
			}
			
			if (flushtype & 1)
			{
				IOREC *iorec = &(iovar->input);
				uchar oldmask;
				
				oldmask = intrs_off (iovar->regs);
				iorec->head = iorec->tail = 0;
				intrs_on (iovar->regs, oldmask);
			}
			
			if (flushtype & 2)
			{
				IOREC *iorec = &(iovar->output);
				uchar oldmask;
				
				oldmask = intrs_off (iovar->regs);
				iorec->head = iorec->tail = 0;
				intrs_on (iovar->regs, oldmask);
			}
			
			break;
		}
		case TIOCSTOP:		/* HSMODEM */
		{
			/* if (iovar->shake)
				rx_stop (iovar); */
			
			r = ENOSYS;
			break;
		}
		case TIOCSTART:		/* HSMODEM */
		{
			/* rx_start (iovar); */
			
			r = ENOSYS;
			break;
		}
		case TIOCIBAUD:
		case TIOCOBAUD:
		{
			DEBUG (("uart_ioctl(TIOCIBAUD) to %li", *(long *) buf));
			
			r = ctl_TIOCBAUD (iovar, (long *) buf);
			break;
		}
		case TIOCCBRK:
		{
			brk_off (iovar->regs);
			break;
		}
		case TIOCSBRK:
		{
			brk_on (iovar->regs);
			break;
		}
		case TIOCGFLAGS:
		{
			DEBUG (("uart_ioctl(TIOCGFLAGS) [%lx]", (ushort *) buf));
			
			ctl_TIOCGFLAGS (iovar, (ushort *) buf);
			break;
		}
		case TIOCSFLAGS:
		{
			DEBUG (("uart_ioctl(TIOCSFLAGS) -> %lx", *(ushort *) buf));
			
			r = ctl_TIOCSFLAGS (iovar, *(ushort *) buf);
			break;
		}
		case TIONOTSEND:
		case TIOCOUTQ:
		{
			*(long *) buf = iorec_used (&iovar->output);
			break;
		}
		case TIOCSFLAGSB:	/* anywhere documented? */
		{
			r = ENOSYS;
			break;
		}
		case TIOCGVMIN:
		{
			struct tty *tty = (struct tty *) f->devinfo;
			ushort *v = buf;
			
			v [0] = tty->vmin;
			v [1] = tty->vtime;
			
			break;
		}
		case TIOCSVMIN:
		{
			struct tty *tty = (struct tty *) f->devinfo;
			ushort *v = buf;
			
			if (v [0] > iovar->input.size / 2)
				v [0] = iovar->input.size / 2;
			
			tty->vmin = v [0];
			tty->vtime = v [1];
			
			/* t->vticks = 0; */
			
			break;
		}
		case TIOCWONLINE:
		{
# if 0
			struct tty *tty = (struct tty *) f->devinfo;
			
			while (tty->state & TS_BLIND)
				sleep (IO_Q, (long) &tty->state);
# else
			r = ENOSYS;
# endif
			break;
		}
		case TIOCBUFFER:	/* HSMODEM special */
		{
			long *ptr = (long *) buf;
			
			/* input buffer size */
			if (*ptr == -1)	*ptr = iovar->input.size;
			else		*ptr = -1;
			
			ptr++;
			
			/* input low watermark */
			if (*ptr == -1)	*ptr = iovar->input.low_water;
			else		*ptr = -1;
			
			ptr++;
			
			/* input high watermark */
			if (*ptr == -1)	*ptr = iovar->input.high_water;
			else		*ptr = -1;
			
			ptr++;
			
			/* output buffer size */
			if (*ptr == -1)	*ptr = iovar->output.size;
			else		*ptr = -1;
			
			break;
		}
		case TIOCCTLMAP:	/* HSMODEM */
		{
			long *ptr = (long *) buf;
			
			ptr [0] = 0
			/*	| TIOCMH_LE */
				| TIOCMH_DTR
				| TIOCMH_RTS
				| TIOCMH_CTS
				| TIOCMH_CD
				| TIOCMH_RI
				| TIOCMH_DSR
			/*	| TIOCMH_LEI */
			/*	| TIOCMH_TXD */
			/*	| TIOCMH_RXD */
				| TIOCMH_BRK
			/*	| TIOCMH_TER */
			/*	| TIOCMH_RER */
				| TIOCMH_TBE
				| TIOCMH_RBF
				;
			
			ptr [1] = 0;	/* will be never supported */
			ptr [2] = 0;	/* will be never supported */
			ptr [3] = 0;	/* reserved */
			ptr [4] = 0;	/* reserved */
			ptr [5] = 0;	/* reserved */
			
			break;
		}
		case TIOCCTLGET:	/* HSMODEM */
		{
			/* register long mask = *(long *) buf; */
			register long val = 0;
			register char reg;
			
			/* TIOCMH_LE */
			
			/* mcr */
			reg = iovar->regs->mcr;
			if (reg & DTRO) val |= TIOCMH_DTR;
			if (reg & RTSO) val |= TIOCMH_RTS;
			
			/* msr */
			reg = iovar->regs->msr;
			if (reg & CTSI) val |= TIOCMH_CTS;
			if (reg & RII ) val |= TIOCMH_RI;
			if (reg & DCDI) val |= TIOCMH_CD;
			if (reg & DSRI) val |= TIOCMH_DSR;
			
			/* TIOCMH_LEI */
			/* TIOCMH_TXD */
			/* TIOCMH_RXD */
			
			/* lsr */
			reg = iovar->regs->lsr;
			if (reg & BRK ) val |= TIOCMH_BRK;
			/* TIOCMH_TER */
			/* TIOCMH_RER */
			if (reg & TXDE) val |= TIOCMH_TBE;
			if (reg & RXDA) val |= TIOCMH_RBF;
			
			*(long *) buf = val;
			break;
		}
		case TIOCCTLSET:	/* HSMODEM */
		{
			long *arg = (long *) buf;
			
			register long mask = *arg++;
			register long val = *arg;
			
			if (mask & (TIOCMH_DTR | TIOCMH_RTS))
			{
				/* mcr */
				register char reg_val = iovar->regs->mcr;
				
				if (mask & TIOCMH_DTR)
				{
					if (val & TIOCMH_DTR)	reg_val |= DTRO;
					else			reg_val &= ~DTRO;
				}
				
				if (mask & TIOCMH_RTS)
				{
					if (val & TIOCMH_RTS)	reg_val |= RTSO;
					else			reg_val &= ~RTSO;
				}
				
				iovar->regs->mcr = reg_val;
			}
			
			break;
		}
		case TIOCERROR:		/* HSMODEM */
		{
			r = EBADARG;
			break;
		}
		case TIOCCDTR:
		{
			dtr_off (iovar->regs);
			break;
		}
		case TIOCSDTR:
		{
			dtr_on (iovar->regs);
			break;
		}
		
		case F_SETLK:
		case F_SETLKW:
		{
			struct flock *lck = (struct flock *) buf;
			int cpid = p_getpid ();
			
			while (iovar->lockpid && iovar->lockpid != cpid)
			{
				if (mode == F_SETLKW && lck->l_type != F_UNLCK)
					sleep (IO_Q, (long) iovar);
				else
					return ELOCKED;
			}
			
			if (lck->l_type == F_UNLCK)
			{
				if (!(f->flags & O_LOCK))
				{
					DEBUG (("uart_ioctl: wrong file descriptor for UNLCK"));
					return ENSLOCK;
				}
				
				if (iovar->lockpid != cpid)
					return ENSLOCK;
				
				iovar->lockpid = 0;
				f->flags &= ~O_LOCK;
				
				/* wake anyone waiting for this lock */
				wake (IO_Q, (long) iovar);
			}
			else
			{
				iovar->lockpid = cpid;
				f->flags |= O_LOCK;
			}
			
			break;
		}
		case F_GETLK:
		{
			struct flock *lck = (struct flock *) buf;
			
			if (iovar->lockpid)
			{
				lck->l_type = F_WRLCK;
				lck->l_start = lck->l_len = 0;
				lck->l_pid = iovar->lockpid;
			}
			else
			{
				lck->l_type = F_UNLCK;
			}
			
			break;
		}
		
		default:
		{
			/* Fcntl will automatically call tty_ioctl to handle
			 * terminal calls that we didn't deal with
			 */
			r = ENOSYS;
			break;
		}
	}
	
	DEBUG (("uart_ioctl: return %li", r));
	return r;
}

static long _cdecl
uart_datime (FILEPTR *f, ushort *timeptr, int rwflag)
{
	DEBUG (("uart_datime [%i]: enter (%i)", f->fc.aux, rwflag));
	
	if (rwflag)
		return EACCES;
	
	*timeptr++ = timestamp;
	*timeptr = datestamp;
	
	return E_OK;
}

static long _cdecl
uart_close (FILEPTR *f, int pid)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	
	DEBUG (("uart_close [%i]: enter", f->fc.aux));
	
	if (iovar->lockpid == pid)
	{
		/* wake anyone waiting for this lock */
		wake (IO_Q, (long) iovar);
	}
	
	if (f->links <= 0)
	{
		register FILEPTR **temp;
		register long flag = 1;
		
		/* remove the FILEPTR from the linked list */
		temp = &iovar->open;
		while (*temp)
		{
			if (*temp == f)
			{
				*temp = f->next;
				f->next = NULL;
				flag = 0;
				
				break;
			}
			
			temp = &(*temp)->next;
		}
		
		if (flag)
		{
			ALERT (("uart_close: remove open FILEPTR fail!", f->fc.aux));
		}
	}
	
	DEBUG (("uart_close: leave ok"));
	return E_OK;
}

static long _cdecl
uart_select (FILEPTR *f, long proc, int mode)
{
	IOVAR *iovar = IOVARS (f->fc.aux);
	struct tty *tty = (struct tty *) f->devinfo;
	
	DEBUG (("uart_select [%i]: enter (%li, %i, %lx)", f->fc.aux, proc, mode, tty));
	
	if (mode == O_RDONLY)
	{
		if (!iorec_empty (&iovar->input))
		{
			TRACE (("uart_select: data present for device %lx", iovar));
			return 1;
		}
		
		if (tty)
		{
			/* avoid collisions with other processes
			 */
			
			if (tty->rsel)
				/* collision */
				return 2;
			
			tty->rsel = proc;
			addroottimeout (1000L, check_select, 0);
		}
		
		return 0;
	}
	else if (mode == O_WRONLY)
	{
		if ((!tty || !(tty->state & (TS_BLIND | TS_HOLD))) && !iorec_empty (&iovar->output))
		{
			TRACE (("uart_select: ready to output on %lx", iovar));
			return 1;
		}
		
		if (tty)
		{
			/* avoid collisions with other processes
			 */
			
			if (tty->wsel)
				/* collision */
				return 2;
			
			tty->wsel = proc;
			addroottimeout (1000L, check_select, 0);
		}
		
		return 0;
	}
	
	/* default -- we don't know this mode, return 0 */
	return 0;
}

static void _cdecl
uart_unselect (FILEPTR *f, long proc, int mode)
{
	struct tty *tty = (struct tty *) f->devinfo;
	
	DEBUG (("uart_unselect [%i]: enter (%li, %i, %lx)", f->fc.aux, proc, mode, tty));
	
	if (tty)
	{
		if (mode == O_RDONLY && tty->rsel == proc)
			tty->rsel = 0;
		else if (mode == O_WRONLY && tty->wsel == proc)
			tty->wsel = 0;
	}
}

/* END device driver routines - top half */
/****************************************************************************/
