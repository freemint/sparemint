/*
 * This file belongs to FreeMiNT.  It's not in the original MiNT 1.12
 * distribution.  See the file Changes.MH for a detailed log of changes.
 */

/*
 * This file is dedicated to the FreeMiNT project.
 * It's not allowed to use this file on other projects without my explicit
 * permission.
 */

/*
 * begin:	1999-07-29
 * last change: 1999-07-29
 * 
 * Author: Frank Naumann - <fnaumann@cs.uni-magdeburg.de>
 * 
 * please send suggestions, patches or bug reports to me or
 * the MiNT mailing list
 *  
 */

# ifndef _rsvf_h
# define _rsvf_h

typedef struct rsvf RSVF;
struct rsvf
{
	char	*data;		/* name or next pointer */
	char	type;		/* specifies the data pointer */
# define RSVF_PORT	0x80	/* if set, RSFV is a port object */
# define RSVF_GEMDOS	0x40	/* port: GEMDOS know about it */
# define RSVF_BIOS	0x20	/* port: BIOS know about it */
# define RSVF_FTABLE	0x01	/* port: ptr to function table is before data */
	char	res1;		/* reserved */
	char	bdev;		/* BIOS device number */
	char	res2;		/* reserved */
};


# endif /* _rsvf_h */
