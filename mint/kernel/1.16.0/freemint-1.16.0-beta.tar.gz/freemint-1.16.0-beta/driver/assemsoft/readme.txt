==============================================================================
 ==                                                                        ==
    ==                  FreeMiNT 1.16.0 beta release                    ==
 ==                                                                        ==
==============================================================================

These are ethernet drivers for various ethernet cards written by Odd Skancke.
Many thanks to him for contributing it to the FreeMiNT distribution. They
are hopefully integrated into FreeMiNT CVS at some time.

There is extended information about which cards and hardware are exactly
supprted. Please take a look on:

                  ===> http://assemsoft.atari.org/ <===

If you want to use one of them just copy them into the <sysdir> directory
and reboot. Take a look on the bootmessages if the driver find the ethernet
card and is correctly installed. After successfull boot you can configure it
with ifconfig or on an EasyMiNT installation add the configuration line to
"/etc/sysconfig/config.if".


The drivers:

rtl8139/                   - PCI card driver for the wide-spread 10/100 Mbit
                             low-cost network cards with RTL8139 chipset.
rtl8139/hades/rtl8139.xif  - Hades version
rtl8139/milan/rtl8139.xif  - Milan version

ne2000/                    - driver for NE2000 PCI and ISA cards
ne2000/ne2kmisa.xif        - Milan ISA bus version
ne2000/ne2kmpci.xif        - Milan/Hades PCI version

EtherneC/                  - driver for the EtherneC NE2000 adapter
EtherneC/ne2kect2.xif      - Falcon CT2 version
EtherneC/ne2kenec.xif      - Falcon, TT version
