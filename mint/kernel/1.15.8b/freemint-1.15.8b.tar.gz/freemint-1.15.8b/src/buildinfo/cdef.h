/* This is an automatically generated file.
 * Do not edit, edit cdef.sh instead
 */

# ifndef _cdef_h
# define _cdef_h

# define _COMPILER_NAME gcc version 2.95.2 19991024 (release)
# define _COMPILER_OPTS -fomit-frame-pointer -O2 -m68030
# define _COMPILER_DEFS -DMULTITOS -DVERBOSE_BOOT -DTRAPS_PRIVATE -DCRYPTO_CODE -DDEBUG_INFO -DONLY030 -DCPU030

# endif /* _cdef_h */
